use regex::Regex;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::sync::OnceLock;

use super::author_knowledge::AuthorSource;
use crate::{
    Error, Result,
    craft::lexicon::WordMatcher,
    manuscript::{
        Evidence, Manuscript, TextRange,
        author_source::validate_sources,
        config::{validate_id, validate_name},
    },
    substrate::utils::AnalysisAvailability,
};

static MALE_PRONOUNS: &[&str] = &["he", "him", "his", "himself"];
static FEMALE_PRONOUNS: &[&str] = &["she", "her", "hers", "herself"];
static NEUTRAL_PRONOUNS: &[&str] = &["they", "them", "their", "theirs", "themselves"];
pub const MAX_COREFERENCE_MENTIONS: usize = 10_000;
pub const MAX_COREFERENCE_CHAIN_DEPTH: u8 = 16;
pub const MAX_AUTHOR_COREFERENCE_BYTES: usize = 4 * 1024 * 1024;

fn pronoun_matcher() -> &'static WordMatcher {
    static M: OnceLock<WordMatcher> = OnceLock::new();
    M.get_or_init(|| WordMatcher::new(&[MALE_PRONOUNS, FEMALE_PRONOUNS, NEUTRAL_PRONOUNS].concat()))
}
fn paragraph_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r"\n\s*\n").expect("constant paragraph regex"))
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum Gender {
    Male,
    Female,
    Neutral,
    Unknown,
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum PronounKind {
    Other,
    Possessive,
    Reflexive,
}
fn pronoun_gender(token: &str) -> Gender {
    let token = token.to_ascii_lowercase();
    if MALE_PRONOUNS.contains(&token.as_str()) {
        Gender::Male
    } else if FEMALE_PRONOUNS.contains(&token.as_str()) {
        Gender::Female
    } else {
        Gender::Neutral
    }
}
fn pronoun_kind(token: &str) -> PronounKind {
    match token.to_ascii_lowercase().as_str() {
        "himself" | "herself" | "themselves" => PronounKind::Reflexive,
        "his" | "her" | "their" => PronounKind::Possessive,
        _ => PronounKind::Other,
    }
}
fn gender_from_str(value: &str) -> Gender {
    match value {
        "male" => Gender::Male,
        "female" => Gender::Female,
        "neutral" => Gender::Neutral,
        _ => Gender::Unknown,
    }
}
fn compute_confidence(
    kind: PronounKind,
    exact_gender: bool,
    same_paragraph: bool,
    distance: usize,
    is_cataphoric: bool,
) -> f64 {
    if is_cataphoric {
        return 0.30;
    }
    match kind {
        PronounKind::Possessive | PronounKind::Reflexive => 0.40,
        _ if exact_gender && same_paragraph && distance < 80 => 0.85,
        _ if exact_gender && distance < 200 => 0.70,
        _ if !exact_gender && same_paragraph => 0.55,
        _ if exact_gender => 0.45,
        _ => 0.35,
    }
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CoreferenceBasis {
    LiteralName,
    UniquePrecedingCandidate,
    AdjacentReflexive,
    BoundedCataphora,
    QuoteLocalNamedCandidate,
    PronounChain,
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Mention {
    pub text: String,
    pub resolved_to: Option<String>,
    pub start: usize,
    pub is_pronoun: bool,
    pub confidence: f64,
    #[serde(default)]
    pub range: Option<TextRange>,
    #[serde(default)]
    pub resolution_basis: Option<CoreferenceBasis>,
    #[serde(default)]
    pub antecedent_start: Option<usize>,
}

fn sorted_counts<S: serde::Serializer>(
    counts: &HashMap<String, usize>,
    serializer: S,
) -> std::result::Result<S::Ok, S::Error> {
    counts
        .iter()
        .collect::<BTreeMap<_, _>>()
        .serialize(serializer)
}
#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CorefResult {
    pub mentions: Vec<Mention>,
    #[serde(serialize_with = "sorted_counts")]
    pub character_mentions: HashMap<String, usize>,
    /// Compatibility coverage convention; use resolution_coverage for empty input.
    pub pronoun_resolution_rate: f64,
    #[serde(default)]
    pub availability: AnalysisAvailability,
    #[serde(default)]
    pub diagnostics: Vec<String>,
    #[serde(default)]
    pub pronoun_count: usize,
    #[serde(default)]
    pub resolved_pronoun_count: usize,
    #[serde(default)]
    pub resolution_coverage: Option<f64>,
}

fn validate_inputs(
    scenes: &[&str],
    characters: &[&str],
    gender_map: Option<&HashMap<String, String>>,
) -> Result<()> {
    if scenes.len() > 10_000 || characters.len() > 256 {
        return Err(Error::InvalidInput(
            "coreference exceeds scene/cast limits".into(),
        ));
    }
    let mut bytes = 0usize;
    for scene in scenes {
        bytes = bytes
            .checked_add(scene.len())
            .filter(|n| *n <= 64 * 1024 * 1024)
            .ok_or_else(|| Error::InvalidInput("coreference source exceeds64MiB".into()))?;
        if scene.len() > 16 * 1024 * 1024 {
            return Err(Error::InvalidInput("coreference scene exceeds16MiB".into()));
        }
    }
    let mut names = BTreeSet::new();
    for character in characters {
        validate_name(character)?;
        if !names.insert(character.to_lowercase()) {
            return Err(Error::InvalidInput(
                "coreference cast names must be unique ignoring case".into(),
            ));
        }
    }
    if let Some(map) = gender_map {
        for (name, gender) in map {
            if !characters.contains(&name.as_str())
                || !["male", "female", "neutral", "unknown"].contains(&gender.as_str())
            {
                return Err(Error::InvalidInput(
                    "coreference gender hints require known names and supported labels".into(),
                ));
            }
        }
    }
    Ok(())
}
fn patterns<'a>(characters: &[&'a str]) -> Result<Vec<(&'a str, Regex)>> {
    characters
        .iter()
        .map(|&name| {
            Regex::new(&format!(r"(?i)\b{}\b", regex::escape(name)))
                .map(|pattern| (name, pattern))
                .map_err(|_| {
                    Error::InvalidInput("coreference name regex exceeds runtime limits".into())
                })
        })
        .collect()
}
fn names_in(text: &str, patterns: &[(&str, Regex)]) -> Result<Vec<Mention>> {
    let mut found = Vec::new();
    for (name, pattern) in patterns {
        for matched in pattern.find_iter(text) {
            if found.len() == MAX_COREFERENCE_MENTIONS {
                return Err(Error::InvalidInput(
                    "coreference mention candidates exceed10000".into(),
                ));
            }
            found.push(Mention {
                text: matched.as_str().into(),
                resolved_to: Some((*name).into()),
                start: matched.start(),
                is_pronoun: false,
                confidence: 0.95,
                range: None,
                resolution_basis: Some(CoreferenceBasis::LiteralName),
                antecedent_start: None,
            });
        }
    }
    found.sort_by(|a, b| {
        a.start
            .cmp(&b.start)
            .then_with(|| b.text.len().cmp(&a.text.len()))
            .then_with(|| a.resolved_to.cmp(&b.resolved_to))
    });
    let mut names: Vec<Mention> = Vec::new();
    for candidate in found {
        if let Some(last) = names.last_mut() {
            if last.start == candidate.start && last.text.len() == candidate.text.len() {
                if last.resolved_to != candidate.resolved_to {
                    last.resolved_to = None;
                    last.resolution_basis = None;
                    last.confidence = 0.0;
                }
                continue;
            }
            if candidate.start < last.start + last.text.len() {
                continue;
            }
        }
        names.push(candidate);
    }
    Ok(names)
}
fn quotations(text: &str) -> Vec<(usize, usize)> {
    let mut ranges = Vec::new();
    let mut open = None;
    let mut chars = text.char_indices().peekable();
    let mut previous: Option<char> = None;
    while let Some((position, ch)) = chars.next() {
        let next = chars.peek().map(|(_, ch)| *ch);
        let apostrophe = matches!(ch, '\'' | '\u{2019}')
            && previous.is_some_and(char::is_alphanumeric)
            && next.is_some_and(char::is_alphanumeric);
        if !apostrophe {
            if let Some((start, kind)) = open {
                if matches!(
                    (kind, ch),
                    ('"', '"') | ('\u{201c}', '\u{201d}') | ('\'', '\'') | ('\u{2018}', '\u{2019}')
                ) {
                    ranges.push((start, position + ch.len_utf8()));
                    open = None;
                }
            } else if matches!(ch, '"' | '\u{201c}' | '\u{2018}')
                || ch == '\''
                    && !previous.is_some_and(char::is_alphanumeric)
                    && next.is_some_and(char::is_alphanumeric)
            {
                open = Some((position, ch));
            }
        }
        previous = Some(ch);
    }
    if let Some((start, _)) = open {
        ranges.push((start, text.len()));
    }
    ranges
}
fn inside(ranges: &[(usize, usize)], position: usize) -> bool {
    quote_scope(ranges, position).is_some()
}
fn quote_scope(ranges: &[(usize, usize)], position: usize) -> Option<usize> {
    let index = ranges.partition_point(|(_, end)| *end <= position);
    ranges
        .get(index)
        .filter(|(start, end)| *start <= position && position < *end)
        .map(|_| index)
}
fn gender_counts(text: &str, names: &[Mention], counts: &mut HashMap<&str, (usize, usize)>) {
    let quotes = quotations(text);
    let mut start = 0;
    let mut name_cursor = 0;
    for end in paragraph_regex()
        .find_iter(text)
        .map(|m| m.start())
        .chain(std::iter::once(text.len()))
    {
        let first_name = name_cursor;
        while name_cursor < names.len() && names[name_cursor].start < end {
            name_cursor += 1;
        }
        let local: Vec<_> = names[first_name..name_cursor]
            .iter()
            .filter(|name| !inside(&quotes, name.start))
            .collect();
        let unique: BTreeSet<_> = local
            .iter()
            .filter_map(|name| name.resolved_to.as_deref())
            .collect();
        if unique.len() == 1 && local.iter().all(|name| name.resolved_to.is_some()) {
            let name = *unique.first().expect("one visible name");
            let first = local.first().expect("one visible name");
            for pronoun in pronoun_matcher().find_iter(&text[start..end]) {
                let position = start + pronoun.start;
                if position < first.start + first.text.len()
                    || position - first.start > 200
                    || inside(&quotes, position)
                {
                    continue;
                }
                if let Some(count) = counts.get_mut(name) {
                    match pronoun_gender(pronoun.text) {
                        Gender::Male => count.0 += 1,
                        Gender::Female => count.1 += 1,
                        _ => {}
                    }
                }
            }
        }
        start = end;
    }
}
fn finish_genders(counts: HashMap<&str, (usize, usize)>) -> HashMap<String, String> {
    counts
        .into_iter()
        .map(|(name, (male, female))| {
            let total = male + female;
            let gender = if total < 3 {
                "unknown"
            } else if male as f64 / total as f64 > 0.65 {
                "male"
            } else if female as f64 / total as f64 > 0.65 {
                "female"
            } else {
                "unknown"
            };
            (name.into(), gender.into())
        })
        .collect()
}
fn stamp_ranges(text: &str, mentions: &mut [Mention]) -> Result<()> {
    let mut wanted = Vec::with_capacity(mentions.len() * 2);
    for mention in mentions.iter() {
        let end = mention
            .start
            .checked_add(mention.text.len())
            .ok_or_else(|| Error::InvalidInput("coreference range overflow".into()))?;
        if text.get(mention.start..end) != Some(mention.text.as_str()) {
            return Err(Error::InvalidInput(
                "coreference mention differs from original source".into(),
            ));
        }
        wanted.extend([mention.start, end]);
    }
    wanted.sort_unstable();
    wanted.dedup();
    let mut offsets = Vec::with_capacity(wanted.len());
    let mut next = 0;
    let mut units = 0u32;
    for (byte, ch) in text.char_indices() {
        if next == wanted.len() {
            break;
        }
        if wanted[next] == byte {
            offsets.push(units);
            next += 1;
        }
        units += ch.len_utf16() as u32;
    }
    if wanted.get(next) == Some(&text.len()) {
        offsets.push(units);
        next += 1;
    }
    if next != wanted.len() {
        return Err(Error::InvalidInput(
            "coreference range is not a character boundary".into(),
        ));
    }
    for mention in mentions {
        let end = mention.start + mention.text.len();
        mention.range = Some(TextRange {
            byte_start: mention.start,
            byte_end: end,
            utf16_start: offsets[wanted
                .binary_search(&mention.start)
                .expect("requested start")],
            utf16_end: offsets[wanted.binary_search(&end).expect("requested end")],
        });
    }
    Ok(())
}

fn cataphoric_candidate<'a>(
    text: &str,
    position: usize,
    token_end: usize,
    names: &'a [Mention],
    sentences: &[(usize, usize)],
    quotes: &[(usize, usize)],
    compatible: impl Fn(&str) -> bool,
) -> Option<&'a Mention> {
    let &(start, end) = sentences.get(sentences.partition_point(|(_, end)| *end <= position))?;
    if start > position {
        return None;
    }
    let first = text[start..position]
        .split_whitespace()
        .next()?
        .to_ascii_lowercase();
    if ![
        "when", "before", "after", "although", "while", "if", "once", "until",
    ]
    .contains(&first.as_str())
    {
        return None;
    }
    let comma = token_end + text[token_end..end].find(',')?;
    let main_start =
        comma + 1 + text[comma + 1..end].len() - text[comma + 1..end].trim_start().len();
    if main_start > position + 100 {
        return None;
    }
    let first = names.partition_point(|name| name.start < main_start);
    let last = names.partition_point(|name| name.start < end && name.start <= position + 100);
    let mut candidates = names[first..last].iter().filter(|name| {
        name.start + name.text.len() <= end
            && !inside(quotes, name.start)
            && name.resolved_to.as_deref().is_some_and(&compatible)
    });
    let candidate = candidates.next()?;
    (candidate.start == main_start && candidates.next().is_none()).then_some(candidate)
}

pub struct CoreferenceResolver;
impl Default for CoreferenceResolver {
    fn default() -> Self {
        Self::new()
    }
}
impl CoreferenceResolver {
    pub fn new() -> Self {
        Self
    }
    pub fn build_character_gender_map_checked(
        &self,
        scenes: &[&str],
        characters: &[&str],
    ) -> Result<HashMap<String, String>> {
        validate_inputs(scenes, characters, None)?;
        let patterns = patterns(characters)?;
        let mut counts = characters.iter().map(|&name| (name, (0, 0))).collect();
        for text in scenes {
            gender_counts(text, &names_in(text, &patterns)?, &mut counts);
        }
        Ok(finish_genders(counts))
    }
    /// Co-occurrence hints are heuristic pronoun categories, not verified gender.
    pub fn build_character_gender_map(
        &self,
        scenes: &[&str],
        characters: &[&str],
    ) -> HashMap<String, String> {
        self.build_character_gender_map_checked(scenes, characters)
            .unwrap_or_default()
    }
    pub fn resolve(
        &self,
        text: &str,
        characters: &[&str],
        gender_map: Option<&HashMap<String, String>>,
    ) -> CorefResult {
        self.resolve_checked(text, characters, gender_map)
            .unwrap_or_else(|error| CorefResult {
                mentions: Vec::new(),
                character_mentions: HashMap::new(),
                pronoun_resolution_rate: 0.0,
                availability: AnalysisAvailability::Unavailable,
                diagnostics: vec![error.to_string()],
                pronoun_count: 0,
                resolved_pronoun_count: 0,
                resolution_coverage: None,
            })
    }
    pub fn resolve_checked(
        &self,
        text: &str,
        characters: &[&str],
        gender_map: Option<&HashMap<String, String>>,
    ) -> Result<CorefResult> {
        validate_inputs(&[text], characters, gender_map)?;
        let name_mentions = names_in(text, &patterns(characters)?)?;
        let owned;
        let gender_map = if let Some(map) = gender_map {
            map
        } else {
            let mut counts = characters.iter().map(|&name| (name, (0, 0))).collect();
            gender_counts(text, &name_mentions, &mut counts);
            owned = finish_genders(counts);
            &owned
        };
        let quote_ranges = quotations(text);
        let breaks: Vec<_> = paragraph_regex()
            .find_iter(text)
            .map(|m| m.start())
            .collect();
        let same_paragraph = |a: usize, b: usize| {
            let lo = a.min(b);
            let hi = a.max(b);
            breaks
                .get(breaks.partition_point(|brk| *brk <= lo))
                .is_none_or(|brk| *brk >= hi)
        };
        let sentences = crate::substrate::utils::sentence_spans(text);
        let mut pronouns: Vec<Mention> = Vec::new();
        let mut chain_depths: Vec<u8> = Vec::new();
        let mut previous_pronouns = [None::<usize>; 3];
        for token in pronoun_matcher().find_iter(text) {
            let end_names = name_mentions.partition_point(|name| name.start <= token.start);
            if end_names > 0
                && name_mentions[end_names - 1].start + name_mentions[end_names - 1].text.len()
                    >= token.end
            {
                continue;
            }
            if name_mentions.len() + pronouns.len() == MAX_COREFERENCE_MENTIONS {
                return Err(Error::InvalidInput(
                    "coreference mention candidates exceed10000".into(),
                ));
            }
            let mut mention = Mention {
                text: token.text.into(),
                resolved_to: None,
                start: token.start,
                is_pronoun: true,
                confidence: 0.0,
                range: None,
                resolution_basis: None,
                antecedent_start: None,
            };
            let gender = pronoun_gender(token.text);
            let gender_index = match gender {
                Gender::Male => 0,
                Gender::Female => 1,
                _ => 2,
            };
            let mut chain_depth = 0;
            {
                let scope = quote_scope(&quote_ranges, token.start);
                let kind = pronoun_kind(token.text);
                let compatible = |name: &str| {
                    let candidate =
                        gender_from_str(gender_map.get(name).map_or("unknown", String::as_str));
                    gender == Gender::Neutral || candidate == Gender::Unknown || candidate == gender
                };
                let start = name_mentions
                    .partition_point(|name| name.start < token.start.saturating_sub(300));
                let end = name_mentions.partition_point(|name| name.start < token.start);
                let mut candidates = BTreeMap::new();
                let mut ambiguous = false;
                for name in &name_mentions[start..end] {
                    if name.start + name.text.len() > token.start
                        || quote_scope(&quote_ranges, name.start) != scope
                    {
                        continue;
                    }
                    if let Some(character) = name.resolved_to.as_deref() {
                        if compatible(character) {
                            candidates.insert(character, name);
                        }
                    } else {
                        ambiguous = true;
                    }
                }
                let adjacent = if kind == PronounKind::Reflexive {
                    candidates
                        .values()
                        .find(|name| {
                            text[name.start + name.text.len()..token.start]
                                .chars()
                                .all(char::is_whitespace)
                        })
                        .copied()
                } else {
                    None
                };
                if !ambiguous && (candidates.len() == 1 || adjacent.is_some()) {
                    let name = adjacent
                        .unwrap_or_else(|| *candidates.values().next().expect("one candidate"));
                    let character = name.resolved_to.as_ref().expect("resolved candidate");
                    mention.resolved_to = Some(character.clone());
                    mention.antecedent_start = Some(name.start);
                    mention.resolution_basis = Some(if adjacent.is_some() {
                        CoreferenceBasis::AdjacentReflexive
                    } else if scope.is_some() {
                        CoreferenceBasis::QuoteLocalNamedCandidate
                    } else {
                        CoreferenceBasis::UniquePrecedingCandidate
                    });
                    mention.confidence = if gender == Gender::Neutral {
                        0.40
                    } else {
                        compute_confidence(
                            kind,
                            gender_from_str(
                                gender_map.get(character).map_or("unknown", String::as_str),
                            ) == gender,
                            same_paragraph(name.start, token.start),
                            token.start - name.start,
                            false,
                        )
                    };
                } else if !ambiguous
                    && candidates.is_empty()
                    && scope.is_none()
                    && kind != PronounKind::Reflexive
                    && let Some(name) = cataphoric_candidate(
                        text,
                        token.start,
                        token.end,
                        &name_mentions,
                        &sentences,
                        &quote_ranges,
                        compatible,
                    )
                {
                    mention.resolved_to = name.resolved_to.clone();
                    mention.antecedent_start = Some(name.start);
                    mention.confidence = 0.30;
                    mention.resolution_basis = Some(CoreferenceBasis::BoundedCataphora);
                }
                if mention.resolved_to.is_none()
                    && !ambiguous
                    && candidates.is_empty()
                    && kind != PronounKind::Reflexive
                    && let Some(previous) = previous_pronouns[gender_index]
                {
                    let antecedent = &pronouns[previous];
                    let first_name =
                        name_mentions.partition_point(|name| name.start < antecedent.start);
                    let next_quote = quote_ranges
                        .get(quote_ranges.partition_point(|(start, _)| *start <= antecedent.start));
                    let competing_name = name_mentions[first_name..end].iter().any(|name| {
                        name.resolved_to.is_none() || name.resolved_to != antecedent.resolved_to
                    });
                    if antecedent.resolved_to.is_some()
                        && chain_depths[previous] < MAX_COREFERENCE_CHAIN_DEPTH
                        && token.start - antecedent.start <= 300
                        && same_paragraph(antecedent.start, token.start)
                        && quote_scope(&quote_ranges, antecedent.start) == scope
                        && next_quote.is_none_or(|(start, _)| *start >= token.start)
                        && !competing_name
                    {
                        mention.resolved_to = antecedent.resolved_to.clone();
                        mention.antecedent_start = Some(antecedent.start);
                        mention.resolution_basis = Some(CoreferenceBasis::PronounChain);
                        mention.confidence = 0.30;
                        chain_depth = chain_depths[previous] + 1;
                    }
                }
            }
            previous_pronouns[gender_index] = Some(pronouns.len());
            chain_depths.push(chain_depth);
            pronouns.push(mention);
        }
        let pronoun_count = pronouns.len();
        let resolved_pronoun_count = pronouns
            .iter()
            .filter(|mention| mention.resolved_to.is_some())
            .count();
        let resolution_coverage =
            (pronoun_count > 0).then(|| resolved_pronoun_count as f64 / pronoun_count as f64);
        let mut mentions = name_mentions;
        mentions.extend(pronouns);
        mentions.sort_by_key(|mention| mention.start);
        stamp_ranges(text, &mut mentions)?;
        let mut character_mentions = characters
            .iter()
            .map(|&name| (name.into(), 0))
            .collect::<HashMap<_, _>>();
        for mention in &mentions {
            if let Some(character) = &mention.resolved_to {
                *character_mentions
                    .get_mut(character)
                    .expect("resolved cast identity") += 1;
            }
        }
        Ok(CorefResult { mentions,character_mentions,pronoun_resolution_rate: resolution_coverage.unwrap_or(1.0), availability: AnalysisAvailability::Partial,
            diagnostics: vec!["Literal-name, quote-local named antecedents and bounded scope-local pronoun-chain hypotheses only; confidence tiers and resolution coverage are not semantic accuracy probabilities. Dialogue speakers and ambiguous antecedents remain unassessed; cataphora is limited to a subordinate clause with one visible main-clause name.".into()],
            pronoun_count,resolved_pronoun_count,resolution_coverage })
    }
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AuthorCoreferenceLink {
    pub id: String,
    pub mention: AuthorSource,
    pub antecedent: AuthorSource,
    pub character_id: String,
}
#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ResolvedAuthorCoreference {
    pub id: String,
    pub character_id: String,
    pub mention: Evidence,
    pub antecedent: Evidence,
}
#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AuthorCoreferenceResult {
    pub document_id: String,
    pub availability: AnalysisAvailability,
    pub diagnostics: Vec<String>,
    pub links: Vec<ResolvedAuthorCoreference>,
}

pub fn resolve_author_coreference(
    manuscript: &Manuscript,
    links: &[AuthorCoreferenceLink],
) -> Result<AuthorCoreferenceResult> {
    manuscript.validate()?;
    if links.len() > MAX_COREFERENCE_MENTIONS {
        return Err(Error::InvalidInput(
            "author coreference exceeds10000 links".into(),
        ));
    }
    let characters: BTreeSet<_> = manuscript
        .known_characters
        .iter()
        .map(String::as_str)
        .collect();
    let mut ids = BTreeSet::new();
    let mut spans = BTreeSet::new();
    let mut assignments = BTreeMap::new();
    let mut bytes = 0usize;
    let mut sources = Vec::with_capacity(links.len() * 2);
    for link in links {
        validate_id(&link.id)?;
        validate_id(&link.character_id)?;
        if link.mention.scene_id == link.antecedent.scene_id
            && link.mention.utf16_start == link.antecedent.utf16_start
            && link.mention.utf16_end == link.antecedent.utf16_end
        {
            return Err(Error::InvalidInput(
                "author coreference requires a distinct antecedent span".into(),
            ));
        }
        for endpoint in [&link.mention, &link.antecedent] {
            let key = (
                endpoint.scene_id.as_str(),
                endpoint.utf16_start,
                endpoint.utf16_end,
            );
            if assignments
                .insert(key, link.character_id.as_str())
                .is_some_and(|previous| previous != link.character_id)
            {
                return Err(Error::InvalidInput(
                    "author coreference assigns conflicting identities to one source span".into(),
                ));
            }
        }
        if !characters.contains(link.character_id.as_str())
            || !ids.insert(&link.id)
            || !spans.insert((
                &link.mention.scene_id,
                link.mention.utf16_start,
                link.mention.utf16_end,
            ))
        {
            return Err(Error::InvalidInput(
                "author coreference requires known identities and unique IDs/mention spans".into(),
            ));
        }
        bytes = bytes
            .checked_add(
                link.id.len()
                    + link.character_id.len()
                    + link.mention.scene_id.len()
                    + link.mention.quote.len()
                    + link.antecedent.scene_id.len()
                    + link.antecedent.quote.len(),
            )
            .filter(|n| *n <= MAX_AUTHOR_COREFERENCE_BYTES)
            .ok_or_else(|| Error::InvalidInput("author coreference metadata exceeds4MiB".into()))?;
        sources.extend([&link.mention, &link.antecedent]);
    }
    let mut evidence = validate_sources(manuscript, &sources)?.into_iter();
    let mut resolved: Vec<_> = links
        .iter()
        .map(|link| ResolvedAuthorCoreference {
            id: link.id.clone(),
            character_id: link.character_id.clone(),
            mention: evidence.next().expect("mention source validated"),
            antecedent: evidence.next().expect("antecedent source validated"),
        })
        .collect();
    resolved.sort_by(|a, b| {
        a.mention
            .scene_id
            .cmp(&b.mention.scene_id)
            .then_with(|| a.mention.range.byte_start.cmp(&b.mention.range.byte_start))
            .then_with(|| a.mention.range.byte_end.cmp(&b.mention.range.byte_end))
            .then_with(|| a.id.cmp(&b.id))
    });
    Ok(AuthorCoreferenceResult { document_id: manuscript.document_id.clone(), availability: AnalysisAvailability::Complete, diagnostics: vec!["Author-supplied identity links only; exact sources locate annotations without proving their semantic interpretation. Nested mentions and explicit cataphora are supported; no chronology is inferred.".into()], links: resolved })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_input() {
        let resolver = CoreferenceResolver::new();
        let result = resolver.resolve("", &[], None);
        assert!(result.mentions.is_empty());
        assert_eq!(result.pronoun_resolution_rate, 1.0);
    }

    #[test]
    fn test_basic_he_resolution() {
        let resolver = CoreferenceResolver::new();
        let text = "John walked to the store. He bought some milk.";
        let mut gender_map = HashMap::new();
        gender_map.insert("John".to_string(), "male".to_string());
        let result = resolver.resolve(text, &["John"], Some(&gender_map));

        let he_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "he")
            .expect("should find 'He' pronoun");
        assert_eq!(he_mention.resolved_to.as_deref(), Some("John"));
        assert!(he_mention.confidence > 0.0);
        assert!(result.pronoun_resolution_rate > 0.0);
    }

    #[test]
    fn test_gender_inference() {
        let resolver = CoreferenceResolver::new();
        let scenes = vec![
            "John picked up his bag. He walked to the door. His coat was heavy.",
            "John said he would return. He promised his friend.",
        ];
        let map = resolver.build_character_gender_map(&scenes, &["John"]);
        assert_eq!(map.get("John").map(|s| s.as_str()), Some("male"));
    }

    #[test]
    fn test_paragraph_boundary() {
        let resolver = CoreferenceResolver::new();
        let text = "John entered the room.\n\nMary smiled. She waved.";
        let mut gender_map = HashMap::new();
        gender_map.insert("John".to_string(), "male".to_string());
        gender_map.insert("Mary".to_string(), "female".to_string());
        let result = resolver.resolve(text, &["John", "Mary"], Some(&gender_map));

        let she_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "she")
            .expect("should find 'She' pronoun");
        assert_eq!(she_mention.resolved_to.as_deref(), Some("Mary"));
    }

    #[test]
    fn test_they_them_neutral_resolution() {
        let resolver = CoreferenceResolver::new();
        let text = "Alex walked in. They sat down.";
        let mut gender_map = HashMap::new();
        gender_map.insert("Alex".to_string(), "unknown".to_string());
        let result = resolver.resolve(text, &["Alex"], Some(&gender_map));

        let they_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "they")
            .expect("should find 'They' pronoun");
        assert_eq!(they_mention.resolved_to.as_deref(), Some("Alex"));
        assert!((they_mention.confidence - 0.4).abs() < f64::EPSILON);
    }

    #[test]
    fn test_possessive_resolution() {
        let resolver = CoreferenceResolver::new();
        let text = "Mary put down her book. John picked up his sword.";
        let mut gender_map = HashMap::new();
        gender_map.insert("Mary".to_string(), "female".to_string());
        gender_map.insert("John".to_string(), "male".to_string());
        let result = resolver.resolve(text, &["Mary", "John"], Some(&gender_map));

        let her_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "her")
            .expect("should find 'her' pronoun");
        assert_eq!(her_mention.resolved_to.as_deref(), Some("Mary"));
        assert!((her_mention.confidence - 0.40).abs() < f64::EPSILON);

        let his_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "his")
            .expect("should find 'his' pronoun");
        assert_eq!(his_mention.resolved_to.as_deref(), Some("John"));
        assert!((his_mention.confidence - 0.40).abs() < f64::EPSILON);
    }

    #[test]
    fn test_reflexive_resolution() {
        let resolver = CoreferenceResolver::new();
        let text = "John looked at himself in the mirror.";
        let mut gender_map = HashMap::new();
        gender_map.insert("John".to_string(), "male".to_string());
        let result = resolver.resolve(text, &["John"], Some(&gender_map));

        let himself_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "himself")
            .expect("should find 'himself' pronoun");
        assert_eq!(himself_mention.resolved_to.as_deref(), Some("John"));
        assert!((himself_mention.confidence - 0.40).abs() < f64::EPSILON);
    }

    #[test]
    fn test_cataphoric_resolution() {
        let resolver = CoreferenceResolver::new();
        let text = "When he arrived, John was tired.";
        let mut gender_map = HashMap::new();
        gender_map.insert("John".to_string(), "male".to_string());
        let result = resolver.resolve(text, &["John"], Some(&gender_map));

        let he_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "he")
            .expect("should find 'he' pronoun");
        assert_eq!(he_mention.resolved_to.as_deref(), Some("John"));
        assert!((he_mention.confidence - 0.30).abs() < f64::EPSILON);
    }

    #[test]
    fn test_confidence_tiers() {
        let resolver = CoreferenceResolver::new();
        // Same paragraph, close distance, exact gender match -> 0.85
        let text = "John smiled. He laughed.";
        let mut gender_map = HashMap::new();
        gender_map.insert("John".to_string(), "male".to_string());
        let result = resolver.resolve(text, &["John"], Some(&gender_map));

        let he_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "he")
            .expect("should find 'He' pronoun");
        assert_eq!(he_mention.resolved_to.as_deref(), Some("John"));
        assert!((he_mention.confidence - 0.85).abs() < f64::EPSILON);
    }

    #[test]
    fn test_name_mention_confidence() {
        let resolver = CoreferenceResolver::new();
        let text = "John walked to the store.";
        let mut gender_map = HashMap::new();
        gender_map.insert("John".to_string(), "male".to_string());
        let result = resolver.resolve(text, &["John"], Some(&gender_map));

        let name_mention = result
            .mentions
            .iter()
            .find(|m| !m.is_pronoun && m.text == "John")
            .expect("should find 'John' name mention");
        assert!((name_mention.confidence - 0.95).abs() < f64::EPSILON);
    }

    #[test]
    fn test_cross_paragraph_confidence() {
        let resolver = CoreferenceResolver::new();
        let text = "John entered the room.\n\nHe sat down.";
        let mut gender_map = HashMap::new();
        gender_map.insert("John".to_string(), "male".to_string());
        let result = resolver.resolve(text, &["John"], Some(&gender_map));

        let he_mention = result
            .mentions
            .iter()
            .find(|m| m.is_pronoun && m.text.to_lowercase() == "he")
            .expect("should find 'He' pronoun");
        assert_eq!(he_mention.resolved_to.as_deref(), Some("John"));
        // Cross paragraph, exact gender, distance ~24 chars -> 0.70
        assert!((he_mention.confidence - 0.70).abs() < f64::EPSILON);
    }
}
