use narrative_lens::{
    structure::promise_payoff::{
        PayoffStatus, build_promise_payoff_ledger, build_promise_payoff_ledger_checked,
    },
    substrate::utils::AnalysisAvailability,
};
#[test]
fn empty_valid_inputs_do_not_create_scene_zero_promises() {
    let r =
        build_promise_payoff_ledger_checked(&[], &[], "mystery", &[], &[], "three_act", 0).unwrap();
    assert!(r.promises.is_empty());
    assert_eq!(r.availability, AnalysisAvailability::Unavailable);
    assert!(r.investment_curve.is_empty());
    assert!(
        build_promise_payoff_ledger(&[], &[], "mystery", &[], &[], "three_act", 0)
            .promises
            .is_empty()
    );
}
#[test]
fn whitespace_only_bodies_are_unavailable_without_discarding_supplied_setups() {
    let blank =
        build_promise_payoff_ledger_checked(&[" \n "], &[0], "mystery", &[], &[], "three_act", 1)
            .unwrap();
    assert_eq!(blank.availability, AnalysisAvailability::Unavailable);
    assert!(blank.promises.is_empty());
    let supplied = build_promise_payoff_ledger_checked(
        &[" \n "],
        &[0],
        "",
        &[("authored outline setup".into(), 0, true)],
        &[],
        "",
        1,
    )
    .unwrap();
    assert!(
        supplied
            .promises
            .iter()
            .any(|p| matches!(p.status, PayoffStatus::ConfirmedFulfilled))
    );
}

#[test]
fn mismatched_counts_invalid_indices_and_overflow_are_rejected_before_analysis() {
    for (words, total) in [(vec![], 1), (vec![1], 0), (vec![usize::MAX], 1)] {
        assert!(
            build_promise_payoff_ledger_checked(&["x"], &words, "", &[], &[], "", total).is_err()
        );
    }
    assert!(
        build_promise_payoff_ledger_checked(
            &["x"],
            &[1],
            "",
            &[("setup".into(), 1, false)],
            &[],
            "",
            1
        )
        .is_err()
    );
    assert!(
        build_promise_payoff_ledger_checked(&["x"], &[1], "", &[], &[("Alice".into(), 1)], "", 1)
            .is_err()
    );
    assert!(
        build_promise_payoff_ledger_checked(
            &["x"],
            &[1],
            "",
            &[],
            &[("Alice".into(), 0), ("ALICE".into(), 0)],
            "",
            1
        )
        .is_err()
    );
    let invalid = build_promise_payoff_ledger(&["x"], &[usize::MAX], "", &[], &[], "", 1);
    assert_eq!(invalid.availability, AnalysisAvailability::Unavailable);
    assert!(invalid.diagnostics.iter().any(|s| s.contains("invalid")));
}
#[test]
fn caller_confirmation_has_no_invented_payoff_position_or_quality() {
    let r = build_promise_payoff_ledger_checked(
        &["x"],
        &[1],
        "",
        &[("an explicit setup".into(), 0, true)],
        &[],
        "",
        1,
    )
    .unwrap();
    let p = r
        .promises
        .iter()
        .find(|p| matches!(p.status, PayoffStatus::ConfirmedFulfilled))
        .unwrap();
    assert!(p.payoff_scene.is_none());
    assert!(p.payoff_quality.is_none());
    assert!(r.weighted_health.is_finite());
    assert_eq!(r.broken_count, 0);
}
#[test]
fn names_labels_setup_counts_and_payload_boundaries_are_explicit() {
    for bytes in [127, 128, 129] {
        assert_eq!(
            build_promise_payoff_ledger_checked(&["x"], &[1], &"g".repeat(bytes), &[], &[], "", 1)
                .is_ok(),
            bytes <= 128
        );
        assert_eq!(
            build_promise_payoff_ledger_checked(
                &["x"],
                &[1],
                "",
                &[],
                &[("a".repeat(bytes), 0)],
                "",
                1
            )
            .is_ok(),
            bytes <= 128
        );
    }
    for bytes in [4095, 4096, 4097] {
        assert_eq!(
            build_promise_payoff_ledger_checked(
                &["x"],
                &[1],
                "",
                &[("x".repeat(bytes), 0, false)],
                &[],
                "",
                1
            )
            .is_ok(),
            bytes <= 4096
        );
    }
    for count in [255, 256, 257] {
        let names: Vec<_> = (0..count).map(|i| (format!("p{i}"), 0)).collect();
        assert_eq!(
            build_promise_payoff_ledger_checked(&["x"], &[1], "", &[], &names, "", 1).is_ok(),
            count <= 256
        );
    }
    for count in [9999, 10000, 10001] {
        let items = vec![("setup".into(), 0, false); count];
        assert_eq!(
            build_promise_payoff_ledger_checked(&["x"], &[1], "", &items, &[], "", 1).is_ok(),
            count <= 10000
        );
    }
    for delta in [-1isize, 0, 1] {
        let mut items = vec![("x".repeat(4096), 0, false); 1024];
        if delta < 0 {
            items[1023].0.pop();
        } else if delta > 0 {
            items.push(("x".into(), 0, false));
        }
        assert_eq!(
            build_promise_payoff_ledger_checked(&["x"], &[1], "", &items, &[], "", 1).is_ok(),
            delta <= 0
        );
    }
    let error = build_promise_payoff_ledger_checked(
        &["x"],
        &[1],
        "",
        &[],
        &[("private".repeat(10000), 0)],
        "",
        1,
    )
    .unwrap_err()
    .to_string();
    assert!(!error.contains("private"));
}
#[test]
fn count_and_source_byte_budgets_cover_minus_equal_plus_one() {
    for count in [9999, 10000, 10001] {
        let scenes = vec![""; count];
        let words = vec![0; count];
        assert_eq!(
            build_promise_payoff_ledger_checked(&scenes, &words, "", &[], &[], "", count).is_ok(),
            count <= 10000
        );
    }
    for count in [16 * 1024 * 1024 - 1, 16 * 1024 * 1024, 16 * 1024 * 1024 + 1] {
        assert_eq!(
            build_promise_payoff_ledger_checked(&["x"], &[count], "", &[], &[], "", 1).is_ok(),
            count <= 16 * 1024 * 1024
        );
    }
    for delta in [-1isize, 0, 1] {
        let words = [16 * 1024 * 1024; 3];
        let mut words = words.to_vec();
        words.push((16 * 1024 * 1024isize + delta.min(0)) as usize);
        if delta > 0 {
            words.push(1);
        }
        let sources = vec!["x"; words.len()];
        assert_eq!(
            build_promise_payoff_ledger_checked(&sources, &words, "", &[], &[], "", sources.len())
                .is_ok(),
            delta <= 0
        );
    }
    for bytes in [16 * 1024 * 1024 - 1, 16 * 1024 * 1024, 16 * 1024 * 1024 + 1] {
        let text = " ".repeat(bytes);
        assert_eq!(
            build_promise_payoff_ledger_checked(&[&text], &[0], "", &[], &[], "", 1).is_ok(),
            bytes <= 16 * 1024 * 1024
        );
    }
    for delta in [-1isize, 0, 1] {
        let text = " ".repeat(16 * 1024 * 1024);
        let last = " ".repeat((16 * 1024 * 1024isize + delta.min(0)) as usize);
        let mut sources = vec![text.as_str(); 3];
        sources.push(&last);
        if delta > 0 {
            sources.push("x");
        }
        let words = vec![0; sources.len()];
        assert_eq!(
            build_promise_payoff_ledger_checked(&sources, &words, "", &[], &[], "", sources.len())
                .is_ok(),
            delta <= 0
        );
    }
}
