// Type-only check for the generated TypeScript definitions (index.d.ts), run
// via `npm run test:types` (tsc --noEmit). This file has no runtime
// assertions -- a type error here is the test failure.

import {
  computeReadability,
  checkGrammar,
  listStructureTemplates,
  type ReadabilityResultJs,
  type GrammarFindingJs,
} from '../../index.js';

const readability: ReadabilityResultJs = computeReadability('Example passage.');
const fkgl: number = readability.fkgl;
const gradeLabel: string = readability.gradeLevels.fkgl;

const findings: GrammarFindingJs[] = checkGrammar('Example passage.');
const firstKind: string | undefined = findings[0]?.kind;

const templates: string[] = listStructureTemplates();

void fkgl;
void gradeLabel;
void firstKind;
void templates;

import { analyzeManuscript, analyzeManuscriptAsync, compareManuscriptReports, ManuscriptContext } from '../../index.js';
import type { Manuscript, Report, RuleId } from '../../manuscript.js';
const manuscriptInput: Manuscript = { documentId: 'typed', scenes: [{ id: 'first', text: 'She was was tired.' }], configuration: { rules: ['NL-GRAMMAR-REPETITION'] } };
const manuscriptReport: Report = analyzeManuscript(manuscriptInput);
const manuscriptPromise: Promise<Report> = analyzeManuscriptAsync(manuscriptInput);
const manuscriptContext = new ManuscriptContext(1024);
const contextReport: Report = manuscriptContext.analyze(manuscriptInput);
const contextPromise: Promise<Report> = manuscriptContext.analyzeAsync(manuscriptInput);
const introducedRule: RuleId | undefined = compareManuscriptReports(manuscriptReport, contextReport).introduced[0]?.ruleId;
// @ts-expect-error Unknown rule IDs are rejected statically.
const invalidRule: RuleId = 'unknown';
// @ts-expect-error Findings expose typed confidence provenance, not a numeric score alone.
const numericConfidence: number = manuscriptReport.findings[0]!.confidence;
void [manuscriptPromise, contextPromise, introducedRule, invalidRule, numericConfidence];

import { defaultManuscriptConfiguration, listManuscriptRules, parseManuscriptReport } from '../../index.js';
import type { Configuration, Scene } from '../../manuscript.js';
const authorSettings: Configuration = { limits: { maxFindings: 100 }, thresholds: { maxGrade: 16 }, suppressions: [{ ruleId: 'NL-PROSE-LEXICON', reason: 'Narrator diction' }] };
const chronologyHint: Scene = { id: 'unplaced', text: 'A clock stopped.', chronologyLane: 'dream' };
const requiredDefault: number = defaultManuscriptConfiguration().limits.nliPairs;
const knownCatalogId: RuleId = listManuscriptRules()[0]!.id;
const importedReport: Report = parseManuscriptReport({});
const countWarnings: number | undefined = manuscriptReport.summary.severityCounts.warning;
// @ts-expect-error Unknown limits are rejected by the generated contract.
const invalidLimits: Configuration = { limits: { typo: 4 } };
void [authorSettings, chronologyHint, requiredDefault, knownCatalogId, importedReport, countWarnings, invalidLimits];

import { trackWorldState, buildPromisePayoffLedger } from '../../index.js';
import type { WorldFact, PayoffStatus } from '../../standalone.generated.js';
const currentFact = trackWorldState(['Alice was in the cellar.'], ['Alice']).snapshots[0]!.facts[0]!;
if ('characterAt' in currentFact) {
  const location: string = currentFact.characterAt.location;
  void location;
}
const worldVariants: WorldFact[] = [
  { characterAt: { character: 'Alice', location: 'cellar' } },
  { characterPossesses: { character: 'Alice', object: 'key' } },
  { characterKnows: { character: 'Alice', information: 'the key is gone' } },
  { characterWitnessed: { character: 'Alice', event: 'the key vanished' } },
  { coLocated: { character_a: 'Alice', character_b: 'Bob' } },
  { communicationVector: { from: 'Alice', to: 'Bob', content: 'the key is gone' } },
  { objectAt: { object: 'key', location: 'cellar' } },
  { physicalConstraint: { character: 'Alice', constraint: 'locked in' } },
  { temporalOrdering: { before: 'arrival', after: 'departure' } },
];
const payoffVariants: PayoffStatus[] = ['unknown', 'confirmedFulfilled', 'outstanding',
  { fulfilled: { quality: 0.8 } }, { partiallyFulfilled: { completeness: 0.5 } },
  'broken', { subverted: { satisfaction: 0.8 } }, { overpaid: { excess: 0.2 } },
  { deferred: { new_deadline: null } }];
const payoff: PayoffStatus | undefined = buildPromisePayoffLedger(['Who stole the key?'], [5], 'general', [], [], 'three_act', 1).promises[0]?.status;
const comparisonComplete: boolean = compareManuscriptReports(manuscriptReport, contextReport).complete;
// @ts-expect-error serde emits camelCase variant tags, not Rust variant names.
const oldWorldTag: WorldFact = { CharacterAt: { character: 'Alice', location: 'cellar' } };
// @ts-expect-error Unit payoff variants are serialized as camelCase strings.
const oldPayoffTag: PayoffStatus = 'Outstanding';
void [worldVariants, payoffVariants, payoff, comparisonComplete, oldWorldTag, oldPayoffTag];

import { analyzePromiseEvents, analyzeSmog } from '../../index.js';
import type { AuthorPromiseEvent } from '../../standalone.generated.js';
const authored: AuthorPromiseEvent[] = [{kind:'setup',id:'question',description:'The missing key',evidence:{sceneId:'opening',utf16Start:0,utf16End:3,quote:'She'}}];
const authoredId: string | undefined = analyzePromiseEvents(manuscriptInput,authored).promises[0]?.id;
const smogGrade: number | null = analyzeSmog('Tomorrow.').grade;
const smogAvailable: boolean = computeReadability('Tomorrow.').smogAvailable;
// @ts-expect-error Author resolution references are required, not inferred from description.
const missingSetup: AuthorPromiseEvent = {kind:'resolution',id:'payoff',outcome:'fulfilled',evidence:{sceneId:'opening',utf16Start:0,utf16End:3,quote:'She'}};
void [authoredId,smogGrade,smogAvailable,missingSetup];

import { analyzeAuthorKnowledge, trackWorldStateCurrent } from '../../index.js';
import type { AuthorProposition, AuthorKnowledgeEvent, AuthorKnowledgeClassification } from '../../standalone.generated.js';
const proposition: AuthorProposition = {id:'key',description:'The key is hidden',truth:'unknown',evidence:{sceneId:'opening',utf16Start:0,utf16End:3,quote:'She'}};
const knowledgeEvent: AuthorKnowledgeEvent = {id:'reader',sequence:1,propositionId:'key',action:{kind:'uncertain',actor:{kind:'reader'}},evidence:proposition.evidence};
const classification: AuthorKnowledgeClassification | undefined = analyzeAuthorKnowledge(manuscriptInput,[proposition],[knowledgeEvent]).states[0]?.classification;
const lastWorldScene: number | null = trackWorldStateCurrent([],[],{includeDeltas:true}).afterScene;
// @ts-expect-error Actor tags separate reader from a named character.
const missingCharacterId: AuthorKnowledgeEvent = {...knowledgeEvent,action:{kind:'believe',actor:{kind:'character'},value:true}};
// @ts-expect-error Ground truth is tri-state, not an unqualified boolean.
const ambiguousTruth: AuthorProposition = {...proposition,truth:true};
// @ts-expect-error Compact world-state options retain boolean types.
trackWorldStateCurrent([],[],{includeDeltas:'yes'});
void [classification,lastWorldScene,missingCharacterId,ambiguousTruth];
