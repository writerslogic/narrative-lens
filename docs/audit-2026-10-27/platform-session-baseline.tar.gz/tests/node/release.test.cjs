const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

test('release preflight rejects missing targets, empty binaries and wrong package identity', async () => {
  const { verifyArtifacts } = await import('../../scripts/release_artifacts.mjs');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'narrative-lens-release-'));
  const target = 'aarch64-apple-darwin';
  try {
    fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ name: 'narrative-lens', version: '0.1.0', napi: { binaryName: 'narrative-lens', targets: [target] } }));
    assert.throws(() => verifyArtifacts(root, [target]), /ENOENT/);
    const directory = path.join(root, 'npm', 'darwin-arm64');
    fs.mkdirSync(directory, { recursive: true });
    const metadata = { name: 'narrative-lens-darwin-arm64', version: '0.1.0', os: ['darwin'], cpu: ['arm64'] };
    const manifest = path.join(directory, 'package.json');
    fs.writeFileSync(manifest, JSON.stringify(metadata));
    fs.writeFileSync(path.join(directory, 'narrative-lens.darwin-arm64.node'), '');
    assert.throws(() => verifyArtifacts(root, [target]), /empty native artifact/);
    metadata.version = '0.0.0';
    fs.writeFileSync(manifest, JSON.stringify(metadata));
    assert.throws(() => verifyArtifacts(root, [target]), /metadata/);
    assert.throws(() => verifyArtifacts(root, [target, target]), /unique/);
    assert.throws(() => verifyArtifacts(root, ['../../unconfigured']), /unconfigured/);
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
});

test('publication rejects artifacts and package code changed after installation tests', async () => {
  const { digest, packagePayload } = await import('../../scripts/release_artifacts.mjs');
  const { verifyTestedArtifacts } = await import('../../scripts/verify_tested_artifacts.mjs');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'narrative-lens-tested-'));
  const target = 'aarch64-apple-darwin';
  try {
    fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ name: 'narrative-lens', version: '0.1.0', files: ['index.js'], napi: { binaryName: 'narrative-lens', targets: [target] } }));
    for (const file of ['index.js', 'README.md', 'LICENSE']) fs.writeFileSync(path.join(root, file), 'original\n');
    const platform = path.join(root, 'npm', 'darwin-arm64');
    fs.mkdirSync(platform, { recursive: true });
    fs.writeFileSync(path.join(platform, 'package.json'), JSON.stringify({ name: 'narrative-lens-darwin-arm64', version: '0.1.0', os: ['darwin'], cpu: ['arm64'] }));
    const binary = path.join(platform, 'narrative-lens.darwin-arm64.node');
    fs.writeFileSync(binary, 'tested binary');
    const tested = path.join(root, 'tested');
    fs.mkdirSync(path.join(tested, `packages-${target}`), { recursive: true });
    fs.writeFileSync(path.join(tested, `packages-${target}`, 'manifest.json'), JSON.stringify({ target, version: '0.1.0', nativeSha256: digest(binary), payload: packagePayload(root) }));
    assert.equal(verifyTestedArtifacts(root, tested), 1);
    fs.writeFileSync(path.join(root, 'index.js'), 'original\r\n');
    assert.equal(verifyTestedArtifacts(root, tested), 1);
    fs.writeFileSync(path.join(root, 'index.js'), 'changed\n');
    assert.throws(() => verifyTestedArtifacts(root, tested), /release payload differs/);
    fs.writeFileSync(path.join(root, 'index.js'), 'original\n');
    fs.writeFileSync(binary, 'changed binary');
    assert.throws(() => verifyTestedArtifacts(root, tested), /release binary differs/);
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
});

test('native packages must bundle unchanged third-party notices', async () => {
  const { stageNotices, verifyArtifacts } = await import('../../scripts/release_artifacts.mjs');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'narrative-lens-notices-'));
  const target = 'aarch64-apple-darwin';
  try {
    fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({name:'narrative-lens',version:'0.1.0',files:['THIRD_PARTY_NOTICES'],napi:{binaryName:'narrative-lens',targets:[target]}}));
    fs.writeFileSync(path.join(root, 'THIRD_PARTY_NOTICES'), 'Resource copyright and license\n');
    const platform = path.join(root,'npm','darwin-arm64');
    fs.mkdirSync(platform,{recursive:true});
    fs.writeFileSync(path.join(platform,'package.json'),JSON.stringify({name:'narrative-lens-darwin-arm64',version:'0.1.0',os:['darwin'],cpu:['arm64'],files:['narrative-lens.darwin-arm64.node']}));
    fs.writeFileSync(path.join(platform,'narrative-lens.darwin-arm64.node'),'binary');
    assert.throws(()=>verifyArtifacts(root,[target]),/notices/);
    stageNotices(root,[target]);
    assert.equal(verifyArtifacts(root,[target]).length,1);
    fs.writeFileSync(path.join(platform,'THIRD_PARTY_NOTICES'),'changed');
    assert.throws(()=>verifyArtifacts(root,[target]),/notices/);
  } finally { fs.rmSync(root,{recursive:true,force:true}); }
});
