use std::collections::{BTreeMap, BTreeSet};
use std::sync::OnceLock;

use regex::Regex;
use serde::{Deserialize, Serialize};

use super::{DialogueLine, speech_verbs};
use crate::{
    Error, Result,
    manuscript::TextRange,
    substrate::{offsets::OffsetIndex, utils::AnalysisAvailability},
};

const MAX_TEXT_BYTES: usize = 16 * 1024 * 1024;
const MAX_LINES: usize = 10_000;
const MAX_DEPTH: usize = 32;
const TAG_WINDOW: usize = 512;
const NAME_WINDOW: usize = 256;

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DialogueAttributionMode {
    #[default]
    ExplicitOnly,
    ConservativeHeuristic,
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct DialogueExtractionOptions {
    #[serde(default)]
    pub attribution: DialogueAttributionMode,
    #[serde(default)]
    pub include_indirect: bool,
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DialogueKind {
    Direct,
    Indirect,
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LocatedDialogueLine {
    pub line: DialogueLine,
    /// Selects the exact original line.quote; delimiters and outside whitespace are excluded.
    pub range: TextRange,
    pub quotation_range: Option<TextRange>,
    pub attribution_range: Option<TextRange>,
    pub kind: DialogueKind,
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DialogueExtractionResult {
    pub availability: AnalysisAvailability,
    pub diagnostics: Vec<String>,
    pub lines: Vec<LocatedDialogueLine>,
}

fn invalid(message: &str) -> Error {
    Error::InvalidInput(message.into())
}

fn word_char(ch: char) -> bool {
    if ch.is_alphanumeric() || ch == '_' {
        return true;
    }
    if ch.is_ascii() {
        return false;
    }
    static WORD: OnceLock<Regex> = OnceLock::new();
    let mut bytes = [0; 4];
    WORD.get_or_init(|| Regex::new(r"^\w$").expect("static word class"))
        .is_match(ch.encode_utf8(&mut bytes))
}
fn name_char(ch: char) -> bool {
    word_char(ch) || matches!(ch, '\'' | '’' | '-')
}
fn normalize_name(text: &str) -> String {
    text.split_whitespace()
        .map(|part| part.replace('’', "'").to_lowercase())
        .collect::<Vec<_>>()
        .join(" ")
}

#[derive(Default)]
struct NameNode {
    children: BTreeMap<char, usize>,
    terminal: Option<Option<String>>,
}
struct Names {
    forward: Vec<NameNode>,
    backward: Vec<NameNode>,
}
struct NameMatch {
    speaker: Option<String>,
    start: usize,
    end: usize,
}

impl Names {
    fn new(cast: &[String]) -> Self {
        let mut full = BTreeMap::<String, String>::new();
        for name in cast {
            full.entry(normalize_name(name))
                .and_modify(|value| {
                    if name < value {
                        *value = name.clone();
                    }
                })
                .or_insert_with(|| name.clone());
        }
        let mut aliases = BTreeMap::<String, BTreeSet<String>>::new();
        for (key, canonical) in &full {
            aliases
                .entry(key.clone())
                .or_default()
                .insert(canonical.clone());
            let parts: Vec<_> = key.split_whitespace().collect();
            for short in [parts.first().copied(), parts.last().copied()]
                .into_iter()
                .flatten()
            {
                if !full.contains_key(short)
                    && !["mr.", "mrs.", "ms.", "dr.", "sir", "lady", "lord"].contains(&short)
                {
                    aliases
                        .entry(short.into())
                        .or_default()
                        .insert(canonical.clone());
                }
            }
        }
        let mut names = Self {
            forward: vec![NameNode::default()],
            backward: vec![NameNode::default()],
        };
        for (alias, identities) in aliases {
            let terminal = if identities.len() == 1 {
                identities.into_iter().next()
            } else {
                None
            };
            Self::insert(&mut names.forward, alias.chars(), terminal.clone());
            Self::insert(&mut names.backward, alias.chars().rev(), terminal);
        }
        names
    }
    fn insert(
        nodes: &mut Vec<NameNode>,
        chars: impl Iterator<Item = char>,
        terminal: Option<String>,
    ) {
        let mut node = 0;
        for ch in chars {
            node = if let Some(&child) = nodes[node].children.get(&ch) {
                child
            } else {
                let child = nodes.len();
                nodes.push(NameNode::default());
                nodes[node].children.insert(ch, child);
                child
            };
        }
        nodes[node].terminal = Some(terminal);
    }
    fn prefix(&self, text: &str) -> Option<NameMatch> {
        let trimmed = text.trim_start();
        let base = text.len() - trimmed.len();
        let mut node = 0;
        let mut space = false;
        let mut best = None;
        for (position, ch) in trimmed.char_indices() {
            if position > NAME_WINDOW {
                break;
            }
            let mapped = if ch.is_whitespace() {
                if space {
                    continue;
                }
                space = true;
                ' '
            } else {
                space = false;
                if ch == '’' { '\'' } else { ch }
            };
            for unit in mapped.to_lowercase() {
                let Some(&next) = self.forward[node].children.get(&unit) else {
                    return best;
                };
                node = next;
            }
            let end = base + position + ch.len_utf8();
            if text[end..]
                .chars()
                .next()
                .is_none_or(|next| !name_char(next))
                && let Some(identity) = &self.forward[node].terminal
            {
                best = Some(NameMatch {
                    speaker: identity.clone(),
                    start: base,
                    end,
                });
            }
        }
        best
    }
    fn suffix(&self, text: &str) -> Option<NameMatch> {
        let trimmed = text.trim_end();
        let mut node = 0;
        let mut space = false;
        let mut best = None;
        for (position, ch) in trimmed.char_indices().rev() {
            if trimmed.len() - position > NAME_WINDOW {
                break;
            }
            let mapped = if ch.is_whitespace() {
                if space {
                    continue;
                }
                space = true;
                ' '
            } else {
                space = false;
                if ch == '’' { '\'' } else { ch }
            };
            for unit in mapped.to_lowercase().rev() {
                let Some(&next) = self.backward[node].children.get(&unit) else {
                    return best;
                };
                node = next;
            }
            if trimmed[..position]
                .chars()
                .next_back()
                .is_none_or(|previous| !name_char(previous))
                && let Some(identity) = &self.backward[node].terminal
            {
                best = Some(NameMatch {
                    speaker: identity.clone(),
                    start: position,
                    end: trimmed.len(),
                });
            }
        }
        best
    }
    fn in_text(&self, text: &str) -> BTreeSet<String> {
        let mut found = BTreeSet::new();
        for (position, ch) in text.char_indices() {
            if word_char(ch)
                && text[..position]
                    .chars()
                    .next_back()
                    .is_none_or(|previous| !name_char(previous))
                && let Some(name) = self.prefix(&text[position..])
                && let Some(identity) = name.speaker
            {
                found.insert(identity);
            }
        }
        found
    }
}

#[derive(Clone, Copy)]
struct Quote {
    start: usize,
    end: usize,
    content_start: usize,
    content_end: usize,
}
struct Frame {
    opening: char,
    closing: char,
    start: usize,
    content_start: usize,
}

fn scan_quotes(text: &str) -> Result<(Vec<Quote>, Vec<String>)> {
    let mut quotes = Vec::new();
    let mut stack = Vec::<Frame>::new();
    let mut chars = text.char_indices().peekable();
    let mut previous = None;
    let mut slashes = 0;
    let mut line_start = true;
    let mut malformed = false;
    while let Some((position, ch)) = chars.next() {
        let next = chars.peek().map(|(_, ch)| *ch);
        let apostrophe = matches!(ch, '\'' | '‘' | '’')
            && previous.is_some_and(word_char)
            && next.is_some_and(word_char);
        let escaped = slashes % 2 == 1;
        let continuation = stack.len() == 1
            && stack[0].opening == ch
            && line_start
            && text[position + ch.len_utf8()..]
                .chars()
                .find(|c| !c.is_whitespace())
                .is_some_and(word_char);
        if !escaped && !apostrophe && !continuation {
            if stack.last().is_some_and(|frame| frame.closing == ch) {
                let frame = stack.pop().expect("closing frame exists");
                if stack.is_empty() {
                    let content = &text[frame.content_start..position];
                    let trimmed = content.trim();
                    if !trimmed.is_empty() {
                        let start =
                            frame.content_start + content.len() - content.trim_start().len();
                        quotes.push(Quote {
                            start: frame.start,
                            end: position + ch.len_utf8(),
                            content_start: start,
                            content_end: start + trimmed.len(),
                        });
                        if quotes.len() > MAX_LINES {
                            return Err(invalid("dialogue line count exceeds 10000"));
                        }
                    }
                }
            } else {
                let closing = match ch {
                    '“' => Some('”'),
                    '‘' => Some('’'),
                    '"' => Some('"'),
                    '\'' => Some('\''),
                    _ => None,
                };
                if let Some(closing) = closing {
                    if matches!(ch, '\'' | '"') && previous.is_some_and(word_char) { /* possessives/inch marks are not opening delimiters */
                    } else {
                        if stack.len() == MAX_DEPTH {
                            return Err(invalid("dialogue quote nesting exceeds 32"));
                        }
                        stack.push(Frame {
                            opening: ch,
                            closing,
                            start: position,
                            content_start: position + ch.len_utf8(),
                        });
                    }
                } else if matches!(ch, '”' | '’') && !previous.is_some_and(word_char) {
                    malformed = true;
                }
            }
        }
        if matches!(ch, '\n' | '\r') {
            line_start = true;
        } else if !ch.is_whitespace() {
            line_start = false;
        }
        slashes = if ch == '\\' { slashes + 1 } else { 0 };
        previous = Some(ch);
    }
    let diagnostics = if malformed || !stack.is_empty() {
        vec!["unbalanced_quote_delimiters".into()]
    } else {
        Vec::new()
    };
    Ok((quotes, diagnostics))
}

fn words(text: &str) -> Vec<(usize, usize)> {
    let mut found = Vec::new();
    let mut start = None;
    for (position, ch) in text.char_indices() {
        if word_char(ch) {
            start.get_or_insert(position);
        } else if let Some(begin) = start.take() {
            found.push((begin, position));
        }
    }
    if let Some(begin) = start {
        found.push((begin, text.len()));
    }
    found
}
fn verb_at(text: &str) -> Option<(usize, usize, String)> {
    let trimmed = text.trim_start();
    let base = text.len() - trimmed.len();
    let end = trimmed
        .char_indices()
        .find(|(_, ch)| !word_char(*ch))
        .map_or(trimmed.len(), |(i, _)| i);
    if end == 0 {
        return None;
    }
    let word = trimmed[..end].to_lowercase();
    if speech_verbs().contains(word.as_str()) {
        Some((base, base + end, word))
    } else if word.ends_with("ly") {
        verb_at_no_adverb(&text[base + end..]).map(|(a, b, v)| (base + end + a, base + end + b, v))
    } else {
        None
    }
}
fn verb_at_no_adverb(text: &str) -> Option<(usize, usize, String)> {
    let trimmed = text.trim_start();
    let base = text.len() - trimmed.len();
    let end = trimmed
        .char_indices()
        .find(|(_, ch)| !word_char(*ch))
        .map_or(trimmed.len(), |(i, _)| i);
    let word = trimmed[..end].to_lowercase();
    speech_verbs()
        .contains(word.as_str())
        .then_some((base, base + end, word))
}

struct Tag {
    speaker: Option<String>,
    verb: String,
    start: usize,
    end: usize,
}
fn after_tag(text: &str, names: &Names) -> Option<Tag> {
    let clean = text.trim_start_matches(|ch: char| ch.is_whitespace() || matches!(ch, ',' | ':'));
    let base = text.len() - clean.len();
    if let Some(name) = names.prefix(clean)
        && let Some((_, end, verb)) = verb_at(&clean[name.end..])
    {
        return Some(Tag {
            speaker: name.speaker,
            verb,
            start: base + name.start,
            end: base + name.end + end,
        });
    }
    if let Some((start, end, verb)) = verb_at_no_adverb(clean)
        && start == 0
    {
        let mut remainder = &clean[end..];
        let mut offset = end;
        if let Some((a, b)) = words(remainder).first().copied()
            && remainder[a..b].to_lowercase().ends_with("ly")
        {
            offset += b;
            remainder = &clean[offset..];
        }
        if let Some(name) = names.prefix(remainder) {
            return Some(Tag {
                speaker: name.speaker,
                verb,
                start: base,
                end: base + offset + name.end,
            });
        }
        return Some(Tag {
            speaker: None,
            verb,
            start: base,
            end: base + end,
        });
    }
    for (a, b) in words(clean).into_iter().take(8) {
        let verb = clean[a..b].to_lowercase();
        if speech_verbs().contains(verb.as_str()) {
            return Some(Tag {
                speaker: None,
                verb,
                start: base,
                end: base + b,
            });
        }
        if clean[..a].contains(['.', ';', '!', '?', '\n', '\r']) {
            break;
        }
    }
    None
}
fn before_tag(text: &str, names: &Names) -> Option<Tag> {
    let clean = text.trim_end_matches(|ch: char| {
        ch.is_whitespace() || matches!(ch, ',' | ':' | '.' | '!' | '?' | ';')
    });
    for (a, b) in words(clean).into_iter().rev() {
        let verb = clean[a..b].to_lowercase();
        if !speech_verbs().contains(verb.as_str()) {
            continue;
        }
        let tail = clean[b..].trim();
        let tail_words: Vec<_> = tail.split_whitespace().collect();
        let allowed = tail.is_empty()
            || tail_words.len() == 1 && tail_words[0].ends_with("ly")
            || tail_words
                .first()
                .is_some_and(|word| word.eq_ignore_ascii_case("to"))
                && tail_words.len() >= 2
                && !tail.contains(['.', ';', '!', '?'])
            || tail.eq_ignore_ascii_case("that");
        if !allowed {
            continue;
        }
        let mut subject = &clean[..a];
        if let Some((adverb_start, adverb_end)) = words(subject).last().copied()
            && subject[adverb_start..adverb_end]
                .to_lowercase()
                .ends_with("ly")
        {
            subject = &subject[..adverb_start];
        }
        if let Some(name) = names.suffix(subject) {
            return Some(Tag {
                speaker: name.speaker,
                verb,
                start: name.start,
                end: b,
            });
        }
        if !subject.trim().is_empty() {
            return Some(Tag {
                speaker: None,
                verb,
                start: 0,
                end: b,
            });
        }
    }
    if let Some(name) = names.suffix(clean) {
        let prefix = clean[..name.start].trim_end();
        if let Some((a, b)) = words(prefix).last().copied() {
            let verb = prefix[a..b].to_lowercase();
            if speech_verbs().contains(verb.as_str()) {
                return Some(Tag {
                    speaker: name.speaker,
                    verb,
                    start: a,
                    end: name.end,
                });
            }
        }
    }
    None
}

fn continuation_tail(text: &str) -> bool {
    let trimmed = text.trim();
    if trimmed.contains(',') && trimmed.chars().all(|ch| ch == ',' || ch.is_whitespace()) {
        return true;
    }
    let Some(recipient) = trimmed
        .strip_suffix(',')
        .and_then(|value| value.trim().strip_prefix("to "))
    else {
        return false;
    };
    !recipient.contains([',', '.', ';', '!', '?'])
        && (1..=4).contains(&recipient.split_whitespace().count())
}

fn lower_boundary(text: &str, mut position: usize) -> usize {
    while !text.is_char_boundary(position) {
        position += 1;
    }
    position
}
fn upper_boundary(text: &str, mut position: usize) -> usize {
    while !text.is_char_boundary(position) {
        position -= 1;
    }
    position
}
fn range(index: &OffsetIndex<'_>, start: usize, end: usize) -> TextRange {
    TextRange {
        byte_start: start,
        byte_end: end,
        utf16_start: index.utf16(start).expect("original boundary"),
        utf16_end: index.utf16(end).expect("original boundary"),
    }
}

/// Extract paired quotation candidates and explicit grammatical speakers. Rule
/// weights in legacy confidence are not calibrated attribution probabilities.
/// Unquoted speech and speech-versus-title semantics are not inferred.
pub fn extract_dialogue_checked(
    text: &str,
    scene_id: usize,
    cast: &[String],
    options: &DialogueExtractionOptions,
) -> Result<DialogueExtractionResult> {
    if text.len() > MAX_TEXT_BYTES || cast.len() > 256 {
        return Err(invalid("dialogue exceeds 16 MiB or 256 characters"));
    }
    for name in cast {
        crate::manuscript::config::validate_name(name)?;
    }
    let names = Names::new(cast);
    let (quotes, mut diagnostics) = scan_quotes(text)?;
    let mut offsets = if quotes.is_empty() {
        None
    } else {
        Some(OffsetIndex::new(text)?)
    };
    let mut lines = Vec::new();
    let mut recent = Vec::<String>::new();
    let mut previous_speaker = None;
    let mut previous_after = None::<(usize, usize)>;
    for (position, quote) in quotes.iter().enumerate() {
        let index = offsets.as_ref().expect("quoted source index");
        let lo =
            lower_boundary(text, quote.start.saturating_sub(TAG_WINDOW)).max(if position == 0 {
                0
            } else {
                quotes[position - 1].end
            });
        let hi = upper_boundary(text, (quote.end + TAG_WINDOW).min(text.len()))
            .min(quotes.get(position + 1).map_or(text.len(), |q| q.start));
        let before = &text[lo..quote.start];
        let after = &text[quote.end..hi];
        let mut pre = before_tag(before, &names);
        if let Some(tag) = &mut pre {
            tag.start += lo;
            tag.end += lo;
        }
        let mut post = after_tag(after, &names);
        if let Some(tag) = &mut post {
            tag.start += quote.end;
            tag.end += quote.end;
        }
        let prior_after = previous_after;
        if pre.as_ref().is_some_and(|tag| {
            prior_after == Some((tag.start, tag.end))
                && !continuation_tail(&text[tag.end..quote.start])
        }) {
            pre = None;
        }
        previous_after = post.as_ref().map(|tag| (tag.start, tag.end));
        let unresolved = pre.as_ref().is_some_and(|tag| tag.speaker.is_none())
            || post.as_ref().is_some_and(|tag| tag.speaker.is_none());
        let conflict = matches!((&pre,&post), (Some(a),Some(b)) if a.speaker.is_some() && b.speaker.is_some() && a.speaker != b.speaker);
        let chosen = if unresolved || conflict {
            None
        } else {
            post.as_ref().or(pre.as_ref())
        };
        let mut speaker = "Unknown".to_string();
        let mut confidence = 0.0;
        let mut method = "unknown".to_string();
        let mut tag_verb = None;
        let mut attribution = None;
        if let Some(tag) = chosen {
            speaker = tag.speaker.clone().expect("resolved tag");
            confidence = if post.is_some() { 0.95 } else { 0.9 };
            method = "explicit_tag".into();
            tag_verb = Some(tag.verb.clone());
            attribution = Some(range(index, tag.start, tag.end));
        } else if options.attribution == DialogueAttributionMode::ConservativeHeuristic
            && !unresolved
            && !conflict
        {
            let proximity_before = if prior_after.is_some() {
                before
                    .rfind(['.', '!', '?', '\n', '\r'])
                    .map_or("", |position| &before[position + 1..])
            } else {
                before
            };
            let mut candidates = names.in_text(proximity_before);
            candidates.extend(names.in_text(after));
            if candidates.len() == 1 {
                speaker = candidates.into_iter().next().expect("one candidate");
                confidence = 0.65;
                method = "proximity".into();
            } else if candidates.is_empty()
                && recent.len() == 2
                && let Some(previous) = &previous_speaker
                && let Some(other) = recent.iter().find(|name| *name != previous)
            {
                speaker = other.clone();
                confidence = 0.45;
                method = "pattern".into();
            }
        }
        if speaker != "Unknown" {
            previous_speaker = Some(speaker.clone());
            if !recent.contains(&speaker) {
                recent.push(speaker.clone());
                if recent.len() > 2 {
                    recent.remove(0);
                }
            }
        }
        lines.push(LocatedDialogueLine {
            line: DialogueLine {
                scene_id,
                quote: text[quote.content_start..quote.content_end].into(),
                speaker,
                confidence,
                method,
                tag_verb,
            },
            range: range(index, quote.content_start, quote.content_end),
            quotation_range: Some(range(index, quote.start, quote.end)),
            attribution_range: attribution,
            kind: DialogueKind::Direct,
        });
        if conflict {
            diagnostics.push("conflicting_adjacent_speech_tags".into());
        }
        if unresolved {
            diagnostics.push("unresolved_adjacent_speech_tag".into());
        }
    }
    if options.include_indirect {
        let mut quote_position = 0;
        for (begin, end) in crate::substrate::utils::sentence_spans(text) {
            let sentence = &text[begin..end];
            for (a, ch) in sentence.char_indices() {
                if !word_char(ch) || sentence[..a].chars().next_back().is_some_and(name_char) {
                    continue;
                }
                let start = begin + a;
                while quotes.get(quote_position).is_some_and(|q| q.end <= start) {
                    quote_position += 1;
                }
                if quotes.get(quote_position).is_some_and(|q| q.start <= start) {
                    continue;
                }
                let Some(actor) = names.prefix(&text[start..end]) else {
                    continue;
                };
                let Some(speaker) = actor.speaker else {
                    continue;
                };
                let rest = &text[start + actor.end..end];
                let tokens = words(rest);
                let Some(&(vstart, vend)) = tokens.first() else {
                    continue;
                };
                if !rest[..vstart].trim().is_empty() {
                    continue;
                }
                let verb = rest[vstart..vend].to_lowercase();
                if ![
                    "told",
                    "informed",
                    "explained",
                    "mentioned",
                    "reminded",
                    "assured",
                    "convinced",
                    "warned",
                    "said",
                    "whispered",
                ]
                .contains(&verb.as_str())
                {
                    continue;
                }
                let complement = &rest[vend..];
                let lowered = complement.to_lowercase();
                if ![" that ", " about "]
                    .iter()
                    .any(|marker| format!(" {} ", lowered.trim()).contains(marker))
                {
                    continue;
                }
                let content_end = quotes
                    .get(quote_position)
                    .filter(|q| q.start > start && q.start < end)
                    .map_or(end, |q| q.start);
                let original = text[start..content_end].trim_end();
                if original.len() <= actor.end + vend {
                    continue;
                }
                let stop = start + original.len();
                if offsets.is_none() {
                    offsets = Some(OffsetIndex::new(text)?);
                }
                let index = offsets.as_ref().expect("reported source index");
                lines.push(LocatedDialogueLine {
                    line: DialogueLine {
                        scene_id,
                        quote: text[start..stop].into(),
                        speaker,
                        confidence: 0.8,
                        method: "indirect_speech".into(),
                        tag_verb: Some(verb),
                    },
                    range: range(index, start, stop),
                    quotation_range: None,
                    attribution_range: Some(range(index, start, start + actor.end + vend)),
                    kind: DialogueKind::Indirect,
                });
                if lines.len() > MAX_LINES {
                    return Err(invalid("dialogue line count exceeds 10000"));
                }
                break;
            }
        }
    }
    lines.sort_by_key(|line| (line.range.byte_start, line.range.byte_end));
    if lines.iter().any(|line| line.line.speaker == "Unknown") {
        diagnostics.push("speaker_attribution_incomplete".into());
    }
    if lines.iter().any(|line| {
        matches!(
            line.line.method.as_str(),
            "proximity" | "pattern" | "continuation"
        )
    }) {
        diagnostics.push("heuristic_speakers_unverified".into());
    }
    let partial = !diagnostics.is_empty();
    diagnostics.push("quotation_candidates_are_not_verified_spoken_events".into());
    diagnostics.push("confidence_values_are_uncalibrated_rule_weights".into());
    diagnostics.sort();
    diagnostics.dedup();
    Ok(DialogueExtractionResult {
        availability: if partial {
            AnalysisAvailability::Partial
        } else {
            AnalysisAvailability::Complete
        },
        diagnostics,
        lines,
    })
}
