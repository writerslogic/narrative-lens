# Accuracy and performance evaluation

The fixtures and labels are **agent-authored engineering cases, with no human
editorial validation**. They test supported patterns, controls, and false-positive
regressions. Related templates and repeated evaluation prevent claims of
independent editorial accuracy or generalization to published novels. Original
fiction was written for the repository; no published passages were copied.

Dale–Chall now uses the complete pinned 2942-entry upstream
[MIT word list](https://github.com/words/dale-chall/tree/cc171e5a515ef67818fa17308dfceff38a21efa4).
Provenance, transformation and hashes are in [resource metadata](readability-resources.json);
`uv run --no-project scripts/verify_readability_resources.py` verifies them offline.
This is not an independent reconstruction of the printed 1995 list; inflections
and proper names receive no special expansion.

SMOG uses [McLaughlin (1969), equation (d), page 643](https://ogg.osu.edu/media/documents/health_lit/WRRSMOG_Readability_Formula_G._Harry_McLaughlin__1969_.pdf)
over three disjoint ten-sentence blocks at the beginning, center and end.
`readability::analyze_smog` / Node `analyzeSmog` returns the selected byte ranges,
polysyllable count and a nullable grade; fewer than 30 complete word-bearing sentences is
unavailable. Legacy `computeReadability` retains numeric zero for that case and
exposes `smogAvailable: false`. Syllables and sentence boundaries remain English
heuristics; spoken numerals/abbreviations are not expanded. These engineering
checks do not validate reading comprehension on a human population.

## Finding-level evaluation

`tests/fixtures/evaluation-v2.json` (version `finding-level-fiction-v2.1`) contains
52 cases, 26 calibration and 26 held-out, with original UTF-8/UTF-16 source spans,
related contradictory quotations, rule IDs, rationale, origin and text hashes.
Nonempty complete texts are disjoint. Empty input is an unscored boundary case
in both splits. Genres in this set include mystery and science fiction; the
older corpus also covers fantasy, thriller, romance, literary, horror and
historical fiction. Cases cover errors, clean prose, duplicate occurrences,
Unicode, author dictionaries, deliberate repetition/dialect/dense prose/long
sentences, cyclical structure, supernatural exceptions, transfers and releases.

```sh
uv run --no-project scripts/verify_fixtures.py
cargo run --example evaluate_findings > measured.json
cargo test --test evaluation_findings
```

The harness matches individual findings one-to-one by rule, scene, exact primary
quotation and original coordinates. Related evidence must cover the labeled
conflicting text; separate conflict/constraint spans can cover a combined labeled
passage, ignoring whitespace gaps. Missing one member of a duplicate pair counts
as a miss. Aggregate annotations match explicit scope and beat identity rather
than inventing pinpoint locations. Every emitted quote is checked against the
original manuscript.

Metrics are reported per rule and split: TP/FP/FN, precision/recall, clean cases
flagged, unrated predictions, Brier score and confidence bins. Calibration uses
only calibration labels: four fixed score bins per rule, Laplace precision
`(correct + 1)/(count + 2)`, with unseen bins left uncalibrated. Scores are the
actual emitted heuristic values. Brier/reliability measures correctness among
rated emitted findings; it does not impute scores for absent findings. Recall
accounts for missed annotations separately. Missing output cannot improve the
regression gate by disappearing from confidence scoring.

The flat-structure cases label only the missing climax and explicitly mark other
beat predictions **unrated**: three per held-out case. Their precision describes
rated predictions, not all structural advice. No NLI accuracy is measured, and
capitalization is an adapter ID without a built-in detector. Standalone analyzer
families outside the facade are not covered by these accuracy figures.

The same harness also removes dictionary additions, corrections, intentions and
suppressions while retaining detector rules/thresholds. This author-controls
ablation separates the effect of supplied intent from a detector-only claim.
It exposes false positives that supported controls deliberately suppress.

[Current measured data](evaluation-v2-current.json) records all bins and both
ablation modes. On the 26 held-out cases there are 14 matched findings, zero
rated FP/FN, and three unrated structural predictions. The raw control ablation
adds false positives in six rule families. This small designed sample does not
justify a perfect-accuracy claim.

| Held-out rule | TP | Clean cases | Raw Brier | Calibration-only fit applied to held-out Brier |
| --- | ---: | ---: | ---: | ---: |
| Repetition | 4 | 3 | 0.0400 | 0.0278 |
| Whitespace | 1 | 5 | 0.0400 | 0.1111 |
| Dictionary absence | 1 | 1 | 0.2500 | 0.1111 |
| Author lexicon | 2 | 1 | 0.0400 | 0.0625 |
| Readability | 1 | 2 | 0.0400 | 0.1111 |
| Long-sentence average | 1 | 2 | 0.0400 | 0.1111 |
| Missing structure beat | 1 | 2 | 0.0400 | 0.1111 |
| Locked location | 1 | 2 | 0.0400 | 0.1111 |
| Eye attribute | 1 | 2 | 0.0400 | 0.1111 |
| Object location | 1 | 1 | 0.2500 | 0.1111 |

Calibration worsens several scores on this sample. It remains a diagnostic
experiment and is not installed into default library confidence. Confidence
provenance stays explicitly heuristic or model-based unless a caller identifies
its own calibration.

The [frozen finding-level baseline](evaluation-v2-baseline.json) records the
observed pre-normalization behavior, including the false conflict between grey
and gray eyes. Its original input is retained as
`tests/fixtures/evaluation-v2-baseline.json`. Provenance records that this earlier
corpus reused one short object assertion across splits; v2.1 replaces the held-out
text and retains the prior artifact. Neither corpus is a blind editorial study.

Regression gates preserve each baseline rule/split’s true positives, disallow
increased false positives, require zero missed supported annotations/clean-case
false positives, and allow at most 0.005 absolute Brier regression from the frozen
raw score. The small allowance supports minor score adjustments without hiding
a lost finding or permitting a large confidence change. Count gates are stricter
than rounded percentages on this tiny sample. Tests remove held-out labels and
verify the calibration fit remains unchanged. Hashes protect annotations and
baselines; changes require a recorded reason and updated provenance.

## Original analyzer-family baseline

The original 56-case `evaluation.json` and `evaluation-baseline.json` remain
reproducible with `cargo run --example evaluate -- --legacy`. The corresponding
facade result is `evaluation-current.json`; run `cargo run --example evaluate`
and `cargo test --test evaluation`. Each split contains 28 cases. This older
harness measures binary any-finding detection per analyzer family and uses a
fixed 0.8 comparison score for legacy confidence. It does not measure individual
finding accuracy; use the newer evaluation above for rule/occurrence and emitted
confidence measurements. Its broader genre coverage remains useful regression
input. Author controls explain part of the facade/legacy difference.

## Performance

Two deterministic novel-sized workloads exercise full and incremental analysis:

- `benchmark-novel-v1`: four existing fiction passages cycled into 160 scenes,
  repeating each passage 14 times (85,280 words, 474,880 UTF-8 bytes).
- `benchmark-novel-v2-xorshift32-20261027`: 160 scenes generated by
  `scripts/generate_benchmark.mjs` using a fixed xorshift32 seed, original sentence
  templates, Unicode names, varied vocabulary, and seeded cross-scene/mechanics
  findings. It is synthetic, not a natural novel or an editorial dataset.

```sh
mkdir -p target
node scripts/generate_benchmark.mjs > target/benchmark-novel-v2.json
cargo build --release --example benchmark_manuscript
# Resolve TARGET from cargo metadata --no-deps --format-version 1.
# macOS uses -l; Linux uses -v. Execute the built binary to exclude compilation.
/usr/bin/time -l TARGET/release/examples/benchmark_manuscript
/usr/bin/time -l TARGET/release/examples/benchmark_manuscript target/benchmark-novel-v2.json
npm run build:debug
NARRATIVE_LENS_ADDON_PROFILE='debug native addon; no ONNX models' node examples/benchmark-manuscript.mjs
NARRATIVE_LENS_ADDON_PROFILE='debug native addon; no ONNX models' node examples/benchmark-manuscript.mjs target/benchmark-novel-v2.json
```

Rust measures five samples each for cache-cleared full analysis, a single-scene
edit, and reordering. Input is reset identically before each sample. “Full” does
not reset process-wide regex/dictionary initialization and is not a process-cold
claim. Incremental output is asserted equal to a fresh result. Node uses the
same fixtures with a debug addon and reports input conversion, timers ticking
during async work, observed maximum timer gaps, latency and process RSS.

Retained cache estimates include cached payload/dependency metadata and differ
from whole-process peak RSS, which includes inputs, reports, temporary work,
loaded code and allocator behavior. Record the OS result separately from compiler
memory. Native fixtures are untrained local graphs for runtime contracts; no
language-model weights or remote services enter these measurements.

### Recorded benchmark results

Measurements were recorded on 2026-10-27 using an Apple M4 (arm64), 32 GiB RAM,
macOS 27.0, Rust 1.96.0 and Node 26.8.1. Both workloads contain 160 scenes and
use no model. Each operation has five samples. Fixture recipes and hashes are
recorded in [performance-fixtures.json](performance-fixtures.json).

| Rust release workload | Words / UTF-8 bytes | Full median | Scene edit median | Reorder median |
| --- | --- | ---: | ---: | ---: |
| Four-passage cycle | 85,280 / 474,880 | 406.59 ms | 22.43 ms | 1.47 ms |
| Varied templates | 104,455 / 571,260 | 58.26 ms | 12.53 ms | 0.42 ms |

Full analysis ranged from 404.15–423.43 ms and 58.10–70.77 ms respectively.
Retained cache estimates were 835,102 and 840,528 bytes against a 16 MiB budget;
whole-process peak RSS measured with `/usr/bin/time -l` was 68,091,904 and
73,842,688 bytes. Raw samples: [four-passage cycle](performance-rust.json) and
[varied templates](performance-rust-varied.json).

| Node debug-addon workload | Full median | Scene edit median | Minimum timer ticks, full / edit | Maximum timer gap | Peak RSS |
| --- | ---: | ---: | ---: | ---: | ---: |
| Four-passage cycle | 3,409.28 ms | 197.37 ms | 1,320 / 73 | 12.89 ms | 133,760 KiB |
| Varied templates | 833.16 ms | 112.36 ms | 331 / 44 | 4.16 ms | 140,000 KiB |

Full analysis ranged from 3,294.16–3,514.22 ms and 831.22–919.29 ms respectively.
Median input conversion took 0.31 and 0.93 ms. Raw samples:
[four-passage cycle](performance-node.json) and
[varied templates](performance-node-varied.json).

Timings apply to these workloads, profiles and machine. The differing results
show that word count alone does not predict latency. Node debug-addon and Rust
release timings use different build profiles. JS input conversion and result
materialization still run on the event loop. These measurements provide no
real-time guarantee or comparison with another product.

Release-blocker verification reran the varied workload in the same Rust release
profile: medians were 58.27 ms full, 12.59 ms edit, and 0.45 ms reorder, with final
incremental output equal to fresh analysis. These samples do not establish a
speed improvement over the recorded run. The release Node addon measured
59.97 ms full and 14.13 ms edit; its profile differs from the older debug-addon
measurements. See [Rust samples](audit-2026-10-27/remediation-performance-rust.json)
and [Node samples](audit-2026-10-27/remediation-performance-node.json).

### Spelling and corpus-embedding component measurements

The next component pass compares identical bounded workloads before/after the
indexed spelling and sparse PPMI changes, using Rust 1.96 release builds on the
same Apple M4. Medians below exclude compilation; MB means decimal megabytes
of additional live bytes requested through Rust's allocator, not process RSS.

| Workload | Before | After | Peak requested bytes before → after |
| --- | ---: | ---: | ---: |
| 20 warmed spelling queries | 11.91 ms | 0.181 ms | 13.0 KB → 4.5 KB |
| 2500 terms, 100 dimensions | 208.66 ms | 71.35 ms | 101.23 MB → 11.95 MB |
| 4096 terms, 100 dimensions | 632.16 ms | 120.35 ms | 270.45 MB → 19.54 MB |
| 1000 terms, mixed contexts | 40.01 ms | 39.91 ms | 16.50 MB → 5.46 MB |

The spelling trie adds about 1.09 MB retained dictionary data after its first
lookup (2 MiB transient peak). Its first query is slightly slower; subsequent
queries preserve the prior distance/frequency/lexical ranking against a scan
oracle. The 512-term embedding case is about 9% slower, while the 128-term exact
path preserves vectors byte-for-byte. Dense fallback remains for high occupancy
and near-full-rank requests. The large-space solver now alternates the matrix
and its transpose with QR reorthogonalization: smoothed PPMI is nonsymmetric.
It is deterministic within the tested build, with no claim of cross-platform
bitwise equality or general editorial accuracy.

Words and passages with zero learned vectors abstain from semantic rankings;
hybrid document search still retrieves exact terms through its lexical index.
Regression cases cover isolated vocabulary, mixed contextual/isolated documents,
and edits that remove a document's last supported context.

Run `cargo run --locked --release --example component_performance -- spelling 7`
or `-- embedding 2500 100 5`; `embedding-mixed` selects the denser corpus.
[Full comparisons and tradeoffs](audit-2026-10-27/component-performance-remediation.json)
retain all eight workloads, raw samples, semantic engineering checks, and the
independent matrix/transpose regression.

### Pinned pretrained-model parity

The optional `component_real_model` example and
`scripts/component_real_model_reference.py` compare the strict embedding profile
with an independently executed Python ONNX Runtime reference. The selected
[all-MiniLM-L6-v2 export](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/tree/1110a243fdf4706b3f48f1d95db1a4f5529b4d41)
is pinned by revision and SHA-256; weights remain in an ignored cache and are not
distributed with this project. Python dependencies are pinned in the script's
PEP 723 metadata and executed with `uv run --python 3.11`.

Its original tokenizer declares fixed padding and truncation, so both native and
WASI strict loaders reject it with `model_profile_tokenizer_settings`. Successful
runs use a separately pinned derived tokenizer with only those settings set to
null; the manifest retains the upstream 128-token limit and rejects overflow.
This adaptation is explicit and does not expand strict-profile compatibility.

On the recorded Apple M4 host, native ONNX Runtime 1.31.0 and actual WASI tract
0.23.5 each produced 16 pooled 384-dimensional vectors across eight batches.
Against Python ONNX Runtime 1.27.0, maximum absolute errors were
2.3842×10⁻⁶ and 2.3544×10⁻⁶ respectively. Reconstructed token IDs, masks and type
IDs matched exactly; 127/128-token inputs succeeded and 129 tokens failed without
truncation. Controls that corrupt tokens or vectors fail the comparison.

These are unnormalized masked means over this float32 export, including special
tokens. They verify this preprocessing/runtime path, without measuring the full
SentenceTransformer encode pipeline, other exports, editorial accuracy or
comparative runtime performance. [Exact commands, hashes, versions and limits](audit-2026-10-27/component-real-model-manifest.json)
and [independent coordinator comparison](audit-2026-10-27/component-real-model-parent-comparison.json)
retain the evidence. Downloads are optional and bounded; the script requires
`--download` to fetch missing model artifacts.

### World-state retention

`component_world_state` measures full snapshots, compact current state and compact
state with replayable deltas. At 1024 synthetic scenes/2048 final facts, five
release samples on the Apple M4 produced these medians and allocation peaks:

| Output mode | Median | Retained requested allocation | Peak additional requested allocation |
| --- | ---: | ---: | ---: |
| Full snapshots | 30.48 ms | 151.52 MB | 152.00 MB |
| Current state with event history | 2.82 ms | 0.43 MB | 0.61 MB |
| Current state, event history and net deltas | 3.06 ms | 0.68 MB | 0.83 MB |

Final facts, violations, knowledge, event histories and scores have identical
semantic fingerprints in these three modes. Compact output omits cumulative
snapshots; full snapshot materialization still necessarily retains their total
size. The default compact mode also omits optional event histories. This is an
output-retention choice, not a same-output full-history speedup claim.

Measurements include allocation accounting and warm regex/cast initialization;
they exclude compilation, caller input and non-Rust/process-RSS overhead. The
additional growth sizes and a separate transfer/location activity workload
are retained in [raw measurements](audit-2026-10-27/component-world-state-after.json).
Run `cargo run --locked --release --example component_world_state -- 1024 5 current`
or select `full`, `deltas`, `minimal`, and optional `activity` workload.
[Implementation, correctness checks and limits](audit-2026-10-27/component-world-state-manifest.json)
also record the oversized-name crash regression, static errors and independent
scene-boundary delta replay checks. No semantic editorial accuracy is measured.
