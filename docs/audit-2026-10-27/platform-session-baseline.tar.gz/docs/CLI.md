# CLI

The CLI is an optional filesystem adapter. Build with
`cargo build --release --features cli --bin narrative-lens`, or install locally
with `cargo install --path . --features cli`. Neither enables ONNX; add `onnx`
explicitly and select local NLI artifacts with `--model-root DIR --model-profile FILE`.
Both flags are required together. The root contains `nli-onnx/model.onnx` and
`nli-onnx/tokenizer.json`; the profile is a trusted v1 manifest of at most 16 KiB.
Select `NL-CONTINUITY-NLI` and set `nli` to `fallback` or `required` in configuration.
The CLI rejects missing/tampered artifacts and records verified identity in JSON.
See [profile contracts](INTEGRATION.md#local-models-and-cli).

```sh
cargo run --features cli --bin narrative-lens -- --help
cargo run --features cli --bin narrative-lens -- --list-rules --format json
cargo run --features cli --bin narrative-lens -- \
  --format terminal --characters Zoë,Mara chapter-01.md chapter-02.txt
cargo run --features cli --bin narrative-lens -- \
  --format json --config author.json --fail-on warning chapter-01.md > report.json
cargo run --features cli --bin narrative-lens -- \
  --format sarif --rules NL-GRAMMAR-REPETITION chapter-01.md > report.sarif
uv run --locked scripts/validate_sarif.py report.sarif
```

Each UTF-8 text/Markdown file is one scene. Markdown is analyzed verbatim, so
ranges stay exact; files stay in argument order. Automatic scene IDs use encoded
canonical paths relative to the current working directory when possible. Use a
stable working directory and paths across revisions, or a manifest for IDs that
survive file moves. Duplicate canonical inputs are rejected. Files must be
regular files within the documented scene/manuscript size limits.
`--document-id` sets identity (default `manuscript`); `--characters NAME,NAME`
sets continuity subjects. Use `--` before paths beginning with a dash.

`--manifest manuscript.json` accepts stable IDs and scene metadata. Paths are
relative to the manifest directory. It cannot be combined with positional files:

```json
{
  "documentId": "novel",
  "knownCharacters": ["Zoë"],
  "configuration": {
    "chronology": true,
    "rules": ["NL-CONTINUITY-LOCKED"]
  },
  "scenes": [
    { "id": "garden", "path": "chapter-01.md", "chronology": { "key": "02", "lane": "main" } },
    { "id": "cellar", "path": "chapter-02.md", "chronology": { "key": "01", "lane": "main" } }
  ]
}
```

Scenes may also supply `purpose`, `intentions`, and `chronologyLane`.
`--config FILE` overlays the [Configuration](MANUSCRIPT.md#author-controls)
object: nested objects merge, arrays replace, and omitted fields retain manifest
values/defaults. `--rules ID,ID`, `--minimum-severity LEVEL`, and repeatable
`--suppress ID` override/add controls. Suppression reasons and scoped selectors
can be supplied in configuration. Unknown options and invalid values are errors.
Selection of an adapter-only rule without a facade detector is an invocation
error; use the catalog’s `facadeAvailable` field when building rule choices.
`--verbose` shows confidence provenance and all coverage statuses. Terminal
reports show source paths, original UTF-16 line/column positions, suggestions,
and separate conflicting/constraint quotations; control characters are escaped.

Levels increase from `info` through `suggestion`, `warning`, and `error`.
`--fail-on LEVEL` sets the failure threshold (default `error`); `--fail-on none`
disables it. `--max-findings N` allows N findings at/above the threshold (default
zero). Counts include findings omitted by the report-size budget, after rule,
severity, intention and suppression controls. `--require-complete` rejects
incomplete selected capabilities; intentionally disabled passes are excluded.

`--baseline FILE` reads a validated facade Report (schema 1 or 2) or CLI JSON
envelope with the same document ID. JSON output is
`{ report, comparison, sources }`; `sources` maps stable scene IDs to source URIs.
`--new-only` requires a baseline and applies thresholds to introduced findings.
Incomplete comparisons produce exit 2. `comparison.complete` is false when
either report omits findings, candidate limits hide the compared population,
selected work fails or lacks required coverage, or an unmatched finding cannot be
assessed. `unassessed` can be empty when every
retained finding persists and all new findings were omitted. Schema-1 baselines
still import and match, but must be regenerated as schema 2 for a complete gate.
The full report remains visible. Callers own files,
configuration, and baselines; the CLI writes results only to stdout:

```sh
cargo run --features cli --bin narrative-lens -- \
  --format json --fail-on none chapter-01.md > baseline.json
cargo run --features cli --bin narrative-lens -- \
  --baseline baseline.json --new-only --fail-on warning chapter-01.md
```

| Exit | Meaning |
| --- | --- |
| `0` | Completed below the configured finding threshold |
| `1` | Finding threshold exceeded |
| `2` | Invocation/I/O/configuration/baseline error, required-capability failure, or requested complete analysis/comparison unavailable |

Optional model failures remain visible coverage unless strict handling is
requested. Errors go to stderr. JSON/SARIF remains available when requested
completeness fails after analysis. A closed stdout pipe is handled normally.

SARIF follows [OASIS SARIF 2.1.0](https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html):
`columnKind: utf16CodeUnits`, one-based lines/columns, zero-based UTF-16 character
offsets, CR/LF/CRLF support, original snippets, related locations, a full rule
catalog, partial fingerprints, accepted external suppressions, and baseline
states. Resolved findings use `absent`; incomplete prior assessments appear as
review results. Old locations retain original UTF-16 offsets without inventing
line numbers from revised text. A bare Report lacks historical file mappings;
its old coordinates remain in `properties.originalEvidence`. Preserve the CLI
envelope to retain historical source URIs. Scene aggregates identify their
artifact when known; aggregate scope never invents a source span.

SARIF text offsets exclude an initial UTF-8 BOM; facade ranges still address the
exact original input. CLI envelopes include `sourceBomUtf16` alongside `sources`
so baseline locations use the historical BOM convention. Older envelopes without
that metadata preserve original evidence instead of guessing physical offsets.

Integration tests validate actual Unicode, cross-file conflicts, resolved,
suppressed, and incomplete outputs against the vendored unmodified official
schema, whose hash is pinned in `tests/fixtures/provenance.json`. Development
validation uses the locked Python dependency in `scripts/validate_sarif.py.lock`.
The runtime adapter uses the existing optional `serde_json` dependency.
