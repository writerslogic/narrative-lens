# Architecture

## Analyzer categories

- **`craft`** -- sentence- and paragraph-level prose quality: readability, pacing, dialogue
  realism, voice consistency, subtext, syntax tension, lexical variety, grammar.
- **`structure`** -- manuscript-level narrative shape: foreshadowing and promise/payoff
  tracking, theme and thematic argument, narrative entropy, opening-page analysis, genre
  compliance.

`structure::author_events` validates snapshots of author-confirmed setups and
resolutions against original scene quotes and UTF-16 ranges. Stable event/scene IDs
preserve identity across presentation changes. This ledger stores exact outcomes
and counts; inferred legacy fulfillment remains unknown.

`continuity::author_knowledge` tracks author-declared propositions, truth changes,
beliefs, knowledge assertions, uncertainty, forgetting and explicit communication.
It shares source validation with the promise ledger. Reader and character actors
remain distinct, and explicit replay sequence is independent of scene ordering.
State is sparse: missing annotations remain unassessed, and matching a belief to
declared truth does not promote it to an author-confirmed knowledge assertion.
- **`continuity`** -- cross-chapter consistency: timeline, world state, coreference and
  entity resolution, causal chains, epistemic state, gap analysis, anachronism detection.
- **`substrate`** -- shared primitives every category above depends on: text segmentation,
  embeddings, confidence scoring, and explanation generation.

## Design rule

Reserved analyzers (subtext, thematic argument, reader mental model) report
`availability: unavailable`. Partial ledgers and convention checks preserve
unknown states rather than infer fulfillment or convention compliance from
unrelated scores. Narrative entropy currently measures semantic novelty, not
probabilistic uncertainty about plot outcomes.

Standalone analyzers have function-specific inputs and results. The optional
`manuscript` facade coordinates supported passes into typed findings and coverage;
its caller-owned `AnalysisContext` bounds retained scene intermediates. Core
analysis has no filesystem or network handling. Native model loading and the
optional CLI are adapters. Persistence, project storage, and revision history
belong to the caller. See [MANUSCRIPT.md](MANUSCRIPT.md) for the supported rule
surface and conservative chronology policies.

## Out of scope: Emathy's meaning graph

Emathy's `meaning_graph` (session-scoped agency/branch/expectation/intent/memory
tracking over a manuscript's revision history) was never ported here. It isn't a
standalone analyzer -- it's wired directly into Emathy's orchestration engine
(60+ call sites into `agency`, `branches`, `expectation`, `intent`, `memory`,
`orchestrator`, `research`, `tags`), which contradicts this crate's pure-function
design rule below. A narrative-lens equivalent would be a new design, not an
extraction, and isn't planned.

## Provenance

This crate began as an extraction from Emathy's `emathy-core`, a native macOS authoring
app. Emathy's own storage, branching, project, and export machinery is not part of
this crate and was never intended to be -- see the project README's "Why narrative-lens"
section for the reasoning.

## Local ONNX path

The `onnx` feature enables model-backed analysis: SBERT sentence embeddings
(`substrate::sbert`, used by `structure::{theme,narrative_entropy,genre}` for
semantic similarity), BERT NER (`continuity::ner`), NLI contradiction detection
(`substrate::nli`), and Ekman-7 emotion classification (`craft::emotion`).
Native (`not(target_arch = "wasm32")`) runs `ort` (ONNX Runtime); `wasm32` runs
`tract`, a pure-Rust CPU runtime.

Follows a "bring your own model, no download" contract, matching
`holographic-memory`'s local embedder: no model weights are bundled or fetched
by this crate. Point `set_model_directory` (per analyzer) at an explicit model
root as described below, or leave it unset -- every analyzer
retains its legacy non-model fallback (or empty output) when no model is found.
The new checked calls and facade report missing models, incompatible output,
inference failures, and coverage explicitly; strict requirements return errors.
With the `onnx` feature disabled entirely, legacy degradation
happens at compile time via a null backend, so no caller needs its own
`#[cfg]`.

Native model directories are explicit roots containing the analyzer subdirectory
(`sbert-onnx`, `ner-onnx`, `nli-onnx`, or `emotion-onnx`). Setters can replace or
retry models after first use. Loading runs outside configuration locks, and
native sessions retain a shared telemetry-disabled ONNX Runtime environment.
Verified profile loaders hash immutable model/tokenizer bytes and share validated
preprocessing and canonical-label remapping between native and tract runtimes.
NLI reports capture identity within a model-generation bracket, preventing mixed
results/provenance during replacement. Legacy paths remain explicitly unverified.
No process-global cache retains NER windows. Callers can opt into bounded,
clearable `onnx::NerCache` retention and supply a revision for injected models;
model changes during a cached batch return an explicit failure.

Example model families (not bundled; one pinned MiniLM float32 export has a
[native/WASI numerical parity check](EVALUATION.md#pinned-pretrained-model-parity),
while the other families still require compatible exports and independent validation):
- SBERT: `sentence-transformers/all-MiniLM-L6-v2` (Apache-2.0, 384-dim, ~90MB).
- NER: `dslim/bert-base-NER` (MIT) -- a maintained ONNX export exists as
  `onnx-community/bert-base-NER-ONNX`.
- NLI: compatible three-class models with contradiction/neutral/entailment order,
  as declared by `substrate::nli::NLI_LABELS`.
- Emotion: `j-hartmann/emotion-english-distilroberta-base` (Ekman-7 labels,
  positionally aligned with `craft::emotion::EKMAN_LABELS`).
