# Manuscript analysis

The optional `manuscript` module coordinates grammar, readability, pacing,
syntax tension, genre profiles, structure templates, author lexicons, and a
conservative continuity pass. Core Rust requires 1.89+ (including the resolved nalgebra dependency);
optional native ONNX builds require 1.92+, and wasm ONNX/tract builds require 1.91+.
The facade requires no feature flag, model, filesystem,
network, project model, or persistence. Existing analyzer functions retain their
signatures and defaults. `Options {}` and `AnalysisResult {}` remain empty legacy
placeholders for source compatibility; the facade uses `Configuration` and
`Report`.

Run the complete examples with `cargo run --example manuscript` and, after
`npm run build:debug`, `node examples/manuscript.mjs`.

```rust
use narrative_lens::manuscript::{
    analyze_manuscript, Configuration, Manuscript, Scene,
};
let manuscript = Manuscript {
    document_id: "novel".into(),
    scenes: vec![Scene::new("opening", "She was was tired.")],
    known_characters: vec![],
    configuration: Configuration::default(),
};
let report = analyze_manuscript(&manuscript)?;
# Ok::<(), narrative_lens::Error>(())
```

`Scene` also accepts `purpose`, `intentions`, optional `Chronology { key,
lane }`, and an optional `chronologyLane` hint when its key is unknown.
`Scene::from_timeline` adapts the existing author-supplied `TimelineEntry` metadata. IDs belong to the caller and must remain stable across revisions.
Presentation order is the scene vector order. Counts, sentence boundaries,
readability, pacing, and tension inputs are computed by the library.

## Findings and evidence

`Report` schema version `"2"` contains ordered findings, suppressed findings with
reasons, per-scene metrics, capability coverage, diagnostics, chronology,
presentation IDs, a resolved configuration snapshot, and summary counts.
`summary` distinguishes all detections, suppressions, returned findings, omitted
findings, and severity counts, including findings omitted by the output budget.
`Report::validate` checks imported report identities, ranges, finite confidence,
chronology, configuration, fingerprints, and count integrity.
`validate_against(&manuscript)` also checks every quotation and coordinate against
the exact original text, including reader-knowledge evidence.
Each `Finding` has a document ID, stable rule ID, typed severity, suggestion,
confidence provenance, explicit scope, evidence, and revision fingerprint.

All ranges are **zero-based, half-open, relative to the exact original scene
text**. `byteStart..byteEnd` counts UTF-8 bytes; `utf16Start..utf16End` counts
UTF-16 code units, suitable for JavaScript `text.slice(start, end)`. Neither
counts graphemes. Text is never normalized before locating evidence. Combining
marks and astral characters retain their original boundaries. `TextRange::new`
and `TextRange::from_utf16` reject invalid boundaries, including a split
surrogate pair. Evidence quotes exactly equal both corresponding slices.

Passage findings identify primary and conflicting evidence with roles. Physical
continuity findings quote both conflicting passages; a locked-location quote
has separate evidence for the earlier location and its constraint. Scene and manuscript aggregate
findings have explicit scope and may have no pinpoint quotation: a missing beat
or aggregate grade cannot honestly identify one offending character range.
Readability/pacing may include an illustrative sentence with the `context` role;
it does not convert their aggregate scope into a pinpoint claim. Evidence also
retains up to 64 original characters on either side within sentence boundaries
for revision matching.
`finding::adapt_grammar` adapts legacy grammar spans;
`finding::adapt_explanation` assigns aggregate scope to spanless legacy
explanations. Adapters assign a fingerprint for a single result; use
`assign_fingerprints(document_id, &mut findings)` after assembling a batch to
assign distinct ordinals to duplicate occurrences. Existing analyzer results
remain available unchanged.

| Rule | Interpretation |
| --- | --- |
| `NL-GRAMMAR-REPETITION` | Consecutive identical words separated by whitespace |
| `NL-GRAMMAR-WHITESPACE` | Extra interior ASCII spaces |
| `NL-GRAMMAR-SPELLING` | Lowercase word absent from the local frequency dictionary; may be invented or dialect |
| `NL-GRAMMAR-CAPITALIZATION` | Reserved adapter ID; explicit facade selection is rejected because no detector is available |
| `NL-READABILITY-COMPLEX` | Scene FKGL exceeds the genre/custom maximum, with an adequate sample |
| `NL-PACING-LONG` | Average sentence length exceeds the genre/custom maximum |
| `NL-PROSE-LEXICON` | Literal whole-word author-configured editorial terms; ASCII-insensitive matching, Unicode boundaries |
| `NL-STRUCTURE-MISSING-BEAT` | Existing template scorer cannot match a beat using scene purposes, position, and computed tension |
| `NL-CONTINUITY-LOCKED` | Explicit named character changes location while an observed constraint remains active |
| `NL-CONTINUITY-ATTRIBUTE` | Explicit eye-color assertions disagree |
| `NL-CONTINUITY-OBJECT` | Explicit key/sword/letter/ring/book location assertions disagree without an observed transfer |
| `NL-CONTINUITY-NLI` | Optional local three-class model reviews sentence pairs inside a configured scene window |

This is a defined facade surface, not an automatic orchestration of every
standalone analyzer. Emotion, theme, voice, causal and epistemic analyzers retain
their standalone APIs. Physical facts use explicit English patterns, known
subjects/aliases, original sentence spans, release/transfer events, and evidence
provenance. Unrecognized states remain unknown. Missing transitions and template
matches are review suggestions; they are not proofs of an author error.

## Author controls

`Configuration` is serializable with camelCase JSON keys, defaults for omitted
fields, and rejection of unknown fields. No configuration is read or saved by
the library. `Genre` uses the existing Rust enum labels in configuration JSON
(`"Fantasy"`, `"SciFi"`, etc.). Existing standalone genre-profile APIs retain
their behavior. Threshold overrides apply over those profiles.

```json
{
  "genre": "Fantasy",
  "thresholds": { "maxGrade": 16, "minSceneWords": 100 },
  "dictionary": ["wyrmlet"],
  "lexicon": ["very", "suddenly"],
  "rules": ["NL-GRAMMAR-SPELLING", "NL-PROSE-LEXICON"],
  "minimumSeverity": "suggestion",
  "suppressions": [
    { "ruleId": "NL-PROSE-LEXICON", "sceneId": "opening", "reason": "Deliberate narrator diction" }
  ]
}
```

`rules: null` or omission selects all supported rules; `rules: []` selects none.
Lexicon omission/empty selects no editorial terms. Dictionary additions suppress
spelling suggestions case-insensitively. The lexicon replaces the author term
list; it does not replace the bundled English dictionary. `entityCorrections`
reuses the existing `{ surface, action: { kind: "assign", canonical } }` or
`{ kind: "reject" }` format for continuity subject aliases. It never rewrites
original text or shifts source ranges. Later corrections for a surface win.

Per-scene `intentions` are `repetition`, `dialect`, `complex_prose`,
`long_sentences`, `nonlinear`, `open_ending`, and `supernatural`. They affect the
corresponding rules. Conventional structure analysis is skipped when every nonempty scene declares
`nonlinear`. An `open_ending` intention on the final scene exempts only closing
beats; it does not suppress missing setup or climax findings. Supernatural scenes clear physical
state, preventing speculative comparisons across an intentional discontinuity.
Rules, minimum severity, and suppressions apply consistently to all facade
findings. Suppressions match all supplied selectors (rule, scene, fingerprint),
require a reason and at least rule or fingerprint, and remain visible in
`report.suppressed`. A manuscript-scope finding matches a scene suppression if
that scene belongs to its aggregate scope.

Validation bounds:

| Setting | Inclusive bounds |
| --- | --- |
| `maxGrade` | 0–30, finite |
| `maxSentenceWords` | 1–500, finite |
| `minSceneWords` | 1–100,000; default 100 |
| `minStructureScenes` | 2–10,000; default 3 |
| `nliContradiction` | 0–1, finite; default 0.8 |
| IDs/chronology keys/lanes | 1–256 UTF-8 bytes; no control characters |
| Known characters | At most 256; names 1–128 bytes; unique ignoring case |
| Dictionary/lexicon | At most 4,096 entries each, 1–128 bytes each |
| Corrections/suppressions | At most 4,096 each; suppression reason 1–1,024 bytes |
| Input | At most 10,000 scenes, 16 MiB/scene, 64 MiB total UTF-8 text |
| Cache budget | 0–256 MiB; default 16 MiB |

`limits` provides validated work budgets (inclusive bounds):

| Limit | Default | Allowed |
| --- | ---: | ---: |
| `maxFindings` | 10,000 | 1–100,000 |
| `sceneCandidates` | 4,096 per selected pass/scene | 1–65,536 |
| `nliPairs` | 128 | 1–65,536 |
| `nliSentencesPerScene` | 8 | 1–64 |
| `nliWindowScenes` | 1 | 1–128 |
| `modelInputBytes` | 16,384 | 1–65,536 |

Grammar and lexicon each use `sceneCandidates`; the world-event budget is twice
that value (8,192 by default), allowing both assertions and transitions. The
three passes have separate budgets. Rule selection, spelling
dictionary additions, and relevant intentions apply before candidate collection;
unselected rules cannot consume another pass’s budget. Suppressions apply before
the active output budget. Active and suppressed retained records each have a
`maxFindings` cap, while summary counts retain totals. Exceeding a limit produces
a diagnostic and partial coverage; exactly meeting it does not. Truncated physical state is not
carried into later comparisons. Limits protect the facade; standalone defaults
remain compatible.

## Confidence and availability

Heuristic scores describe engineering evidence strength. They are not validated
probabilities of editorial correctness. `confidence.source`, `method`, and
`calibrationId` distinguish heuristic, model, and calibrated values; defaults
have no calibration ID. NLI softmax scores identify model provenance and the
caller-supplied `modelRevision`, and also remain uncalibrated.

Every capability has a status, total/analyzed unit counts, and diagnostics:

| Status | Meaning |
| --- | --- |
| `complete` | Selected supported pass finished over eligible inputs; no claim of semantic completeness |
| `heuristic_fallback` | Deterministic substitute used or partial candidate/report/chronology coverage |
| `unavailable` | Capability disabled, unselected, or model unavailable |
| `insufficient_input` | Empty/short text or no eligible pairs/scenes |
| `execution_failure` | Incompatible model output/load or inference failure |

`nli` is `disabled` by default, `fallback` for optional model analysis, or
`required` for strict handling. An unavailable optional NLI pass is explicitly
unavailable; the deterministic continuity pass records fallback when used.
A required pass returns `AnalysisFailed` if unavailable, failing, insufficient,
or candidate-limited. Invalid configuration returns `InvalidInput`.

With `onnx`, native model loading uses only an explicitly configured root with
the analyzer subdirectory (`sbert-onnx`, `ner-onnx`, `nli-onnx`, or `emotion-onnx`)
containing `model.onnx` and `tokenizer.json`; no model is fetched or discovered
from the current directory. Setters replace or retry models after first use and
invalidate retained analysis through a model-generation counter. For
independent caller-owned runtimes use `analyze_with_backend`
or `AnalysisContext::analyze_with_backend` and `InferenceBackend`. Advertise
availability with `check_model`; inference can return a typed failure through
`embed_checked`, `tag_batch_checked`, `classify_checked`, and
`classify_pairs_checked`. `onnx::checked::{nli, embeddings, entities, emotion}`
validate availability, cardinality, tensor shape, finite values, probability
distributions where appropriate, and NER original-text byte ranges. Checked
inference bounds text batches, token counts, tensor dimensions and allocations.
NLI returns canonical contradiction/neutral/entailment order and a three-value
probability distribution. Verified manifests declare and remap source label order;
legacy models must export canonical order. Shape checks cannot establish label meaning.
Successful NLI reports include `modelIdentities`: a verified artifact/profile
manifest, or explicit unverified legacy provenance. The facade brackets inference
and identity capture with model generation; replacement discards all NLI findings
from that pass, and required mode returns an error. Old reports without identity
metadata still import, without acquiring a verification claim.
Legacy empty-output functions remain compatible. Native missing/invalid files, injected failures, and twelve tiny local ONNX
models exercise success, incompatible outputs, and real execution failures for
all four capabilities. Successful empty NER results remain distinct from failure.
These untrained constant/Cast graphs test runtime contracts, not model accuracy. No model weights are
bundled or used for the synthetic accuracy claims.

## Chronology and reader knowledge

Chronology is opt-in: set `configuration.chronology = true` and supply each
scene's `{ key, lane }`. Keys are author-defined strings sorted lexicographically
inside each lane, so use fixed-width numbers or sortable timestamps. The library
does not interpret dates or infer chronology from prose. Scenes remain in
presentation order in the input and report. Physical state is evaluated in story
order independently per lane; no cross-lane ordering or interactions are assumed.

Tied keys form local uncertainty barriers: state is cleared at the tied group,
and unambiguous segments before/after it are still checked. A scene with no key
but a known `chronologyLane` blocks physical comparisons in that lane. An unknown
lane blocks all physical comparisons because that scene might explain any
transition. Diagnostics retain the ambiguity.
These policies favor avoiding a speculative contradiction over guessing an order.

`chronology.readerKnowledge`, when chronology is enabled, follows presentation order, recording the
first introduced explicit learned/discovered/knew/realized fact with its original
passage. It is a reader introduction ledger, not a proof of character epistemic
access or an inference that a flashback is an error.

## Author-confirmed narrative annotations

`continuity::author_knowledge::analyze_author_knowledge(&manuscript, &propositions, &events)`
and Node `analyzeAuthorKnowledge(manuscript, propositions, events)` replay explicit
author annotations. Propositions have stable IDs, descriptions, `"true"`,
`"false"` or `"unknown"` baseline truth, and exact source evidence. Every event
has a unique ID, unique unsigned 32-bit `sequence`, `propositionId`, action and
source. Scene/input-array reordering does not change replay order.

Actors are `{kind:"reader"}` or `{kind:"character",characterId:"Alice"}`;
characters must exactly match the manuscript's `knownCharacters`. A character
named `reader` remains distinct from the reader. `believe` records a belief;
matching declared truth yields `correct_belief`, not knowledge. `know` requires
an explicit author knowledge assertion matching known current truth. `uncertain`
and `forget` preserve explicit uncertainty and unknown state. Missing actor/fact
pairs remain unassessed. Truth changes reclassify existing assertions without
automatically informing any actor.

`communicate` records the sender, recipient, stated Boolean value and explicit
`uptake` (`unchanged`, `belief` or `knowledge`). It permits deception without
copying the speaker's belief or treating testimony as truth. Knowledge uptake
requires the same author-confirmation/truth conditions as `know`. Transitions
retain the exact source and prior recipient/sender assertions and event IDs;
the sparse final states and per-proposition reader/character comparisons retain
unknown and unassessed distinctions.

Replay is one author-defined sequence, not an inferred story timeline or reader
presentation chronology. Use separate proposition IDs for distinct temporal or
contextual claims. Source validation proves quote/range identity; it does not
prove a passage entails the annotation. The pure function validates the complete
snapshot before returning, with at most 10000 propositions, 10000 events and
4 MiB of annotation strings. It does not populate facade findings automatically.

`structure::author_events::analyze_promise_events(&manuscript, &events)` and Node
`analyzePromiseEvents(manuscript, events)` provide a separate author-confirmed
ledger. Each `setup` supplies a stable `id`, description and source evidence;
each `resolution` names its `setupId` and an author-chosen
`fulfilled|partial|subverted|abandoned` outcome. Evidence contains `sceneId`,
`utf16Start`, `utf16End` and the exact original `quote`. Returned evidence also
includes byte ranges and local context. An unlinked setup has unknown resolution,
even if later prose appears to answer it.

Event IDs share one unique namespace, and a setup permits one current resolution.
Submit a replacement snapshot to revise annotations; input/event order does not
determine identity or overwrite decisions. Scene reordering preserves links,
including nonlinear presentation. Editing source text requires refreshing its
ranges; stale quotes, surrogate splits, unknown references and duplicate decisions
return an error. Limits are 10,000 events, 4 MiB total annotation fields, 64 KiB per
quote, and 4096 bytes per setup description. The ledger does not infer payoff
quality or alter the heuristic manuscript report.

## Reanalysis and revisions

`AnalysisContext` belongs to the caller. Reuse it for successive manuscripts;
call `clear` to release its scene cache. It caches grammar, segmentation,
readability, pacing, tension, and evidenced world events by exact scene ID/text.
Edits recompute the changed scene; insertion/deletion update membership;
reordering, intentions, purposes, and chronology recompute the dependent passes.
Intermediate components are shared through `Arc` rather than deep-cloned on
reuse. Thresholds, output filters, purposes, chronology and model revision changes
reuse raw scene metrics. Dictionary/grammar-selection changes invalidate grammar;
cast/corrections/world-selection changes invalidate evidenced world events.
Relevant scene intentions invalidate only their affected components. Model inference is never cached, so replacing an
injected backend cannot return stale model findings. All cross-scene passes are
rerun from cached intermediates; incremental output equals fresh output.

The budget bounds retained scene payload estimates, including string/vector
capacities and map-node allowances. Eviction uses deterministic scene-ID order.
Zero disables retention. Dependency metadata is included in the retained-byte
estimate. Temporary work, inputs, returned reports, allocator bookkeeping, and
runtime models are outside that budget. `stats()` exposes reuse, recomputation, retained bytes, and
entry count, and per-component recomputation counts. This is a scene cache, not persisted revision storage.

`try_compare_reports(before, after)` validates imported reports and document
identity, then returns introduced, persistent (before/after pairs), resolved, and
`unassessed` findings. `compare_reports` is the existing unchecked counterpart. Matching uses versioned full anchors: document ID,
rule ID, stable scene ID (or sorted aggregate scene IDs and the aggregate message),
and ordered primary/conflict evidence scene IDs/quotes. Illustrative `context`
evidence is excluded. Quotes collapse whitespace and lowercase
Unicode; they are not Unicode-normalized. Offsets, presentation order, severity,
and confidence are excluded. Exact local contexts match first; remaining identical evidence matches as an
ordered multiset. `matchKind` distinguishes `context`, `evidence`, and
`ambiguous_occurrence` matches. Duplicate occurrences get distinct occurrence ordinals and
fingerprints. Adding/removing an indistinguishable copy changes multiplicity;
there is no claim to identify which identical copy was edited. Moving content
to a new scene ID is introduced/resolved. Changed evidence wording is also
introduced/resolved. `nl-v2` FNV-1a fingerprints include local context and a fixed 64-bit ordinal encoding;
matching compares full anchors to avoid hash-collision identity errors.

Callers retain reports and baselines in their own storage. Comparisons include
active findings; suppressing an active finding therefore resolves it in the
active-finding comparison. A rule disabled, unavailable, insufficiently sampled,
or truncated in the counterpart report cannot establish a repair or a new
regression; those unmatched findings are `unassessed` with a reason. Persisted
older schema-1 reports can be imported, but missing old local context may require
evidence-only matching. `comparison.complete` is false if either report has
omitted findings, candidate limits, unavailable selected work, or an older schema
that cannot prove exhaustive coverage. Even when all retained findings persist,
such a comparison cannot establish the absence of regressions. Rust callers can
recompute this condition with `is_complete(before, after)`; `--new-only` returns
exit 2 when completeness is unproved. Regenerate schema-1 baselines before using
them as an exhaustive CI gate. Reports and revision storage remain caller-owned.

## Node

`index.d.ts` is generated by napi and references the precisely typed
`manuscript.d.ts` input wrappers and `manuscript.generated.d.ts` result contracts.
The latter and `docs/manuscript.schema.json` are generated from the Rust types:

```sh
cargo run --features bindings --example export_contracts
cargo run --features bindings --example export_contracts -- --check
npm run test:contracts
```

CI checks drift, strict TypeScript usage, and actual Node values against generated
schemas. The JSON bridge does not imply `any` return values.
`defaultManuscriptConfiguration()` exposes resolved defaults;
`listManuscriptRules()` exposes the rule catalog.
`parseManuscriptReport(unknown)` validates persisted JSON before use.

```js
import { analyzeManuscriptAsync, ManuscriptContext } from 'narrative-lens';
const manuscript = {
  documentId: 'novel',
  scenes: [{ id: 'opening', text: 'She was was tired.' }],
};
const report = await analyzeManuscriptAsync(manuscript);
const context = new ManuscriptContext(16 * 1024 * 1024);
const next = await context.analyzeAsync(manuscript);
```

Synchronous `analyzeManuscript`, context `analyze`, `stats`, and `clear` also
exist. `compareManuscriptReports` compares typed reports. Expensive async work
runs on libuv's worker pool via [napi ScopedTask](https://napi.rs/docs/concepts/async-task).
Input conversion and final JS object materialization still run on the event
loop; async does not eliminate those costs. Concurrent operations on the same
context may reject with `analysis context is busy`; retry after the current
promise resolves or use separate contexts. The context mutex protects ownership
only and is released during computation. No lock is held across an await or I/O.
Native tests require the addon and verify timer progress during novel-sized work;
a missing addon is a test failure.

See [CLI](CLI.md) and [evaluation and benchmarks](EVALUATION.md).
