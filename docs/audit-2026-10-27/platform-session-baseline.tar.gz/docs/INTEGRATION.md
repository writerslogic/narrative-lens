# Integration

Core Rust requires 1.89+; native ONNX requires 1.92+, WASM ONNX/tract requires
1.91+, and Node requires 18+. The default library uses no network,
model download, or persistence. Filesystem handling belongs to the CLI/model
adapters and consuming application.

## Rust

```toml
[dependencies]
narrative-lens = "0.1"
```

Standalone analyzers retain their own signatures:

```rust
use narrative_lens::craft::readability;
let scene = "The rain fell steadily against the window pane.";
let result = readability::compute_readability(scene);
assert!(result.word_count > 0);
```

For coordinated analysis, use `manuscript::analyze_manuscript(&Manuscript)`.
It computes intermediate counts and returns a consistent `Report`. Reuse a
caller-owned `AnalysisContext` for edits and compare reports with
`compare_reports`. See [MANUSCRIPT.md](MANUSCRIPT.md) for typed evidence,
configuration, intentions, suppressions, availability, chronology, incremental
invalidation, revision matching, and limits. Legacy `Options`/`AnalysisResult`
remain empty compatibility types; standalone analyzers do not use them.

The executable examples are `cargo run --example analyze_passage` and
`cargo run --example manuscript`; CI executes both.

## Node

```js
import { computeReadability, analyzeManuscriptAsync } from 'narrative-lens';
const metrics = computeReadability('The rain fell steadily.');
const report = await analyzeManuscriptAsync({
  documentId: 'novel', scenes: [{ id: 'first', text: 'She was was tired.' }],
});
```

`src/napi_bindings/` exposes most craft, structure, continuity, and selected
substrate functions. Small DTO bindings and JSON bridges both have precise
TypeScript declarations through napi objects and generated Rust wire contracts.
`index.d.ts` is generated from those bindings and references `manuscript.d.ts`
and `standalone.generated.d.ts`. The `bindings` Cargo feature (`ts-rs`/`schemars`)
generates manuscript contracts with `cargo run --features bindings --example
export_contracts` and standalone contracts with `cargo run --features bindings
--example export_standalone_contracts`; napi generates the function/class
declarations. CI checks generation and validates actual Node results against the
schemas. Serialized enum tags follow serde: world facts use `characterAt`,
and payoff states include `unknown` and `confirmedFulfilled`.

Standalone internal helpers (`substrate::{text,utils,nlp,wordfreq,nli,sbert}` and
`continuity::ner`) and some model-only/in-place functions are not Node exports.
Consult `index.d.ts` for the actual surface. No namespace object per category is
required. New facade exports are `analyzeManuscript`, `analyzeManuscriptAsync`,
`ManuscriptContext` (`analyze`, `analyzeAsync`, `stats`, `clear`), and
`compareManuscriptReports`, `parseManuscriptReport`,
`defaultManuscriptConfiguration`, and `listManuscriptRules`. Expensive async computation runs on libuv workers;
JSON input conversion and final JS materialization still occupy the event loop.

`npm ci && npm run build:debug` builds the native addon and regenerates the
CommonJS loader and declarations. `index.mjs` is the maintained ESM wrapper;
keep named exports synchronized when adding bindings. Native `.node` binaries
are ignored by Git. `npm test` fails when the addon is missing; it does not
silently skip native tests. `npm run test:types` checks strict TypeScript.
`npm run test:examples` executes the representative Node examples.
`npm run test:contracts` validates actual facade and standalone outputs against generated schemas
using the locked development validator.

`npm run test:package` installs staged root/platform tarballs without registry
access and checks CJS, ESM, manuscript evidence, and installed declarations.
Release jobs execute the packed artifacts on every declared target and Node
18/20/22/24/26 before allowing publication. Binary digests and text payload hashes
(with checkout line endings normalized) bind publication to tested packages.

`trackWorldState` reduces explicit English events in source order. Snapshot
`facts` contain live state; `newFacts` and `invalidatedFacts` record transitions,
including facts introduced and invalidated within one scene. Unobserved knowledge
paths remain unknown. Reserved/partial narrative APIs expose `availability` and
`diagnostics`; neutral legacy numbers do not establish a measurement.
Named lock/unlock events use that actor's previously observed location. An
unrecognized explicit subject does not borrow another actor's location or clear
an unrelated lock; supported bare/indefinite clauses retain legacy scoping.

For current state without cumulative snapshots, Rust
`world_state::track_world_state_current(scenes, characters, &options)` and Node
`trackWorldStateCurrent(scenes, characters, options?)` use the same reducer.
Options default to `includeDeltas:false` and `includeEventHistory:false`.
The result retains final facts, current knowledge and violations; `afterScene`
is the final zero-based scene index, or null when nothing was reduced.
Opt into historical locations/transmissions with `includeEventHistory`.
`includeDeltas` returns net scene-boundary changes: apply removals then additions
to reconstruct each boundary state. These deltas cancel intra-scene cycles;
legacy `trackWorldState` snapshots retain their original event-change lists.
Full cumulative history necessarily grows with the sum of all snapshot sizes.

Rust `track_world_state_checked` and `track_world_state_current` return `Result`;
both Node bindings throw on rejected input. World-state inputs allow at most
10000 scenes, 256 cast entries, 128 bytes per nonempty character name, 16 MiB per
scene and 64 MiB total source text. Names cannot contain control characters.
Regex compilation failures return static diagnostics without echoing input.
Legacy Rust `track_world_state` preserves its return type and reports
`availability: unavailable` with diagnostics on failure; its numeric scores then
carry no measurement. Missing availability in older serialized results also
defaults to unavailable.
Rust consumers constructing `WorldStateResult` literals must supply the new
`availability` and `diagnostics` fields; ordinary function callers retain their
existing return type.

Source-validated author epistemics are exposed separately through
`analyzeAuthorKnowledge`, with [truth/belief/reader semantics and limits](MANUSCRIPT.md#author-confirmed-narrative-annotations).
The fused `trainAndFindNearest` and `trainAndSimilarity` adapters propagate corpus
limit errors; invalid training input does not become an empty/zero semantic result.

## Local models and CLI

Enable `onnx` explicitly for optional SBERT/NER/NLI/emotion model runtimes:

```toml
narrative-lens = { version = "0.1", features = ["onnx"] }
```

```rust
narrative_lens::substrate::sbert::set_model_directory("/path/to/models");
// Native adapter looks for sbert-onnx/{model.onnx,tokenizer.json}.
```

Models are caller-provided and must be selected explicitly; there is no current-
directory discovery or fallback to a different model path. Relative paths resolve
when set. Setters support replacement/retry, and in-flight native calls retain
their model handle. Native model/tokenizer files are bounded at 1 GiB/64 MiB.
Legacy model wrappers preserve empty-output/fallback behavior. Checked APIs and
the facade expose explicit availability, failure diagnostics, and strict NLI
requirements; an empty result is never presented as a successful inference in
those paths. See [Architecture](ARCHITECTURE.md) and [Manuscript](MANUSCRIPT.md).

Legacy model exports must match the adapters' fixed label orders: NLI uses
contradiction/neutral/entailment, emotion uses anger/disgust/fear/joy/neutral/sadness/surprise,
and NER uses `O,B-MISC,I-MISC,B-PER,I-PER,B-ORG,I-ORG,B-LOC,I-LOC`.
Output shape checks cannot verify label meaning. Legacy setters report
`unverified_legacy` identity. For artifact verification, pass a trusted
`onnx::model::ModelManifest` to `set_model_directory_verified(kind, root, &manifest)`
or `set_model_bytes_verified(kind, model, tokenizer, &manifest)`. Both native and
WASM paths hash the exact bytes loaded, validate version/kind/profile, and remap
declared class order to the canonical order. Failed verification clears the
previous model. Verified v1 profiles require self-contained ONNX, supported
int64 HuggingFace inputs, no tokenizer-side truncation/padding, an existing padding
token ID, and at most 4096 tokens. Different graph architectures require another profile.

Native roots contain the analyzer subdirectory. A manifest records
`schemaVersion: 1`, `kind`, `profile`, lowercase `modelSha256`/`tokenizerSha256`,
`maxTokens`, `paddingTokenId`, and exact source-order `labels` (empty for embeddings).
Profiles are `hugging_face_masked_mean_v1`, `hugging_face_bio9_v1`,
`hugging_face_ekman7_v1`, and `hugging_face_nli3_v1`.
Identity is available through `InferenceBackend::model_identity`; manuscript
reports retain `modelIdentities` from successful NLI analysis. Artifact/configuration
verification establishes neither model accuracy nor the truth of supplied label meanings.

The [pretrained MiniLM parity check](EVALUATION.md#pinned-pretrained-model-parity)
records successful native/WASI execution with an explicitly adapted tokenizer,
and the original tokenizer's strict-profile rejection. Configured tokenizer-side
padding or truncation requires a separate compatible profile or an explicit,
separately pinned adaptation.

For Node model support, build with
`npx --no-install napi build --platform --release --features node-api,onnx -- --locked`.
`await loadVerifiedModel('nli', modelRoot, manifest)` loads on a worker; the default
addon explicitly rejects model loading because it excludes `onnx`. Relative roots
resolve at call time. After loading, `analyzeManuscriptAsync` records the verified
identity; replacement during inference discards the NLI results. Keep
`modelRevision` current when replacing an injected backend.

The release profile retains symbols to avoid the
[Rust/LLVM strip-debug layout defect](https://github.com/rust-lang/rust/issues/157750)
reproduced by the ONNX Node addon on macOS 27. Both default and model-enabled
artifacts must pass actual loading tests; compilation alone does not verify delivery.

Enable `cli` for the optional text/Markdown filesystem adapter with terminal,
JSON, and SARIF output. It supports configuration, rule/severity filters,
suppressions, revision baselines, and failure thresholds. See [CLI.md](CLI.md)
for commands, source-location conventions, and exit codes.
