import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, readFileSync, copyFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { basename, dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { digest, packagePayload, platform, stageNotices, verifyArtifacts } from './release_artifacts.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const args = process.argv.slice(2);
function option(name) {
  const index = args.indexOf(name);
  if (index < 0) return undefined;
  assert.ok(args[index + 1] && !args[index + 1].startsWith('--'), `${name} requires a value`);
  return args[index + 1];
}
function run(command, argv, cwd) {
  const result = spawnSync(command, argv, { cwd, encoding: 'utf8', env: { ...process.env, npm_config_audit: 'false', npm_config_fund: 'false' } });
  if (result.error) throw result.error;
  assert.equal(result.status, 0, `${basename(command)} failed: ${(result.stderr || result.stdout).slice(-6000)}`);
  return result.stdout;
}
function npm(argv, cwd) {
  assert.ok(process.env.npm_execpath, 'run this check through npm run test:package');
  return run(process.execPath, [process.env.npm_execpath, ...argv], cwd);
}
const temporary = mkdtempSync(join(tmpdir(), 'narrative-lens-package-'));
try {
  let archives;
  const from = option('--archives');
  if (from) {
    const directory = resolve(from);
    const manifest = JSON.parse(readFileSync(join(directory, 'manifest.json'), 'utf8'));
    archives = manifest.archives.map(archive => {
      assert.equal(basename(archive.filename), archive.filename, 'archive filename must stay inside artifact directory');
      const path = join(directory, archive.filename);
      assert.equal(digest(path), archive.sha256, 'archive digest changed');
      return path;
    });
  } else {
    const target = option('--target') || ({ darwin: { arm64: 'aarch64-apple-darwin', x64: 'x86_64-apple-darwin' }, linux: { x64: 'x86_64-unknown-linux-gnu' }, win32: { x64: 'x86_64-pc-windows-msvc' } })[process.platform]?.[process.arch];
    const host = platform(target);
    const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
    const staging = join(temporary, 'package');
    mkdirSync(staging);
    for (const file of [...pkg.files, 'README.md', 'LICENSE']) copyFileSync(join(root, file), join(staging, file));
    // Each native host stages its own target; the publishing gate requires all targets.
    writeFileSync(join(staging, 'package.json'), JSON.stringify({ ...pkg, napi: { ...pkg.napi, targets: [target] } }, null, 2));
    const require = createRequire(import.meta.url);
    const cliPackage = require.resolve('@napi-rs/cli/package.json');
    const cliMetadata = JSON.parse(readFileSync(cliPackage, 'utf8'));
    const cli = join(dirname(cliPackage), typeof cliMetadata.bin === 'string' ? cliMetadata.bin : cliMetadata.bin.napi);
    run(process.execPath, [cli, 'create-npm-dirs', '--cwd', staging], root);
    const filename = `${pkg.napi.binaryName}.${host.suffix}.node`;
    copyFileSync(join(root, filename), join(staging, 'npm', host.suffix, filename));
    stageNotices(staging, [target]);
    run(process.execPath, [cli, 'prepublish', '--cwd', staging, '--skip-optional-publish', '--no-gh-release', '-t', 'npm'], root);
    verifyArtifacts(staging, [target]);
    const output = resolve(option('--output') || join(root, 'target', 'package-smoke', target));
    mkdirSync(output, { recursive: true });
    archives = [staging, join(staging, 'npm', host.suffix)].map(directory => {
      const packed = JSON.parse(npm(['pack', '--ignore-scripts', '--json', '--pack-destination', output], directory))[0];
      return join(output, packed.filename);
    });
    const manifest = { target, version: pkg.version, nativeSha256: digest(join(root, filename)), payload: packagePayload(root), archives: archives.map(path => ({ filename: basename(path), sha256: digest(path) })) };
    writeFileSync(join(output, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  }
  assert.equal(archives.length, 2, 'expected the root and one platform archive');
  const consumer = join(temporary, 'consumer');
  mkdirSync(consumer);
  writeFileSync(join(consumer, 'package.json'), '{"private":true}');
  npm(['install', '--ignore-scripts', '--offline', '--omit=optional', '--no-package-lock', ...archives], consumer);
  const smoke = `
    const assert = require('node:assert/strict');
    const fs = require('node:fs');
    const path = require('node:path');
    const api = require('narrative-lens');
    const installed = path.dirname(require.resolve('narrative-lens'));
    assert.ok(!fs.readdirSync(installed).some(file => file.endsWith('.node')), 'root tarball must load the platform package');
    const platformNotice = path.join(path.dirname(require.resolve('narrative-lens-' + ({darwin:{arm64:'darwin-arm64',x64:'darwin-x64'},linux:{x64:'linux-x64-gnu'},win32:{x64:'win32-x64-msvc'}})[process.platform][process.arch])), 'THIRD_PARTY_NOTICES');
    assert.equal(fs.readFileSync(platformNotice, 'utf8'), fs.readFileSync(path.join(installed,'THIRD_PARTY_NOTICES'),'utf8'));
    const text = '😀 She saw saw the bird.';
    const report = api.analyzeManuscript({ documentId: 'package', scenes: [{ id: 'first', text }], configuration: { rules: ['NL-GRAMMAR-REPETITION'] } });
    assert.equal(report.findings.length, 1);
    for (const evidence of report.findings[0].evidence) assert.equal(text.slice(evidence.range.utf16Start, evidence.range.utf16End), evidence.quote);
    assert.ok('characterAt' in api.trackWorldState(['Alice was in the cellar.'], ['Alice']).snapshots[0].facts[0]);
    assert.deepEqual(api.trackWorldStateCurrent(['Alice was in the cellar.'],['Alice']).facts, api.trackWorldState(['Alice was in the cellar.'],['Alice']).snapshots[0].facts);
    const source = {sceneId:'first',utf16Start:0,utf16End:3,quote:'The'};
    const authored = api.analyzeAuthorKnowledge({documentId:'authored',scenes:[{id:'first',text:'The key is hidden.'}]},[{id:'key',description:'The key is hidden',truth:'unknown',evidence:source}],[{id:'reader',sequence:1,propositionId:'key',action:{kind:'uncertain',actor:{kind:'reader'}},evidence:source}]);
    assert.equal(authored.states[0].classification,'uncertain');
    import('narrative-lens').then(async esm => assert.deepEqual(await esm.analyzeManuscriptAsync({ documentId: 'package', scenes: [{ id: 'first', text }], configuration: { rules: ['NL-GRAMMAR-REPETITION'] } }), report)).catch(error => { console.error(error); process.exitCode = 1; });
  `;
  run(process.execPath, ['-e', smoke], consumer);
  if (!from) {
    writeFileSync(join(consumer, 'consumer.mts'), "import { analyzeManuscript, trackWorldState } from 'narrative-lens';\nconst count: number = analyzeManuscript({documentId:'typed',scenes:[]}).summary.totalFindings;\nconst fact = trackWorldState(['Alice was in the cellar.'],['Alice']).snapshots[0].facts[0];\nif ('characterAt' in fact) { const location: string = fact.characterAt.location; void location; }\nvoid count;\n");
    writeFileSync(join(consumer, 'tsconfig.json'), JSON.stringify({ compilerOptions: { strict: true, noEmit: true, target: 'es2022', module: 'nodenext', moduleResolution: 'nodenext', types: [] }, files: ['consumer.mts'] }));
    run(process.execPath, [join(root, 'node_modules', 'typescript', 'bin', 'tsc'), '-p', consumer], consumer);
  }
  process.stdout.write(`Installed package CJS, ESM and manuscript smoke passed on ${process.platform}/${process.arch} Node ${process.version}\n`);
} finally {
  rmSync(temporary, { recursive: true, force: true });
}
