import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import * as api from '../index.mjs';

const scenes = ['Alice was in the cellar. Alice discovered that the key was gone.', 'Alice entered the garden.'];
const profile = api.buildVoiceProfile('Alice', ['We should leave now.']);
const authorManuscript = {documentId:'author-contract',scenes:[{id:'question',text:'Who stole the key?'},{id:'answer',text:'Alice stole the key.'}]};
const authorEvents = [
  {kind:'setup',id:'key',description:'Identity of the thief',evidence:{sceneId:'question',utf16Start:0,utf16End:18,quote:'Who stole the key?'}},
  {kind:'resolution',id:'key-answer',setupId:'key',outcome:'fulfilled',evidence:{sceneId:'answer',utf16Start:0,utf16End:20,quote:'Alice stole the key.'}},
];
const knowledge=JSON.parse(readFileSync(new URL('../tests/fixtures/author-knowledge.json',import.meta.url),'utf8'));
const samples = {
  AuthorPromiseEvents: authorEvents,
  AnalyzePromiseEventsResult: api.analyzePromiseEvents(authorManuscript,authorEvents),
  AnalyzeSmogResult: api.analyzeSmog('Tomorrow. '.repeat(30)),
  AuthorPropositions: knowledge.propositions,
  AuthorKnowledgeEvents: knowledge.events,
  AnalyzeAuthorKnowledgeResult: api.analyzeAuthorKnowledge(knowledge.manuscript,knowledge.propositions,knowledge.events),
  WorldStateOptionsContract: {includeDeltas:true,includeEventHistory:true},
  TrackWorldStateCurrentResult: api.trackWorldStateCurrent(scenes,['Alice'],{includeDeltas:true,includeEventHistory:true}),
  AnalyzeSceneResult: api.analyzeScene(['radio'], 1200, 0),
  AnalyzeCausalityResult: api.analyzeCausality(scenes, ['Alice']),
  ResolveEntitiesResult: api.resolveEntities([['Alice', []]], 'character'),
  ResolveEntitiesWithCorrectionsResult: api.resolveEntitiesWithCorrections([['Alice', []]], 'character', []),
  BuildMentalModelResult: api.buildMentalModel(scenes, ['Alice'], ['Alice'], []),
  AnalyzeGapsResult: api.analyzeGaps([['Unpaid setup', 0]], [], [], [], 2, 1),
  TrackEpistemicsResult: api.trackEpistemics(scenes, ['Alice'], ['Alice']),
  BuildTimelineResult: api.buildTimeline([['first', 'Alice waited on Monday.']]),
  TrackWorldStateResult: api.trackWorldState(scenes, ['Alice']),
  ResolveCoreferencesResult: api.resolveCoreferences('İ Alice smiled. She waited.', ['Alice']),
  AnalyzePacingResult: api.analyzePacing(0, 0, 10, 2),
  AggregatePacingResult: api.aggregatePacing([api.analyzePacing(0, 0, 10, 2)]),
  ExtractDialogueResult: api.extractDialogue('"We should leave," Alice said.', 0, ['Alice']),
  AnalyzeDialoguePatternsResult: api.analyzeDialoguePatterns(api.extractDialogue('"We should leave," Alice said.', 0, ['Alice']), ['Alice']),
  AnalyzeDialogueRealismResult: api.analyzeDialogueRealism([0], ['Alice'], ['We should leave.'], ['Alice']),
  AnalyzeSyntaxTensionResult: api.analyzeSyntaxTension('Would she leave? She ran!'),
  GetTensionMetricsResult: api.getTensionMetrics([0.1, 0.8]),
  CollectProseExamplesResult: api.collectProseExamples(['Alice was very very tired.']),
  BuildVoiceProfileResult: profile,
  CompareVoicesResult: api.compareVoices([profile]),
  MeasureVoiceDriftResult: api.measureVoiceDrift(profile, profile),
  MeasureVoiceDriftFromTextResult: api.measureVoiceDriftFromText('Alice', ['Wait here.'], ['Wait here.']),
  AnalyzeCharacterVoicesResult: api.analyzeCharacterVoices(['Alice'], [['We should leave.']]),
  AnalyzeSubtextResult: api.analyzeSubtext(scenes, [], [], [], [], [], [], [], 'general'),
  GetStructureTemplateResult: api.getStructureTemplate('three_act'),
  ValidateStructureResult: api.validateStructure('nonlinear', [0.1, 0.5, 0.9, 0.4], []),
  AnalyzeForeshadowingResult: api.analyzeForeshadowing([['silver','key'], ['garden'], ['silver','key']], 3),
  BuildPromisePayoffLedgerResult: api.buildPromisePayoffLedger(['Who stole the silver key?', 'Alice stole the silver key.', 'Alice returned it.'], [5,5,3], 'general', [['silver key', 0, true]], [], 'three_act', 3),
  TrackThematicArgumentResult: api.trackThematicArgument(scenes, [], ['Alice'], [], 'general'),
  AnalyzeOpeningResult: api.analyzeOpening(scenes[0], 'general', []),
  CheckGenreComplianceResult: api.checkGenreCompliance('romance', false, false, false, true, false, false, 1000, 0.9, 'rising'),
  ComputeNarrativeEntropyResult: api.computeNarrativeEntropy(scenes, [], 'three_act', 'general', []),
  GenreFromLabelResult: api.genreFromLabel('general'),
  DetectGenreResult: api.detectGenre([], [0.1, 0.5], 0.2, 8),
  DetectGenreSmartResult: api.detectGenreSmart('Alice watched the garden.', [], [0.1, 0.5], 0.2, 8),
  EvaluateAgainstGenreResult: api.evaluateAgainstGenre('general', 8, 10, 0.2, 0.1, 0, 1000),
  GetGenreProfileResult: api.getGenreProfile('general'),
  DetectThemesSmartResult: api.detectThemesSmart(scenes, [['Alice','garden'], ['Alice','key']]),
  AnalyzeResolutionResult: api.analyzeResolution([{ hope: 0.8 }, { hope: 0.2 }]),
  ExplainReadabilityResult: api.explainReadability(20, 5, 10, 'general'),
  ExplainPacingResult: api.explainPacing(40, 0, false, 0),
  ExplainTensionResult: api.explainTension(0, 0.5, 1, 0, 0, 3, 1),
  ExplainToneShiftResult: api.explainToneShift('hopeful', 'grim', 1, 'general'),
  ExplainWhiteRoomResult: api.explainWhiteRoom(0, 0, 1000),
  ExplainShowDontTellResult: api.explainShowDontTell('filter_word', 'She noticed the garden.'),
  ComputeSceneConfidenceResult: api.computeSceneConfidence(scenes[0], 0),
  ComputeReadabilityConfidenceResult: api.computeReadabilityConfidence(100, 5),
  WordFrequenciesResult: api.wordFrequencies('garden key garden', 5),
  WordFrequenciesFromWordsResult: api.wordFrequenciesFromWords(['garden','key','garden'], 5),
};
assert.ok(samples.TrackWorldStateResult.snapshots.some(s => s.facts.some(f => 'characterAt' in f)));
assert.equal(samples.ValidateStructureResult.healthPct, 100);
const result = spawnSync('uv', ['run', '--locked', 'scripts/validate_sarif.py', '--standalone-contracts'], {
  cwd: new URL('..', import.meta.url), encoding: 'utf8', input: JSON.stringify(samples),
});
assert.equal(result.status, 0, result.stderr || result.stdout || result.error?.message);
process.stdout.write(result.stdout);
