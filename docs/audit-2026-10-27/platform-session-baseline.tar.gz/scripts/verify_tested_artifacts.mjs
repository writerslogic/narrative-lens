import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { packagePayload, verifyArtifacts } from './release_artifacts.mjs';

export function verifyTestedArtifacts(root, directory) {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
  for (const artifact of verifyArtifacts(root, pkg.napi.targets)) {
    const manifest = JSON.parse(readFileSync(join(directory, `packages-${artifact.target}`, 'manifest.json'), 'utf8'));
    assert.equal(manifest.target, artifact.target, 'tested target changed');
    assert.equal(manifest.version, artifact.version, 'tested version changed');
    assert.equal(manifest.nativeSha256, artifact.sha256, 'release binary differs from the installed/tested binary');
    assert.deepEqual(manifest.payload, packagePayload(root), 'release payload differs from the installed/tested package');
  }
  return pkg.napi.targets.length;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const root = fileURLToPath(new URL('..', import.meta.url));
  const count = verifyTestedArtifacts(root, resolve(process.argv[2] || 'tested-packages'));
  process.stdout.write(`All ${count} release binaries and payloads match tested packages\n`);
}
