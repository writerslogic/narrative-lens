import { createHash } from 'node:crypto';
import { readFileSync, statSync, copyFileSync, writeFileSync } from 'node:fs';
import { basename, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const platforms = {
  'x86_64-apple-darwin': { suffix: 'darwin-x64', os: 'darwin', cpu: 'x64' },
  'aarch64-apple-darwin': { suffix: 'darwin-arm64', os: 'darwin', cpu: 'arm64' },
  'x86_64-unknown-linux-gnu': { suffix: 'linux-x64-gnu', os: 'linux', cpu: 'x64', libc: 'glibc' },
  'x86_64-pc-windows-msvc': { suffix: 'win32-x64-msvc', os: 'win32', cpu: 'x64' },
};

export function platform(target) {
  const value = platforms[target];
  if (!value) throw new Error(`unsupported release target: ${target}`);
  return value;
}

export function digest(path) {
  return createHash('sha256').update(readFileSync(path)).digest('hex');
}

export function packagePayload(root) {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
  return Object.fromEntries([...pkg.files, 'README.md', 'LICENSE'].map(filename => {
    // Git's Windows checkout can change line endings without changing the payload.
    const content = readFileSync(join(root, filename), 'utf8').replace(/\r\n/g, '\n');
    return [filename, createHash('sha256').update(content).digest('hex')];
  }));
}

export function stageNotices(root, targets, directory = 'npm') {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
  if (!pkg.files?.includes('THIRD_PARTY_NOTICES')) return;
  for (const target of targets) {
    if (!pkg.napi.targets.includes(target)) throw new Error(`unconfigured release target: ${target}`);
    const folder = join(root, directory, platform(target).suffix);
    const filename = join(folder, 'package.json');
    const metadata = JSON.parse(readFileSync(filename, 'utf8'));
    if (metadata.name !== `${pkg.name}-${platform(target).suffix}` || metadata.version !== pkg.version) throw new Error('invalid notice destination package');
    copyFileSync(join(root, 'THIRD_PARTY_NOTICES'), join(folder, 'THIRD_PARTY_NOTICES'));
    metadata.files = [...new Set([...(metadata.files || []), 'THIRD_PARTY_NOTICES'])];
    writeFileSync(filename, JSON.stringify(metadata, null, 2) + '\n');
  }
}

export function verifyArtifacts(root, targets, directory = 'npm') {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
  if (!/^[A-Za-z0-9._-]{1,128}$/.test(pkg.napi.binaryName)) throw new Error('invalid native binary name');
  if (!Array.isArray(targets) || targets.length === 0 || new Set(targets).size !== targets.length) {
    throw new Error('release targets must be a nonempty unique list');
  }
  return targets.map(target => {
    if (!pkg.napi.targets.includes(target)) throw new Error(`unconfigured release target: ${target}`);
    const host = platform(target);
    const folder = join(root, directory, host.suffix);
    const path = join(folder, `${pkg.napi.binaryName}.${host.suffix}.node`);
    const metadata = JSON.parse(readFileSync(join(folder, 'package.json'), 'utf8'));
    if (metadata.name !== `${pkg.name}-${host.suffix}` || metadata.version !== pkg.version
      || !metadata.os?.includes(host.os) || !metadata.cpu?.includes(host.cpu)
      || host.libc && !metadata.libc?.includes(host.libc)) {
      throw new Error(`invalid platform package metadata: ${target}`);
    }
    const stat = statSync(path);
    if (!stat.isFile() || stat.size === 0) throw new Error(`missing or empty native artifact: ${target}`);
    if (pkg.files?.includes('THIRD_PARTY_NOTICES') && (!metadata.files?.includes('THIRD_PARTY_NOTICES')
      || digest(join(folder, 'THIRD_PARTY_NOTICES')) !== digest(join(root, 'THIRD_PARTY_NOTICES')))) {
      throw new Error(`missing or changed third-party notices: ${target}`);
    }
    return { target, path, filename: basename(path), package: metadata.name, version: pkg.version, sha256: digest(path) };
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
  try {
    if (process.argv.includes('--stage-notices')) stageNotices(root, pkg.napi.targets);
    const artifacts = verifyArtifacts(root, pkg.napi.targets);
    process.stdout.write(`Verified ${artifacts.length} release artifacts\n`);
  } catch (error) {
    process.stderr.write(`Release artifact validation failed: ${error.message}\n`);
    process.exitCode = 1;
  }
}
