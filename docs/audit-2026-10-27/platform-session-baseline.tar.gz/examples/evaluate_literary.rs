use narrative_lens::{
    continuity::{coreference::CoreferenceResolver, ner},
    craft::dialogue,
};
use serde::Deserialize;
use serde_json::json;
use std::{fs::File, io::Read};

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Case {
    id: String,
    split: String,
    entity_text: String,
    quotation_text: String,
    supplied_cast: Vec<String>,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let path = std::env::args()
        .nth(1)
        .ok_or("usage: evaluate_literary <prepared-input.json>")?;
    let mut bytes = Vec::new();
    File::open(path)?
        .take(16 * 1024 * 1024 + 1)
        .read_to_end(&mut bytes)?;
    if bytes.len() > 16 * 1024 * 1024 {
        return Err("benchmark inputs exceed16MiB".into());
    }
    let cases: Vec<Case> = serde_json::from_slice(&bytes)?;
    if cases.len() > 1000 {
        return Err("benchmark exceeds1000 works".into());
    }
    for case in cases {
        if case.entity_text.len() > 512 * 1024
            || case.quotation_text.len() > 512 * 1024
            || case.supplied_cast.len() > 256
        {
            return Err("benchmark case exceeds text/cast limits".into());
        }
        let started = std::time::Instant::now();
        let prediction = std::panic::catch_unwind(|| {
            let persons = ner::ner_extract_persons(vec![case.entity_text.clone()]);
            let detected: Vec<String> = persons
                .iter()
                .take(256)
                .map(|(name, _)| name.clone())
                .collect();
            let supplied: Vec<_> = case.supplied_cast.iter().map(String::as_str).collect();
            let discovered: Vec<_> = detected.iter().map(String::as_str).collect();
            let resolver = CoreferenceResolver::new();
            json!({
                "personNames":persons,
                "coreferenceSuppliedCast":resolver.resolve(&case.entity_text,&supplied,None),
                "coreferenceDetectedCast":resolver.resolve(&case.entity_text,&discovered,None),
                "dialogueSuppliedCast":dialogue::extract_dialogue(&case.quotation_text,0,&case.supplied_cast),
                "dialogueDetectedCast":dialogue::extract_dialogue(&case.quotation_text,0,&detected),
                "detectedCastTruncated":persons.len()>256,
            })
        });
        let mut output = match prediction {
            Ok(value) => value,
            Err(_) => json!({"failure":"analysis_panicked"}),
        };
        output["id"] = json!(case.id);
        output["split"] = json!(case.split);
        output["runtimeMs"] = json!(started.elapsed().as_secs_f64() * 1000.0);
        output["modelMode"] =
            json!("default features; no trained models; heuristic person extraction");
        println!("{}", serde_json::to_string(&output)?);
    }
    Ok(())
}
