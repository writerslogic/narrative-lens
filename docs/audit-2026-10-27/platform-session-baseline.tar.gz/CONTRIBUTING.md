# Contributing to narrative-lens

Thanks for considering a contribution. This project extracts Emathy's manuscript-analysis
engine into a standalone, dependency-light crate -- keep that scope in mind: analyzers here
are stateless (text in, a structured result out), with no project model, storage, or
versioning. That belongs in a consuming application, not here.

## Reporting bugs and suggesting enhancements

Use the [GitHub issue tracker](https://github.com/writerslogic/narrative-lens/issues). For a bug, include the passage you analyzed, the result you got, the result you expected, and the crate or package version. For an enhancement, say which category it belongs to (craft, structure, continuity) and what a realistic test passage would look like. For security issues, follow [SECURITY.md](./SECURITY.md) instead of opening a public issue.

## Development setup

```bash
git clone https://github.com/writerslogic/narrative-lens.git
cd narrative-lens
cargo build
cargo test
```

For the Node bindings:

```bash
npm install
npm run build:debug
npm test
```

## Before opening a PR

- `cargo test` and `cargo clippy --all-targets -- -D warnings` pass.
- New analyzers include a test against at least one realistic passage, with the expected
  result authored independently of the analyzer's own implementation -- a fixture written by
  reading only the input text, not the code that will judge it.
- Public wire changes regenerate manuscript and standalone contracts with
  `cargo run --locked --features bindings --example export_contracts` and
  `cargo run --locked --features bindings --example export_standalone_contracts`.
  Run `npm run test:types`, `npm run test:contracts`, and `npm run test:package`
  after building the addon. Generated declarations and schemas are not hand-edited.
- Update `docs/ARCHITECTURE.md` if analyzer categories or availability change.
- Verify pinned readability data with `uv run --no-project scripts/verify_readability_resources.py`.
  When changing model profiles, execute the native fixture tests and the WASI
  runner in CI; compare label permutations and tied logits as well as tensor shapes.

## Fuzzing

Install nightly Rust and `cargo-fuzz`, then run the text-analysis target:

```bash
rustup toolchain install nightly
cargo install cargo-fuzz --version 0.13.2 --locked
cargo +nightly fuzz run text_analysis -- -max_total_time=120 -max_len=4096 -timeout=10
```

The target checks Unicode offset conversion, finite readability scores, and
dialogue confidence bounds while exercising grammar checking. GitHub Actions
runs it on pushes, pull requests, and daily; failing inputs are uploaded as
artifacts. Turn a minimized failing input into a regression test before fixing it.

## Adding an analyzer

Pick the category it belongs to (`craft`, `structure`, `continuity`) based on what it
answers, not what techniques it uses -- a craft analyzer using an embedding model is still
a craft analyzer. Each analyzer is a pure function: no filesystem access, no network call,
no shared mutable state across calls beyond what's passed in via `Options`.

## Code of Conduct

This project follows the [Contributor Covenant](./CODE_OF_CONDUCT.md).
