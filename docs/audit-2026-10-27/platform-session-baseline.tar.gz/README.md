### narrative-lens

<img align="left" width="96" src="assets/logo-black.svg" alt="narrative-lens logo">

Local, deterministic prose and narrative-craft analysis (readability, pacing, voice, foreshadowing, continuity) with no LLM and no network call. Extracted from Emathy's meaning engine, for Rust and Node.

<br clear="left">

[![CI](https://img.shields.io/github/actions/workflow/status/writerslogic/narrative-lens/ci.yml?branch=main&label=CI)](https://github.com/writerslogic/narrative-lens/actions/workflows/ci.yml) [![CodeQL](https://github.com/writerslogic/narrative-lens/actions/workflows/codeql.yml/badge.svg?branch=main)](https://github.com/writerslogic/narrative-lens/actions/workflows/codeql.yml) [![OpenSSF Scorecard](https://img.shields.io/ossf-scorecard/github.com/writerslogic/narrative-lens)](https://securityscorecards.dev/viewer/?uri=github.com/writerslogic/narrative-lens) [![npm](https://img.shields.io/npm/v/narrative-lens.svg)](https://www.npmjs.com/package/narrative-lens) [![License](https://img.shields.io/badge/license-Apache--2.0-blue)](https://github.com/writerslogic/narrative-lens/blob/main/LICENSE)

<p align="center">
  <a href="#install">Install</a> &middot;
  <a href="#what-it-analyzes">What It Analyzes</a> &middot;
  <a href="#api">API</a> &middot;
  <a href="#guides">Guides</a> &middot;
  <a href="#contributing">Contributing</a>
</p>

---

narrative-lens analyzes passages and manuscripts with local heuristics and optional local models. Standalone analyzers return their own metrics and suggestions; the manuscript facade adds consistent findings, original-text evidence, author controls, coverage, and revision comparisons. Confidence is explicitly uncalibrated unless identified otherwise. These are review aids, not editorial validation.

The analysis layer was originally built inside Emathy, a native macOS authoring app. The standalone crate lets other tools use the same local analysis without sending manuscript text to a service.

Run [the Rust example](examples/manuscript.rs) or [the async Node example](examples/manuscript.mjs) to analyze a manuscript and compare revisions.

Requires Rust 1.89+ or Node.js 18+, on macOS, Linux, and Windows.

## Install

```bash
npm install narrative-lens
```

```toml
[dependencies]
narrative-lens = "0.1"
```

<details>
<summary><strong>Optional: local ONNX models for embeddings, NER, NLI, and emotion</strong></summary>

The default analyzers are pure Rust with no model to load. Enable `onnx` for local SBERT embeddings, BERT NER, NLI and Ekman-7 emotion classification. Verified setters pin model/tokenizer bytes and validate declared preprocessing and label mappings; Node exposes `loadVerifiedModel`, and the CLI accepts `--model-root`/`--model-profile`. No model is downloaded. See [integration](docs/INTEGRATION.md).

</details>

## What It Analyzes

**Prose craft** — readability, pacing, prose quality, dialogue realism, voice consistency, sentence-level syntax tension, lexical variety, grammar. Subtext is reserved and explicitly unavailable.

**Narrative structure** — foreshadowing, a partial inferred promise/payoff ledger, source-validated author setup/resolution annotations, theme presence, model-backed semantic novelty, opening-page analysis, and supported genre-convention checks. Unobserved payoffs and unsupported conventions remain unknown; thematic argument is reserved and unavailable.

**Continuity and world state** — timeline consistency, explicit physical-state tracking with full or compact output, source-validated author truth/belief/knowledge and communication annotations, coreference and named-entity resolution, partial causal/epistemic heuristics, anachronism detection and supplied gap signals. Unannotated knowledge remains unassessed; prose alone does not establish false beliefs or causal necessity.

Analyzers accept caller-supplied text and return structured results. Confidence and evidence availability vary by standalone analyzer. The optional manuscript facade reports those distinctions explicitly. Persistence and project storage belong to the caller.

## API

<details>
<summary><strong>Rust</strong> -- analyzers, types, feature flags</summary>

| Module | What it does |
|--------|-------------|
| `manuscript` | Coordinated findings, controls, coverage, chronology, incremental context, revision comparisons |
| `craft::*` | Readability, pacing, prose quality, dialogue, voice, subtext, syntax tension, lexical, grammar |
| `structure::*` | Foreshadowing, promise/payoff, theme, thematic argument, narrative entropy, opening analysis, genre compliance |
| `continuity::*` | Timeline, world state, coreference, entity/NER, causal chains, epistemic state, mental models, gap analysis, anachronism |
| `substrate::*` | Shared primitives: text segmentation, embeddings, confidence scoring, explanation generation |

Each standalone analyzer has its own signature, such as `readability::compute_readability(text)` and `grammar::check(text)`. `manuscript::analyze_manuscript(&Manuscript)` coordinates supported passes into a `Report`; `AnalysisContext` reuses scene intermediates after changes.

</details>

<details>
<summary><strong>Node.js</strong> -- the same analyzers, generated bindings</summary>

Most standalone analyzers are exposed through napi with precise TypeScript declarations in `index.d.ts`. The manuscript API references `manuscript.d.ts`. Use `analyzeManuscriptAsync`, `ManuscriptContext.analyzeAsync`, and `compareManuscriptReports` for responsive manuscript workflows. See the integration guide for coverage.

</details>

## Guides

- **[Architecture](./docs/ARCHITECTURE.md)** -- the analyzer categories, the shared substrate, and what's reserved vs. shipped
- **[Integration](./docs/INTEGRATION.md)** -- using narrative-lens from Rust, Node, and as a local analysis backend for an MCP server
- **[Manuscript API](./docs/MANUSCRIPT.md)** -- findings, author controls, coverage, chronology, caching, comparisons, and async Node
- **[CLI](./docs/CLI.md)** -- optional text/Markdown adapter, JSON, SARIF, baselines, and exit codes
- **[Evaluation](./docs/EVALUATION.md)** -- reproducible synthetic accuracy fixtures and performance measurements
- **[Contributing](./CONTRIBUTING.md)** -- development setup and conventions

## Requirements

- **Rust 1.89+** or **Node.js 18+**; optional native ONNX builds require Rust 1.92+, and WASM ONNX/tract requires Rust 1.91+
- No API key, no network access, no external service of any kind

## Development

```bash
git clone https://github.com/writerslogic/narrative-lens.git
cd narrative-lens
cargo test                          # all analyzer categories, Rust side
npm ci && npm run build:debug && npm test  # native tests fail if the addon is missing
npm run test:types                  # strict TS check against generated bindings
```

## Why narrative-lens

Readability formulas, mechanical checks, and explicit state tracking can run locally on the caller’s text. narrative-lens gives editors, MCP servers, and manuscript CI tools deterministic results with inspectable evidence. Craft and continuity heuristics still need author judgment; supported patterns, evaluation limits, and measured performance are documented.

## Contributing

We welcome contributions of all sizes. Check the [issue tracker](https://github.com/writerslogic/narrative-lens/issues) for `good first issue` labels, or see [CONTRIBUTING.md](./CONTRIBUTING.md) for development setup.

**Areas where help is especially welcome:**
- Additional language support for the craft and structure analyzers (currently English-tuned)
- Evaluation fixtures for the continuity analyzers against real manuscript excerpts
- Integration examples for MCP servers and other manuscript tooling beyond Emathy and scrivener-mcp

## Security

Found a vulnerability? Please report it privately — see [SECURITY.md](./SECURITY.md).

## License

Apache-2.0 &copy; [WritersLogic, Inc.](https://github.com/writerslogic)

<p align="center">
  <a href="https://github.com/writerslogic/narrative-lens">GitHub</a> &middot;
  <a href="https://www.npmjs.com/package/narrative-lens">npm</a> &middot;
  <a href="https://crates.io/crates/narrative-lens">crates.io</a> &middot;
  <a href="https://github.com/writerslogic/narrative-lens/issues">Issues</a> &middot;
  <a href="./CHANGELOG.md">Changelog</a>
</p>
