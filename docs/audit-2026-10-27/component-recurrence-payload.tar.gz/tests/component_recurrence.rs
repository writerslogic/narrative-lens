use narrative_lens::structure::foreshadow::analyze_foreshadowing;

#[test]
fn caller_token_case_does_not_change_emphasis_candidates() {
    let mut scenes = vec![Vec::<String>::new(); 9];
    scenes[0] = vec!["noticed".into(), "reliquary".into()];
    scenes[4] = vec!["reliquary".into()];
    let lower = analyze_foreshadowing(scenes.clone(), 9);
    for tokens in &mut scenes {
        for token in tokens {
            *token = token.to_uppercase();
        }
    }
    let upper = analyze_foreshadowing(scenes, 9);
    assert_eq!(
        lower.iter().map(|x| &x.setup_term).collect::<Vec<_>>(),
        upper.iter().map(|x| &x.setup_term).collect::<Vec<_>>()
    );
}

fn workload(size: usize) -> Vec<Vec<String>> {
    let terms: Vec<_> = (0..size)
        .map(|mut n| {
            let mut suffix = String::new();
            loop {
                suffix.push((b'a' + (n % 26) as u8) as char);
                n /= 26;
                if n == 0 {
                    break;
                }
            }
            format!("zzq{suffix}")
        })
        .collect();
    let mut scenes = vec![vec!["ordinary".into()]; 9];
    scenes[0] = terms.clone();
    scenes[0].insert(0, "noticed".into());
    scenes[8] = terms;
    scenes[8].extend(["blood".into(), "danger".into(), "used".into()]);
    scenes
}

fn fingerprint(value: &[narrative_lens::structure::foreshadow::ForeshadowingItem]) -> String {
    let projection: Vec<_> = value
        .iter()
        .map(|x| {
            (
                &x.setup_term,
                x.setup_scene,
                x.setup_count,
                x.payoff_count,
                x.last_recurrence_scene,
                x.recurrence_signal,
            )
        })
        .collect();
    let bytes = serde_json::to_vec(&projection).unwrap();
    let hash = bytes.into_iter().fold(0xcbf29ce484222325u64, |hash, byte| {
        (hash ^ byte as u64).wrapping_mul(0x100000001b3)
    });
    format!("{hash:016x}")
}

#[test]
#[ignore = "bounded release benchmark;timings are observations,not CI thresholds"]
fn legacy_recurrence_performance() {
    for size in [256, 1024, 4096] {
        let input = workload(size);
        std::hint::black_box(analyze_foreshadowing(input.clone(), 9));
        let mut times = Vec::new();
        let mut sig = String::new();
        let mut count = 0;
        for _ in 0..5 {
            let input = input.clone();
            let begin = std::time::Instant::now();
            let result = analyze_foreshadowing(std::hint::black_box(input), 9);
            times.push(begin.elapsed().as_secs_f64() * 1000.0);
            let next = fingerprint(&result);
            if !sig.is_empty() {
                assert_eq!(sig, next);
            }
            sig = next;
            count = result.len();
            std::hint::black_box(result);
        }
        times.sort_by(f64::total_cmp);
        println!(
            "{}",
            serde_json::json!({"workload":"9 scenes,unique alphabetic rare terms in setup and final scene,no middle mentions","vocabulary":size,"samplesMs":times,"medianMs":times[2],"findings":count,"semanticFingerprintFNV1a64":sig,"timingScope":"analysis+returned output;input clone and static dictionary warmup excluded"})
        );
    }
}

use narrative_lens::{
    manuscript::{Manuscript, Scene},
    structure::foreshadow::{
        RecurrenceOptions, RecurrenceTerm, analyze_foreshadowing_checked, track_recurrences,
    },
    substrate::utils::AnalysisAvailability,
};
fn manuscript(texts: &[&str]) -> Manuscript {
    Manuscript {
        document_id: "recurrence".into(),
        scenes: texts
            .iter()
            .enumerate()
            .map(|(i, text)| Scene::new(format!("s{i}"), *text))
            .collect(),
        known_characters: vec![],
        configuration: Default::default(),
    }
}
fn term(id: &str, text: &str) -> RecurrenceTerm {
    RecurrenceTerm {
        id: id.into(),
        term: text.into(),
    }
}

#[test]
fn literal_terms_preserve_unicode_source_and_overlapping_phrase_occurrences() {
    let m = manuscript(&[
        "🜂İ ÉPÉE beside a red scarf. Scarf.",
        "nothing here",
        "épée RED SCARF returns.",
    ]);
    let terms = [
        term("unicode", "İ"),
        term("accent", "épée"),
        term("phrase", "red scarf"),
        term("word", "scarf"),
    ];
    let result = track_recurrences(&m, &terms, &Default::default()).unwrap();
    assert_eq!(result.availability, AnalysisAvailability::Complete);
    assert!(!result.payoff_assessed);
    for item in &result.terms {
        let expected = match item.id.as_str() {
            "unicode" => 1,
            "word" => 3,
            _ => 2,
        };
        assert_eq!(item.total_count, expected);
        assert_eq!(item.omitted_occurrence_count, 0);
        for e in &item.occurrences {
            let source = &m
                .scenes
                .iter()
                .find(|scene| scene.id == e.scene_id)
                .unwrap()
                .text;
            assert_eq!(&source[e.range.byte_start..e.range.byte_end], e.quote);
            assert_eq!(
                source[..e.range.byte_start].encode_utf16().count() as u32,
                e.range.utf16_start
            );
            assert_eq!(
                source[..e.range.byte_end].encode_utf16().count() as u32,
                e.range.utf16_end
            );
        }
    }
    assert_eq!(result.setup_end_scene_exclusive, 1);
    assert_eq!(result.later_start_scene, 2);
    assert!(
        result
            .terms
            .iter()
            .find(|x| x.id == "phrase")
            .unwrap()
            .late_recurrence_after_gap
    );
    let mut reordered = terms.to_vec();
    reordered.reverse();
    assert_eq!(
        serde_json::to_value(&result).unwrap(),
        serde_json::to_value(track_recurrences(&m, &reordered, &Default::default()).unwrap())
            .unwrap()
    );
}

#[test]
fn folded_chunk_boundaries_do_not_duplicate_or_invent_word_matches() {
    for offset in [32765, 32767, 32768, 32769, 65534] {
        let text = format!(
            "{}İ red scarf {} end",
            " ".repeat(offset),
            "x".repeat(32768)
        );
        let m = manuscript(&[&text]);
        let result = track_recurrences(
            &m,
            &[
                term("i", "İ"),
                term("p", "red scarf"),
                term("s", "scarf"),
                term("suffix", "xxx"),
            ],
            &Default::default(),
        )
        .unwrap();
        for t in result.terms {
            assert_eq!(
                t.total_count,
                usize::from(t.id != "suffix"),
                "offset{offset}:{}",
                t.id
            );
        }
    }
    let m = manuscript(&["İ i I ı"]);
    let result = track_recurrences(&m, &[term("i", "i")], &Default::default()).unwrap();
    assert_eq!(result.terms[0].total_count, 2);
}

#[test]
fn current_counts_and_global_retention_are_independent_and_reordering_is_explicit() {
    let m = manuscript(&["scarf red scarf", "scarf", "red scarf scarf"]);
    let terms = [term("b", "scarf"), term("a", "red scarf")];
    let full = track_recurrences(&m, &terms, &Default::default()).unwrap();
    for max in [0, 1, 2, 3] {
        let capped = track_recurrences(
            &m,
            &terms,
            &RecurrenceOptions {
                include_occurrences: true,
                max_occurrences: max,
            },
        )
        .unwrap();
        assert_eq!(capped.retained_occurrence_count, max);
        for (a, b) in full.terms.iter().zip(capped.terms) {
            assert_eq!(a.total_count, b.total_count);
            assert_eq!(a.scene_count, b.scene_count);
            assert_eq!(
                b.total_count,
                b.occurrences.len() + b.omitted_occurrence_count
            );
        }
    }
    let counts = track_recurrences(
        &m,
        &terms,
        &RecurrenceOptions {
            include_occurrences: false,
            max_occurrences: 10000,
        },
    )
    .unwrap();
    assert_eq!(counts.retained_occurrence_count, 0);
    assert!(
        counts
            .terms
            .iter()
            .all(|t| t.omitted_occurrence_count == t.total_count)
    );
    let mut reordered = m.clone();
    reordered.scenes.reverse();
    let after = track_recurrences(&reordered, &terms, &Default::default()).unwrap();
    for (before, after) in full.terms.iter().zip(after.terms) {
        assert_eq!(before.total_count, after.total_count);
        assert_eq!(after.first_scene_id.as_deref(), Some("s2"));
        for e in after.occurrences {
            assert!(reordered.scenes.iter().any(|s| s.id == e.scene_id));
        }
    }
}

#[test]
fn measured_zero_empty_cast_and_short_manuscripts_never_invent_a_payoff() {
    for texts in [vec![""], vec!["relic"], vec!["relic", "relic"]] {
        let m = manuscript(&texts);
        let result = track_recurrences(
            &m,
            &[term("r", "relic"), term("unknown", "absent")],
            &Default::default(),
        )
        .unwrap();
        assert_eq!(result.availability, AnalysisAvailability::Complete);
        assert_eq!(result.setup_end_scene_exclusive, 0);
        assert_eq!(result.later_start_scene, m.scenes.len());
        assert!(
            result
                .terms
                .iter()
                .all(|t| t.setup_count == 0 && t.later_count == 0 && !t.late_recurrence_after_gap)
        );
        assert_eq!(
            result
                .terms
                .iter()
                .find(|t| t.id == "unknown")
                .unwrap()
                .total_count,
            0
        );
    }
    assert_eq!(
        track_recurrences(&manuscript(&[]), &[term("r", "relic")], &Default::default())
            .unwrap()
            .availability,
        AnalysisAvailability::Unavailable
    );
}

#[test]
fn token_signal_math_uses_actual_local_counts_without_fulfillment_claims() {
    let mut scenes = vec![vec![]; 9];
    scenes[0] = vec!["zzqrelic".into()];
    scenes[6] = vec!["zzqrelic".into()];
    let first = analyze_foreshadowing_checked(scenes.clone(), 9).unwrap();
    let item = first.iter().find(|x| x.setup_term == "zzqrelic").unwrap();
    assert!((item.recurrence_signal - 0.3).abs() < 1e-12);
    assert_eq!(item.last_recurrence_scene, Some(6));
    assert!(item.payoff_scene.is_none());
    assert!(!item.payoff_assessed);
    assert_eq!(item.status, "later_recurrence_observed");
    scenes[6] = vec!["zzqrelic".into(), "blood".into(), "zzqrelic".into()];
    let result = analyze_foreshadowing_checked(scenes, 9).unwrap();
    let item = result.iter().find(|x| x.setup_term == "zzqrelic").unwrap();
    assert!((item.recurrence_signal - 0.45).abs() < 1e-12);
    assert_eq!(item.payoff_count, 2);
}

#[test]
fn term_identity_literal_size_retention_and_scene_limits_are_checked() {
    let m = manuscript(&["x"]);
    assert!(
        track_recurrences(
            &m,
            &[term("same", "one"), term("same", "two")],
            &Default::default()
        )
        .is_err()
    );
    assert!(
        track_recurrences(
            &m,
            &[term("a", "İ"), term("b", "i\u{307}")],
            &Default::default()
        )
        .is_err()
    );
    for value in ["", " x", "x ", "x\n"] {
        assert!(track_recurrences(&m, &[term("x", value)], &Default::default()).is_err());
    }
    for size in [127, 128, 129] {
        assert_eq!(
            track_recurrences(&m, &[term("x", &"x".repeat(size))], &Default::default()).is_ok(),
            size <= 128
        );
    }
    for count in [255, 256, 257] {
        let terms: Vec<_> = (0..count)
            .map(|i| term(&format!("t{i}"), &format!("word{i}")))
            .collect();
        assert_eq!(
            track_recurrences(&m, &terms, &Default::default()).is_ok(),
            count <= 256
        );
    }
    for max in [9999, 10000, 10001] {
        assert_eq!(
            track_recurrences(
                &m,
                &[],
                &RecurrenceOptions {
                    include_occurrences: false,
                    max_occurrences: max
                }
            )
            .is_ok(),
            max <= 10000
        );
    }
    assert!(analyze_foreshadowing_checked(vec![vec![]; 3], 2).is_err());
    for count in [9999, 10000, 10001] {
        assert_eq!(
            analyze_foreshadowing_checked(vec![vec![]; count], count).is_ok(),
            count <= 10000
        );
    }
    for length in [4095, 4096, 4097] {
        assert_eq!(
            analyze_foreshadowing_checked(vec![vec!["x".repeat(length)]], 1).is_ok(),
            length <= 4096
        );
    }
}

#[test]
fn token_and_candidate_budgets_are_boundaries_not_silent_truncation() {
    for count in [999999, 1000000, 1000001] {
        let mut scenes = vec![vec![]; 3];
        scenes[0] = vec!["x".into(); count];
        assert_eq!(
            analyze_foreshadowing_checked(scenes, 3).is_ok(),
            count <= 1000000
        );
    }
    for count in [9999, 10000, 10001] {
        assert_eq!(
            analyze_foreshadowing_checked(workload(count - 1), 9).is_ok(),
            count <= 10000
        );
    }
    for count in [99999, 100000, 100001] {
        let mut scenes = workload(count);
        scenes[0].remove(0);
        scenes[1].clear();
        scenes[2].clear();
        scenes[8].clear();
        assert_eq!(
            analyze_foreshadowing_checked(scenes, 9).is_ok(),
            count <= 100000
        );
    }
}

fn byte_scene(bytes: usize) -> Vec<String> {
    let mut result = vec!["x-".repeat(2048); bytes / 4096];
    if !bytes.is_multiple_of(4096) {
        result.push("x".repeat(bytes % 4096));
    }
    result
}
#[test]
fn per_scene_and_corpus_byte_budgets_cover_minus_equal_plus_one() {
    for bytes in [16 * 1024 * 1024 - 1, 16 * 1024 * 1024, 16 * 1024 * 1024 + 1] {
        assert_eq!(
            analyze_foreshadowing_checked(vec![byte_scene(bytes)], 1).is_ok(),
            bytes <= 16 * 1024 * 1024
        );
    }
    for delta in [-1isize, 0, 1] {
        let mut scenes = vec![byte_scene(16 * 1024 * 1024); 3];
        scenes.push(byte_scene((16 * 1024 * 1024isize + delta.min(0)) as usize));
        if delta > 0 {
            scenes.push(vec!["x".into()]);
        }
        let n = scenes.len();
        assert_eq!(analyze_foreshadowing_checked(scenes, n).is_ok(), delta <= 0);
    }
}
