use narrative_lens::{
    manuscript::{Manuscript, Scene},
    structure::foreshadow::{RecurrenceOptions, RecurrenceTerm, track_recurrences},
};
use std::{
    alloc::{GlobalAlloc, Layout, System},
    sync::atomic::{AtomicUsize, Ordering::Relaxed},
};
struct RequestedHeap;
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
fn added(bytes: usize) {
    let live = LIVE.fetch_add(bytes, Relaxed) + bytes;
    PEAK.fetch_max(live, Relaxed);
}
unsafe impl GlobalAlloc for RequestedHeap {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc(layout) };
        if !ptr.is_null() {
            added(layout.size());
        }
        ptr
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        LIVE.fetch_sub(layout.size(), Relaxed);
        unsafe { System.dealloc(ptr, layout) };
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let next = unsafe { System.realloc(ptr, layout, size) };
        if !next.is_null() {
            if size >= layout.size() {
                added(size - layout.size());
            } else {
                LIVE.fetch_sub(layout.size() - size, Relaxed);
            }
        }
        next
    }
}
#[global_allocator]
static ALLOCATOR: RequestedHeap = RequestedHeap;

#[test]
#[ignore = "optional release requested-heap profile;caller input and warmed static caches excluded"]
fn literal_recurrence_requested_heap() {
    let terms: Vec<_> = [
        ("u", "İ"),
        ("a", "épée"),
        ("w", "scarf"),
        ("p", "red scarf"),
    ]
    .into_iter()
    .map(|(id, term)| RecurrenceTerm {
        id: id.into(),
        term: term.into(),
    })
    .collect();
    for bytes in [64 * 1024, 1024 * 1024, 8 * 1024 * 1024] {
        let pattern = "Épée red scarf İ . ";
        let text = pattern.repeat(bytes / pattern.len());
        let manuscript = Manuscript {
            document_id: "heap".into(),
            scenes: vec![Scene::new("s", text)],
            known_characters: vec![],
            configuration: Default::default(),
        };
        for retain in [false, true] {
            let options = RecurrenceOptions {
                include_occurrences: retain,
                max_occurrences: 10000,
            };
            std::hint::black_box(track_recurrences(&manuscript, &terms, &options).unwrap());
            let mut samples = Vec::new();
            for _ in 0..3 {
                let baseline = LIVE.load(Relaxed);
                PEAK.store(baseline, Relaxed);
                let begin = std::time::Instant::now();
                let result =
                    track_recurrences(std::hint::black_box(&manuscript), &terms, &options).unwrap();
                let ms = begin.elapsed().as_secs_f64() * 1000.0;
                let peak = PEAK.load(Relaxed).saturating_sub(baseline);
                let retained = LIVE.load(Relaxed).saturating_sub(baseline);
                let matches: usize = result.terms.iter().map(|term| term.total_count).sum();
                samples.push(serde_json::json!({"ms":ms,"peakRequestedBytesAboveInput":peak,"retainedRequestedBytesAboveInput":retained,"retainedOccurrences":result.retained_occurrence_count,"totalLiteralMatches":matches}));
                drop(result);
            }
            println!(
                "{}",
                serde_json::json!({"sourceBytes":manuscript.scenes[0].text.len(),"retainOccurrences":retain,"samples":samples,"scope":"Rust global allocator requested live/peak bytes;caller manuscript and warmed caches excluded;single benchmark test;not RSS/native/JS heap;instrumented times not compared to uninstrumented legacy timings"})
            );
        }
    }
}
