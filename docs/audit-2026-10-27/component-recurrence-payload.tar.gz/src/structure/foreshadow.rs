use crate::substrate::utils::AnalysisAvailability;
use crate::{Error, Result};
use std::collections::{HashMap, HashSet};
use std::sync::OnceLock;
mod recurrence;
pub use recurrence::{
    RecurrenceOptions, RecurrenceResult, RecurrenceTerm, TermRecurrence, track_recurrences,
};

use crate::substrate::wordfreq::zipf_frequency;

#[cfg(test)]
use crate::substrate::text::tokenize_words;

/// Adjectives that mark symbolic objects when used in "the [adj] [noun]" patterns.
const SYMBOLIC_ADJECTIVES: &[&str] = &[
    "old",
    "ancient",
    "strange",
    "peculiar",
    "mysterious",
    "forgotten",
    "hidden",
    "locked",
    "sealed",
];

/// Phrases that signal explicit foreshadowing promise language.
/// Checked via substring match on the raw scene text.
const PROMISE_PHRASES: &[&str] = &[
    "little did",
    "would later prove",
    "one day",
    "if only",
    "someday",
    "it would not be the last time",
    "would come to regret",
    "did not yet know",
];

/// Action verbs that indicate a foreshadowed item has been resolved.
const RESOLUTION_VERBS: &[&str] = &[
    "used",
    "opened",
    "revealed",
    "discovered",
    "broke",
    "destroyed",
    "fired",
    "grabbed",
    "wielded",
    "unlocked",
    "shattered",
    "activated",
    "drew",
    "seized",
];

/// Words that signal deliberate emphasis on an object or detail.
const EMPHASIS_WORDS: &[&str] = &[
    "noticed",
    "caught",
    "unusual",
    "strange",
    "peculiar",
    "odd",
    "remarkable",
    "glint",
    "glimmer",
    "glimpse",
    "eyed",
    "stared",
    "fixated",
    "conspicuous",
    "unmistakable",
];

/// Words that signal high narrative tension.
const TENSION_WORDS: &[&str] = &[
    "scream",
    "screamed",
    "blood",
    "death",
    "die",
    "died",
    "kill",
    "killed",
    "gun",
    "knife",
    "shatter",
    "shattered",
    "explode",
    "exploded",
    "crash",
    "crashed",
    "desperate",
    "panic",
    "terror",
    "horror",
    "fear",
    "dread",
    "threat",
    "danger",
    "trembled",
    "gasped",
    "fled",
    "attack",
    "attacked",
    "fought",
    "struggle",
    "collapsed",
    "fury",
    "rage",
];

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ForeshadowingItem {
    #[serde(default)]
    pub availability: AnalysisAvailability,
    #[serde(default)]
    pub diagnostics: Vec<String>,
    #[serde(default)]
    pub payoff_assessed: bool,
    /// Uncalibrated recurrence/context index, never semantic payoff quality.
    pub recurrence_signal: f64,
    pub last_recurrence_scene: Option<usize>,
    pub setup_term: String,
    pub setup_scene: usize,
    /// Unassessed compatibility field;actual recurrence position is separate.
    pub payoff_scene: Option<usize>,
    pub setup_count: usize,
    pub payoff_count: usize,
    /// Unassessed compatibility placeholder0.5;inspect recurrence_signal instead.
    pub payoff_quality: f64,
    pub status: String,
    pub suggestion: String,
}

fn invalid(message: &str) -> Error {
    Error::InvalidInput(message.into())
}
fn eligible(word: &str) -> bool {
    word.chars().count() >= 3 && word.chars().all(char::is_alphabetic)
}
fn future_phrase(tokens: &[String]) -> bool {
    static MATCHER: OnceLock<crate::craft::lexicon::WordMatcher> = OnceLock::new();
    MATCHER
        .get_or_init(|| crate::craft::lexicon::WordMatcher::new(PROMISE_PHRASES))
        .is_match(&tokens.join(" "))
}
#[derive(Default)]
struct Setup {
    count: usize,
    first_scene: usize,
}
#[derive(Default)]
struct Later {
    count: usize,
    scene_count: usize,
    last_scene: usize,
}

/// Checked token heuristic. Counts and recurrence/context indices are observed;
/// semantic payoff, required fulfillment and author intent are unassessed.
pub fn analyze_foreshadowing_checked(
    mut scenes_tokens: Vec<Vec<String>>,
    total_scenes: usize,
) -> Result<Vec<ForeshadowingItem>> {
    if total_scenes != scenes_tokens.len() || total_scenes > 10_000 {
        return Err(invalid(
            "foreshadow scene count must match and not exceed 10000",
        ));
    }
    let mut bytes = 0usize;
    let mut tokens = 0usize;
    for scene in &scenes_tokens {
        let mut scene_bytes = 0usize;
        tokens = tokens
            .checked_add(scene.len())
            .filter(|count| *count <= 1_000_000)
            .ok_or_else(|| invalid("foreshadow exceeds 1000000 tokens"))?;
        for token in scene {
            if token.is_empty() || token.len() > 4096 {
                return Err(invalid("foreshadow tokens require 1..=4096 bytes"));
            }
            scene_bytes = scene_bytes
                .checked_add(token.len())
                .filter(|bytes| *bytes <= 16 * 1024 * 1024)
                .ok_or_else(|| invalid("foreshadow scene exceeds 16 MiB token bytes"))?;
        }
        bytes = bytes
            .checked_add(scene_bytes)
            .filter(|bytes| *bytes <= 64 * 1024 * 1024)
            .ok_or_else(|| invalid("foreshadow exceeds 64 MiB token bytes"))?;
    }
    if total_scenes < 3 {
        return Ok(Vec::new());
    }
    for scene in &mut scenes_tokens {
        for token in scene {
            if token.is_ascii() {
                token.make_ascii_lowercase();
            } else {
                *token = token.to_lowercase();
            }
        }
    }
    let n = total_scenes;
    let first_third = n / 3;
    let later_start = n - n / 3;
    let climax_start = n - n.max(7) / 7;
    let mut setup = HashMap::<String, Setup>::new();
    let mut later = HashMap::<String, Later>::new();
    let mut middle = HashSet::new();
    let mut emphasized = HashSet::new();
    let mut symbolic = HashSet::new();
    let mut future_context = HashSet::new();
    for (scene_index, scene) in scenes_tokens.iter().enumerate() {
        if scene_index < first_third {
            for word in scene.iter().filter(|word| eligible(word)) {
                let item = setup.entry(word.clone()).or_insert(Setup {
                    count: 0,
                    first_scene: scene_index,
                });
                item.count += 1;
                if setup.len() > 100_000 {
                    return Err(invalid("foreshadow exceeds 100000 setup terms"));
                }
            }
            for (index, word) in scene.iter().enumerate() {
                if EMPHASIS_WORDS.contains(&word.as_str()) {
                    emphasized.extend(
                        scene[index.saturating_sub(5)..(index + 6).min(scene.len())]
                            .iter()
                            .filter(|word| eligible(word))
                            .cloned(),
                    );
                }
            }
            for window in scene.windows(3) {
                if window[0] == "the"
                    && SYMBOLIC_ADJECTIVES.contains(&window[1].as_str())
                    && eligible(&window[2])
                {
                    symbolic.insert(window[2].clone());
                }
            }
            if future_phrase(scene) {
                future_context.extend(scene.iter().filter(|word| eligible(word)).cloned());
            }
        } else if scene_index < later_start {
            middle.extend(
                scene
                    .iter()
                    .filter(|word| setup.contains_key(*word))
                    .cloned(),
            );
        } else {
            for word in scene.iter().filter(|word| setup.contains_key(*word)) {
                let item = later.entry(word.clone()).or_default();
                if item.count == 0 || item.last_scene != scene_index {
                    item.scene_count += 1;
                }
                item.count += 1;
                item.last_scene = scene_index;
            }
        }
    }
    let candidates: HashSet<_> = setup
        .keys()
        .filter(|word| {
            zipf_frequency(word) < 5.0
                && ((!middle.contains(*word) && later.contains_key(*word))
                    || emphasized.contains(*word)
                    || symbolic.contains(*word))
        })
        .cloned()
        .collect();
    if candidates.len() > 10_000 {
        return Err(invalid("foreshadow exceeds 10000 findings"));
    }
    let mut tension_near = HashMap::<String, usize>::new();
    let mut action_near = HashSet::new();
    for (scene_index, scene) in scenes_tokens.iter().enumerate().skip(later_start) {
        for (index, word) in scene.iter().enumerate() {
            if TENSION_WORDS.contains(&word.as_str()) {
                for target in &scene[index.saturating_sub(8)..(index + 9).min(scene.len())] {
                    if candidates.contains(target) {
                        *tension_near.entry(target.clone()).or_default() += 1;
                    }
                }
            }
            if scene_index >= n - n / 4 && RESOLUTION_VERBS.contains(&word.as_str()) {
                action_near.extend(
                    scene[index.saturating_sub(6)..(index + 7).min(scene.len())]
                        .iter()
                        .filter(|word| candidates.contains(*word))
                        .cloned(),
                );
            }
        }
    }
    let mut results = Vec::with_capacity(candidates.len());
    for term in candidates {
        let early = &setup[&term];
        let late = later.get(&term);
        let count = late.map_or(0, |info| info.count);
        let signal = if let Some(late) = late {
            let in_final_band = late.last_scene >= climax_start;
            let mut value: f64 = 0.3;
            if late.scene_count >= 2 {
                value += 0.2;
            }
            if in_final_band {
                value += 0.25;
            }
            match tension_near.get(&term).copied().unwrap_or(0) {
                0 => {}
                1 => value += 0.08,
                _ => value += 0.15,
            }
            if action_near.contains(&term) {
                value += 0.15;
            }
            if symbolic.contains(&term) {
                value += 0.1;
            }
            if future_context.contains(&term) {
                value += 0.1;
            }
            if late.count == 1 && late.scene_count == 1 && !in_final_band {
                value = value.min(0.5);
            }
            value.clamp(0.0, 1.0)
        } else {
            0.0
        };
        let status = if early.count > 5 {
            "frequent_early_mentions"
        } else if count > 0 {
            "later_recurrence_observed"
        } else {
            "early_mentions_only"
        };
        let suggestion = format!(
            "Literal term has {} early and {} later-third mentions;semantic setup,required payoff and fulfillment are unassessed.",
            early.count, count
        );
        results.push(ForeshadowingItem {
            availability: AnalysisAvailability::Partial,
            diagnostics: vec![
                "token_recurrence_and_context_only;semantic_payoff_unassessed".into(),
            ],
            payoff_assessed: false,
            recurrence_signal: signal,
            last_recurrence_scene: late.map(|info| info.last_scene),
            setup_term: term,
            setup_scene: early.first_scene,
            payoff_scene: None,
            setup_count: early.count,
            payoff_count: count,
            payoff_quality: 0.5,
            status: status.into(),
            suggestion,
        });
    }
    results.sort_by(|a, b| {
        b.recurrence_signal
            .total_cmp(&a.recurrence_signal)
            .then_with(|| a.setup_scene.cmp(&b.setup_scene))
            .then_with(|| a.last_recurrence_scene.cmp(&b.last_recurrence_scene))
            .then_with(|| a.setup_term.cmp(&b.setup_term))
    });
    Ok(results)
}

pub fn analyze_foreshadowing(
    scenes_tokens: Vec<Vec<String>>,
    total_scenes: usize,
) -> Vec<ForeshadowingItem> {
    analyze_foreshadowing_checked(scenes_tokens, total_scenes).unwrap_or_else(|_| {
        log::warn!("foreshadow unavailable:invalid input;use checked API");
        Vec::new()
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_scene(words: &str) -> Vec<String> {
        tokenize_words(words)
    }

    #[test]
    fn test_too_few_scenes() {
        let scenes = vec![make_scene("hello world")];
        let result = analyze_foreshadowing(scenes, 1);
        assert!(result.is_empty());
    }

    #[test]
    fn test_classic_chekhov_gun() {
        // 9 scenes: setup (0-2), middle (3-5), payoff (6-8)
        let scenes = vec![
            // Setup: introduce "revolver" near emphasis
            make_scene("She noticed the peculiar revolver hanging on the wall"),
            make_scene("The old revolver gleamed in morning light"),
            make_scene("She wondered about the revolver again"),
            // Middle: no mention of revolver
            make_scene("They traveled across the countryside"),
            make_scene("The storm gathered over the hills"),
            make_scene("Arguments erupted at dinner"),
            // Payoff: revolver returns with tension
            make_scene("He grabbed the revolver from the wall"),
            make_scene("The revolver exploded with a deafening crash"),
            make_scene("The revolver fell to the floor as panic spread"),
        ];
        let result = analyze_foreshadowing(scenes, 9);
        let revolver = result.iter().find(|r| r.setup_term == "revolver");
        assert!(
            revolver.is_some(),
            "Should detect 'revolver' as foreshadowing"
        );
        let r = revolver.unwrap();
        assert!(
            r.recurrence_signal >= 0.5,
            "Revolver should score at least moderate, got {}",
            r.recurrence_signal
        );
        assert!(r.payoff_count > 0);
        assert!(r.last_recurrence_scene.is_some());
        assert!(r.payoff_scene.is_none());
        assert!(!r.payoff_assessed);
    }

    #[test]
    fn test_unresolved_foreshadowing() {
        // 9 scenes: locket appears in setup only
        let scenes = vec![
            make_scene("She clutched the strange locket around her neck"),
            make_scene("The locket felt warm against her skin"),
            make_scene("She tucked the locket away"),
            make_scene("They marched through the forest"),
            make_scene("Rain fell on the weary travelers"),
            make_scene("Camp was set by the river"),
            make_scene("Dawn broke over the mountains"),
            make_scene("They reached the castle gates"),
            make_scene("The battle began at noon"),
        ];
        let result = analyze_foreshadowing(scenes, 9);
        let locket = result.iter().find(|r| r.setup_term == "locket");
        assert!(locket.is_some(), "Should detect 'locket' as unresolved");
        let l = locket.unwrap();
        assert_eq!(l.recurrence_signal, 0.0);
        assert_eq!(l.status, "early_mentions_only");
        assert!(l.suggestion.contains("unassessed"));
    }

    #[test]
    fn test_overcrowded() {
        // Term mentioned 6+ times in setup
        let scenes = vec![
            make_scene(
                "The dagger was sharp. The dagger gleamed. She held the dagger tightly. The dagger was ancient. Another dagger reference. The dagger shone.",
            ),
            make_scene("The dagger again"),
            make_scene("More about the dagger here"),
            make_scene("Walking in the garden"),
            make_scene("Nothing happened"),
            make_scene("Still nothing"),
            make_scene("The dagger appeared once more"),
            make_scene("She used the dagger"),
            make_scene("The dagger ended it all"),
        ];
        let result = analyze_foreshadowing(scenes, 9);
        let dagger = result.iter().find(|r| r.setup_term == "dagger");
        assert!(dagger.is_some(), "Should detect 'dagger'");
        let d = dagger.unwrap();
        assert_eq!(d.status, "frequent_early_mentions");
        assert!(d.suggestion.contains("unassessed"));
    }

    #[test]
    fn test_common_words_filtered() {
        // Common words (Zipf >= 5.0) should not be candidates
        let scenes = vec![
            make_scene("The door opened and the hand reached out"),
            make_scene("Another day with the door"),
            make_scene("The door was still there"),
            make_scene("Walking through the forest"),
            make_scene("Nothing special"),
            make_scene("Still nothing"),
            make_scene("The door opened again"),
            make_scene("She reached for the door"),
            make_scene("The door closed"),
        ];
        let result = analyze_foreshadowing(scenes, 9);
        // "door" and "hand" are common words, should be filtered
        let _door = result.iter().find(|r| r.setup_term == "door");
        // Depending on Zipf score, "door" may or may not be filtered.
        // But truly common words like "the", "and" should never appear.
        let the = result.iter().find(|r| r.setup_term == "the");
        assert!(the.is_none(), "'the' should be filtered as too common");
    }

    #[test]
    fn test_emphasis_detection() {
        // Word near emphasis markers should be detected even if it appears in middle
        let scenes = vec![
            make_scene("She noticed the peculiar medallion on the shelf"),
            make_scene("It was an ordinary morning"),
            make_scene("The sun rose slowly"),
            make_scene("The medallion sat there unnoticed"),
            make_scene("Days passed uneventfully"),
            make_scene("More time passed"),
            make_scene("The medallion was the key to everything"),
            make_scene("She grabbed the medallion"),
            make_scene("The medallion unlocked the gate with a crash"),
        ];
        let result = analyze_foreshadowing(scenes, 9);
        let medallion = result.iter().find(|r| r.setup_term == "medallion");
        assert!(
            medallion.is_some(),
            "Should detect 'medallion' via emphasis pattern"
        );
    }

    #[test]
    fn test_symbolic_object_detection() {
        // "the ancient chalice" should be detected as a symbolic object
        let scenes = vec![
            make_scene("On the mantle sat the ancient chalice covered in dust"),
            make_scene("The chalice gleamed when light struck it"),
            make_scene("She left the room thinking of the chalice"),
            make_scene("The journey continued through the plains"),
            make_scene("Nothing remarkable happened"),
            make_scene("They rested at camp"),
            make_scene("She grabbed the chalice and used it to open the door"),
            make_scene("The chalice revealed a hidden passage"),
            make_scene("The chalice shattered as the spell broke"),
        ];
        let result = analyze_foreshadowing(scenes, 9);
        let chalice = result.iter().find(|r| r.setup_term == "chalice");
        assert!(
            chalice.is_some(),
            "Should detect 'chalice' as symbolic object"
        );
        let c = chalice.unwrap();
        assert!(
            c.recurrence_signal > 0.0,
            "Chalice should have payoff quality"
        );
    }

    #[test]
    fn test_promise_phrase_detection() {
        // Promise language "little did she know" should boost detection
        let scenes = vec![
            make_scene(
                "She picked up the talisman. Little did she know it would change everything",
            ),
            make_scene("The talisman was warm to the touch"),
            make_scene("She carried the talisman in her pocket"),
            make_scene("The road was long and winding"),
            make_scene("They stopped at an inn"),
            make_scene("The night was uneventful"),
            make_scene("The talisman began to glow"),
            make_scene("She used the talisman against the darkness"),
            make_scene("The talisman destroyed the barrier"),
        ];
        let result = analyze_foreshadowing(scenes, 9);
        let talisman = result.iter().find(|r| r.setup_term == "talisman");
        assert!(
            talisman.is_some(),
            "Should detect 'talisman' via promise phrase"
        );
    }

    #[test]
    fn test_resolution_verb_bonus() {
        // Term reappearing near action verbs in final quarter gets bonus
        let scenes = vec![
            make_scene("The strange amulet hung on the wall"),
            make_scene("She eyed the amulet with curiosity"),
            make_scene("The amulet was forgotten"),
            make_scene("The village celebrated a festival"),
            make_scene("Days turned into weeks"),
            make_scene("Nothing changed in the village"),
            make_scene("She remembered the amulet"),
            make_scene("She grabbed the amulet and destroyed the seal"),
            make_scene("The amulet revealed the hidden truth at last"),
        ];
        let result = analyze_foreshadowing(scenes, 9);
        let amulet = result.iter().find(|r| r.setup_term == "amulet");
        assert!(amulet.is_some(), "Should detect 'amulet'");
        let a = amulet.unwrap();
        assert!(
            a.recurrence_signal >= 0.5,
            "Amulet with resolution verbs should score well, got {}",
            a.recurrence_signal
        );
    }
}
