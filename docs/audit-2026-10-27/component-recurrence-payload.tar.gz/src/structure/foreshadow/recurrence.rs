use crate::Result;
use crate::craft::{lexicon::WordMatcher, measurements};
use crate::manuscript::{Evidence, EvidenceRole, Manuscript, config::validate_id};
use crate::substrate::utils::AnalysisAvailability;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct RecurrenceTerm {
    pub id: String,
    pub term: String,
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct RecurrenceOptions {
    #[serde(default = "default_true")]
    pub include_occurrences: bool,
    #[serde(default = "default_limit")]
    pub max_occurrences: usize,
}
fn default_true() -> bool {
    true
}
fn default_limit() -> usize {
    10_000
}
impl Default for RecurrenceOptions {
    fn default() -> Self {
        Self {
            include_occurrences: true,
            max_occurrences: default_limit(),
        }
    }
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TermRecurrence {
    pub id: String,
    pub term: String,
    pub total_count: usize,
    pub scene_count: usize,
    pub setup_count: usize,
    pub middle_count: usize,
    pub later_count: usize,
    pub late_recurrence_after_gap: bool,
    pub first_scene_id: Option<String>,
    pub last_scene_id: Option<String>,
    pub occurrences: Vec<Evidence>,
    pub omitted_occurrence_count: usize,
}

#[cfg_attr(feature = "bindings", derive(ts_rs::TS, schemars::JsonSchema))]
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RecurrenceResult {
    pub document_id: String,
    pub availability: AnalysisAvailability,
    pub diagnostics: Vec<String>,
    pub payoff_assessed: bool,
    pub setup_end_scene_exclusive: usize,
    pub later_start_scene: usize,
    pub retained_occurrence_count: usize,
    pub terms: Vec<TermRecurrence>,
}

#[derive(Default)]
struct Counts {
    total: usize,
    scenes: usize,
    setup: usize,
    middle: usize,
    later: usize,
    first: Option<usize>,
    last: Option<usize>,
}

fn boundary_after(text: &str, mut byte: usize) -> usize {
    while !text.is_char_boundary(byte) {
        byte += 1;
    }
    byte
}

/// Track supplied literal whole-word/phrase terms, without inferring motifs or
/// semantic payoff. Matching uses Unicode lowercase (not normalization, stemming
/// or full casefold). Original source boundaries survive expanding lowercase.
/// IDs are stable; thirds/first/last project current presentation order. For fewer
/// than three scenes all matches belong to the middle and no gap arc is claimed.
/// Retention is globally capped by earliest(scene,start,term ID,end);counts remain
/// complete when source occurrences are disabled or capped.
pub fn track_recurrences(
    manuscript: &Manuscript,
    terms: &[RecurrenceTerm],
    options: &RecurrenceOptions,
) -> Result<RecurrenceResult> {
    if terms.len() > 256 || options.max_occurrences > 10_000 {
        return Err(super::invalid(
            "recurrence exceeds 256 terms or 10000 retained occurrences",
        ));
    }
    manuscript.validate()?;
    let mut ordered: Vec<_> = terms.iter().collect();
    ordered.sort_by(|a, b| a.id.cmp(&b.id));
    let mut ids = BTreeSet::new();
    let mut normalized = BTreeMap::new();
    for (index, term) in ordered.iter().enumerate() {
        validate_id(&term.id)?;
        if !ids.insert(term.id.as_str()) {
            return Err(super::invalid("recurrence term IDs must be unique"));
        }
        if term.term.is_empty()
            || term.term.trim() != term.term
            || term.term.len() > 128
            || term.term.chars().any(char::is_control)
        {
            return Err(super::invalid(
                "recurrence terms require 1..=128 unpadded bytes and no controls",
            ));
        }
        if normalized.insert(term.term.to_lowercase(), index).is_some() {
            return Err(super::invalid(
                "recurrence terms must be unique after Unicode lowercase",
            ));
        }
    }
    let patterns: Vec<_> = normalized.keys().map(String::as_str).collect();
    let matcher = WordMatcher::new(&patterns);
    let lookahead = patterns.iter().map(|p| p.len()).max().unwrap_or(0) * 4 + 4;
    let n = manuscript.scenes.len();
    let setup_end = n / 3;
    let later_start = n - n / 3;
    let mut counts: Vec<_> = (0..terms.len()).map(|_| Counts::default()).collect();
    let mut retained = BTreeSet::<(usize, usize, usize, usize)>::new();
    if !terms.is_empty() {
        for (scene_index, scene) in manuscript.scenes.iter().enumerate() {
            let text = &scene.text;
            let mut start = 0;
            while start < text.len() {
                let end = boundary_after(text, (start + 32 * 1024).min(text.len()));
                let window_start = if start == 0 {
                    0
                } else {
                    text[..start]
                        .char_indices()
                        .next_back()
                        .expect("prior character")
                        .0
                };
                let window_end = boundary_after(text, (end + lookahead).min(text.len()));
                let mut folded = String::new();
                let mut boundaries = vec![(0usize, window_start)];
                for (position, ch) in text[window_start..window_end].char_indices() {
                    folded.extend(ch.to_lowercase());
                    boundaries.push((folded.len(), window_start + position + ch.len_utf8()));
                }
                for hit in matcher.find_iter(&folded) {
                    let (Ok(begin), Ok(stop)) = (
                        boundaries.binary_search_by_key(&hit.start, |point| point.0),
                        boundaries.binary_search_by_key(&hit.end, |point| point.0),
                    ) else {
                        continue;
                    };
                    let begin = boundaries[begin].1;
                    let stop = boundaries[stop].1;
                    if begin < start || begin >= end {
                        continue;
                    }
                    let index = normalized[hit.text];
                    let count = &mut counts[index];
                    count.total += 1;
                    if count.last != Some(scene_index) {
                        count.scenes += 1;
                    }
                    count.first.get_or_insert(scene_index);
                    count.last = Some(scene_index);
                    if scene_index < setup_end {
                        count.setup += 1;
                    } else if scene_index >= later_start {
                        count.later += 1;
                    } else {
                        count.middle += 1;
                    }
                    if options.include_occurrences && options.max_occurrences > 0 {
                        let key = (scene_index, begin, index, stop);
                        if retained.len() < options.max_occurrences
                            || retained.last().is_some_and(|last| key < *last)
                        {
                            retained.insert(key);
                            if retained.len() > options.max_occurrences {
                                retained.pop_last();
                            }
                        }
                    }
                }
                start = end;
            }
        }
    }
    let retained_occurrence_count = retained.len();
    let mut output: Vec<_> = ordered
        .iter()
        .zip(&counts)
        .map(|(term, count)| TermRecurrence {
            id: term.id.clone(),
            term: term.term.clone(),
            total_count: count.total,
            scene_count: count.scenes,
            setup_count: count.setup,
            middle_count: count.middle,
            later_count: count.later,
            late_recurrence_after_gap: count.setup > 0 && count.later > 0 && count.middle == 0,
            first_scene_id: count.first.map(|i| manuscript.scenes[i].id.clone()),
            last_scene_id: count.last.map(|i| manuscript.scenes[i].id.clone()),
            occurrences: Vec::new(),
            omitted_occurrence_count: count.total,
        })
        .collect();
    let mut retained = retained.into_iter().peekable();
    for (scene_index, scene) in manuscript.scenes.iter().enumerate() {
        let mut selected = Vec::new();
        while retained.peek().is_some_and(|key| key.0 == scene_index) {
            selected.push(retained.next().expect("selected source key"));
        }
        let spans: Vec<_> = selected.iter().map(|key| (key.1, key.3)).collect();
        for (key, range) in selected
            .into_iter()
            .zip(measurements::ranges(&scene.text, &spans)?)
        {
            let item = &mut output[key.2];
            item.omitted_occurrence_count -= 1;
            item.occurrences.push(Evidence {
                document_id: manuscript.document_id.clone(),
                scene_id: scene.id.clone(),
                range,
                quote: scene.text[key.1..key.3].into(),
                role: EvidenceRole::Primary,
                context: None,
            });
        }
    }
    Ok(RecurrenceResult {document_id:manuscript.document_id.clone(),
        availability:if terms.is_empty()||manuscript.scenes.is_empty(){AnalysisAvailability::Unavailable}else{AnalysisAvailability::Complete},
        diagnostics:vec!["literal_recurrence_only;semantic_setup_payoff_and_fulfillment_unassessed".into(),
            "Unicode_lowercase_whole_words;no_normalization_stemming_or_full_casefold;presentation_order_thirds".into()],
        payoff_assessed:false,setup_end_scene_exclusive:setup_end,later_start_scene:later_start,retained_occurrence_count,terms:output})
}
