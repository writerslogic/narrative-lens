use narrative_lens::structure::structure::{suggest_best_template, validate_structure};
#[test]
fn normalized_tension_contract_rejects_nonfinite_and_wrong_units() {
    for value in [f64::NAN, f64::INFINITY, -0.01, 1.01, 100.0] {
        assert!(validate_structure("three_act", vec![value], vec![]).is_err());
    }
}
#[test]
fn mismatched_nonempty_purpose_vectors_are_not_partly_ignored() {
    assert!(validate_structure("three_act", vec![0.1, 0.2], vec!["opening".into()]).is_err());
}
#[test]
fn unrelated_label_substrings_do_not_increase_positional_fit() {
    let baseline =
        validate_structure("three_act", vec![0.2; 20], vec!["ordinary".into(); 20]).unwrap();
    let collisions = validate_structure(
        "three_act",
        vec![0.2; 20],
        vec!["disappointment".into(); 20],
    )
    .unwrap();
    assert_eq!(baseline.health_pct, collisions.health_pct);
    let baseline =
        validate_structure("save_the_cat", vec![0.2; 20], vec!["ordinary".into(); 20]).unwrap();
    let collisions =
        validate_structure("save_the_cat", vec![0.2; 20], vec!["this".into(); 20]).unwrap();
    assert_eq!(baseline.health_pct, collisions.health_pct);
}
#[test]
fn empty_input_does_not_suggest_an_observed_template() {
    assert!(
        validate_structure("three_act", vec![], vec![])
            .unwrap()
            .suggested_template
            .is_empty()
    );
    assert!(suggest_best_template(vec![], vec![]).is_empty());
}
#[test]
fn unknown_template_errors_never_echo_unbounded_supplied_labels() {
    let error = validate_structure(&"private-unrecognized".repeat(10000), vec![], vec![])
        .unwrap_err()
        .to_string();
    assert!(!error.contains("private-unrecognized"));
}

use narrative_lens::{
    structure::structure::{get_structure_template, list_templates, suggest_best_template_checked},
    substrate::utils::AnalysisAvailability,
};
#[test]
fn fit_units_empty_availability_and_checked_selection_are_explicit() {
    let empty = validate_structure("nonlinear", vec![], vec![]).unwrap();
    assert_eq!(empty.availability, AnalysisAvailability::Unavailable);
    assert!(!empty.quality_assessed);
    assert_eq!(empty.scene_count, 0);
    assert!(
        suggest_best_template_checked(vec![], vec![])
            .unwrap()
            .is_none()
    );
    for name in list_templates() {
        let report = validate_structure(&name, vec![0.0, 0.5, 1.0], vec![]).unwrap();
        assert!((0.0..=100.0).contains(&report.health_pct));
        assert!(!report.quality_assessed);
        assert!(report.beat_details.iter().all(|b|(0.0..=1.0).contains(&b.confidence)&&(0.0..=1.0).contains(&b.actual_pct)));
        assert!(
            suggest_best_template_checked(vec![0.0, 0.5, 1.0], vec![])
                .unwrap()
                .is_some()
        );
    }
    let error = get_structure_template(&"private".repeat(10000))
        .unwrap_err()
        .to_string();
    assert!(!error.contains("private"));
}
#[test]
fn purpose_label_case_separator_normalization_is_coherent_and_order_is_stable() {
    let a = validate_structure(
        "three_act",
        vec![0.2; 20],
        vec!["Inciting Incident".into(); 20],
    )
    .unwrap();
    let b = validate_structure(
        "three_act",
        vec![0.2; 20],
        vec!["INCITING-INCIDENT".into(); 20],
    )
    .unwrap();
    assert_eq!(
        serde_json::to_value(&a).unwrap(),
        serde_json::to_value(b).unwrap()
    );
    for _ in 0..10 {
        assert_eq!(
            a.health_pct,
            validate_structure(
                "three_act",
                vec![0.2; 20],
                vec!["inciting_incident".into(); 20]
            )
            .unwrap()
            .health_pct
        );
    }
}
#[test]
fn scene_label_and_unit_limits_cover_minus_equal_plus_one() {
    for scenes in [9999, 10000, 10001] {
        assert_eq!(
            validate_structure("nonlinear", vec![0.5; scenes], vec![]).is_ok(),
            scenes <= 10000
        );
    }
    for bytes in [4095, 4096, 4097] {
        assert_eq!(
            validate_structure("nonlinear", vec![0.5], vec!["x".repeat(bytes)]).is_ok(),
            bytes <= 4096
        );
    }
    for delta in [-1isize, 0, 1] {
        let mut labels = vec!["x".repeat(4096); 1024];
        if delta < 0 {
            labels[1023].pop();
        } else if delta > 0 {
            labels.push("x".into());
        }
        assert_eq!(
            validate_structure("nonlinear", vec![0.5; labels.len()], labels).is_ok(),
            delta <= 0
        );
    }
    for value in [-f64::EPSILON, 0.0, 1.0, 1.0 + f64::EPSILON] {
        assert_eq!(
            suggest_best_template_checked(vec![value], vec![]).is_ok(),
            (0.0..=1.0).contains(&value)
        );
    }
}
