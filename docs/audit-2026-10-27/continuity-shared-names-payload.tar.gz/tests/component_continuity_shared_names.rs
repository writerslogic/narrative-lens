use narrative_lens::continuity::causal_engine::{self, CausalLinkType};

#[test]
fn name_substrings_cannot_create_agents_or_association_edges() {
    let text = "A wall stood beside empty huts. Calm breezes rippled through barren trees.";
    let result = causal_engine::analyze_causality_checked(&[text], &["Al"]).unwrap();
    assert_eq!(result.events.len(), 2);
    assert!(result.events.iter().all(|event| event.agent.is_none()));
    assert!(result.links.is_empty());
}

#[test]
fn subject_prefix_candidates_are_cast_order_independent_and_skip_introductory_objects() {
    let text = "Alice decided to leave the harbor. After Bob spoke, Alice chose the eastern road.";
    let first = causal_engine::analyze_causality_checked(&[text], &["Al", "Alice", "Bob"]).unwrap();
    let second =
        causal_engine::analyze_causality_checked(&[text], &["Alice", "Bob", "Al"]).unwrap();
    assert_eq!(first.events.len(), 2);
    assert!(
        first
            .events
            .iter()
            .all(|event| event.agent.as_deref() == Some("Alice"))
    );
    assert_eq!(
        serde_json::to_value(first).unwrap(),
        serde_json::to_value(second).unwrap()
    );
}

#[test]
fn unsupported_passive_reported_and_negated_subject_roles_stay_unknown() {
    for text in [
        "The king spoke to Alice quietly.",
        "Bob was killed by Alice yesterday.",
        "Bob said Alice decided to leave.",
        "Alice never decided to leave the room.",
    ] {
        let result = causal_engine::analyze_causality_checked(&[text], &["Alice", "Bob"]).unwrap();
        assert_eq!(result.events.len(), 1);
        assert!(result.events[0].agent.is_none(), "{text}");
        assert!(
            result
                .links
                .iter()
                .all(|link| link.link_type == CausalLinkType::Association)
        );
        assert!(result.counterfactuals.is_empty() && result.plot_holes.is_empty());
    }
    let exact = causal_engine::analyze_causality_checked(
        &["\u{feff}ÉLODIE decided to leave the harbor."],
        &["Élodie"],
    )
    .unwrap();
    assert_eq!(exact.events[0].agent.as_deref(), Some("Élodie"));
}
