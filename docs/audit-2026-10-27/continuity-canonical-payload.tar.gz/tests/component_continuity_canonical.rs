use narrative_lens::{
    continuity::{
        coreference::*,
        entity::{self, Entity, EntityType},
    },
    manuscript::TextRange,
    substrate::common_types::Provenance,
};
use std::collections::HashMap;

fn character(id: &str, name: &str, aliases: &[&str]) -> Entity {
    Entity {
        id: id.into(),
        canonical: name.into(),
        aliases: aliases.iter().map(|s| (*s).into()).collect(),
        kind: EntityType::Character,
        mention_count: 0,
        confidence: 0.0,
        provenance: Provenance::UserEdited,
    }
}
fn pronouns(result: &CanonicalCoreferenceResult) -> Vec<&Mention> {
    result
        .analysis
        .mentions
        .iter()
        .filter(|m| m.is_pronoun)
        .collect()
}

#[test]
fn aliases_resolve_to_stable_ids_with_id_keyed_hints_and_exact_source_links() {
    let cast = [
        character("c-robert", "Robert Finch", &["Robert", "Bob"]),
        character("c-alice", "Alice Jones", &["Alice"]),
    ];
    let hints: HashMap<_, _> = [
        ("c-robert".into(), "male".into()),
        ("c-alice".into(), "female".into()),
    ]
    .into_iter()
    .collect();
    let result = CoreferenceResolver::new()
        .resolve_characters_checked("Bob met Alice. He waved.", &cast, Some(&hints))
        .unwrap();
    assert_eq!(
        pronouns(&result)[0].resolved_to.as_deref(),
        Some("c-robert")
    );
    assert_eq!(pronouns(&result)[0].antecedent_start, Some(0));
    assert_eq!(result.analysis.character_mentions["c-robert"], 2);
    assert_eq!(result.analysis.character_mentions["c-alice"], 1);
    assert_eq!(
        result
            .characters
            .iter()
            .find(|c| c.id == "c-robert")
            .unwrap()
            .canonical,
        "Robert Finch"
    );
    let mut reversed = cast.to_vec();
    reversed.reverse();
    reversed[1].aliases.reverse();
    assert_eq!(
        serde_json::to_value(&result).unwrap(),
        serde_json::to_value(
            CoreferenceResolver::new()
                .resolve_characters_checked("Bob met Alice. He waved.", &reversed, Some(&hints))
                .unwrap()
        )
        .unwrap()
    );
    let mut renamed = cast.to_vec();
    let previous_name = renamed[0].canonical.clone();
    renamed[0].aliases.push(previous_name);
    renamed[0].canonical = "Rob Finch".into();
    let after = CoreferenceResolver::new()
        .resolve_characters_checked("Bob met Alice. He waved.", &renamed, Some(&hints))
        .unwrap();
    assert_eq!(
        serde_json::to_value(result.analysis).unwrap(),
        serde_json::to_value(after.analysis).unwrap()
    );
}

#[test]
fn shared_aliases_and_authoritative_distinct_ids_remain_ambiguous() {
    let resolver = CoreferenceResolver::new();
    let cast = [
        character("john", "John Smith", &["Smith"]),
        character("mary", "Mary Smith", &["Smith"]),
    ];
    let result = resolver
        .resolve_characters_checked("Smith waited. They left.", &cast, None)
        .unwrap();
    assert!(
        result
            .analysis
            .mentions
            .iter()
            .all(|m| m.resolved_to.is_none())
    );
    let explicit = resolver
        .resolve_characters_checked("John Smith waited. He left.", &cast, None)
        .unwrap();
    assert_eq!(pronouns(&explicit)[0].resolved_to.as_deref(), Some("john"));
    let names = [
        character("first", "Alice", &[]),
        character("second", "Alice", &[]),
    ];
    assert!(
        resolver
            .resolve_characters_checked("Alice waited. She left.", &names, None)
            .unwrap()
            .analysis
            .mentions
            .iter()
            .all(|m| m.resolved_to.is_none())
    );
    let separate = [
        character("bob", "Bob", &[]),
        character("robert", "Robert", &[]),
    ];
    assert!(
        pronouns(
            &resolver
                .resolve_characters_checked("Bob met Robert. He left.", &separate, None)
                .unwrap()
        )[0]
        .resolved_to
        .is_none()
    );
}

#[test]
fn existing_entity_resolution_composes_without_flat_alias_identity_confusion() {
    let surfaces = ["Bob", "Robert", "Bob", "Robert"];
    let mentions: Vec<_> = surfaces
        .into_iter()
        .map(|s| entity::Mention::new(s, Vec::new()))
        .collect();
    let cast = entity::resolve_checked(&mentions, EntityType::Character).unwrap();
    assert_eq!(cast.len(), 1);
    assert_eq!(cast[0].mention_count, 4);
    let resolver = CoreferenceResolver::new();
    let flat = resolver
        .resolve_checked("Bob met Robert. He left.", &["Bob", "Robert"], None)
        .unwrap();
    assert!(
        flat.mentions
            .iter()
            .filter(|m| m.is_pronoun)
            .all(|m| m.resolved_to.is_none())
    );
    let canonical = resolver
        .resolve_characters_checked("Bob met Robert. He left.", &cast, None)
        .unwrap();
    assert_eq!(
        pronouns(&canonical)[0].resolved_to.as_deref(),
        Some(cast[0].id.as_str())
    );
    assert_eq!(canonical.analysis.character_mentions[&cast[0].id], 3);
}

#[test]
fn bulk_alias_matching_preserves_unicode_case_ambiguity_and_nonword_names() {
    let resolver = CoreferenceResolver::new();
    let cast = [
        character("elo", "Élodie O’Neill", &["Élodie"]),
        character("cpp", "C++", &[]),
    ];
    let hints = HashMap::from([
        ("elo".into(), "female".into()),
        ("cpp".into(), "neutral".into()),
    ]);
    let text =
        "\u{feff}😀 İ ÉLODIE O’NEILL paused. She rested. XC++ and C++x are controls. C++ waited.";
    let result = resolver
        .resolve_characters_checked(text, &cast, Some(&hints))
        .unwrap();
    assert_eq!(pronouns(&result)[0].resolved_to.as_deref(), Some("elo"));
    assert_eq!(
        result
            .analysis
            .mentions
            .iter()
            .filter(|m| !m.is_pronoun && m.resolved_to.as_deref() == Some("cpp"))
            .count(),
        1
    );
    for mention in &result.analysis.mentions {
        let range = mention.range.as_ref().unwrap();
        assert_eq!(
            TextRange::from_utf16(text, range.utf16_start, range.utf16_end).unwrap(),
            *range
        );
        assert_eq!(&text[range.byte_start..range.byte_end], mention.text);
    }
    let ambiguous = resolver
        .resolve_characters_checked(
            "Σ rested. He left.",
            &[character("s1", "σ", &[]), character("s2", "ς", &[])],
            None,
        )
        .unwrap();
    assert!(
        ambiguous
            .analysis
            .mentions
            .iter()
            .all(|m| m.resolved_to.is_none())
    );
}

#[test]
fn canonical_cast_validation_is_atomic_and_rejects_invalid_identity_metadata() {
    let resolver = CoreferenceResolver::new();
    let valid = character("c", "Alice", &["Ada"]);
    let mut bads = Vec::new();
    let mut bad = valid.clone();
    bad.kind = EntityType::Setting;
    bads.push(bad);
    let mut bad = valid.clone();
    bad.confidence = f64::NAN;
    bads.push(bad);
    let mut bad = valid.clone();
    bad.confidence = 1.01;
    bads.push(bad);
    let mut bad = valid.clone();
    bad.aliases = vec!["Ada".into(), "Ada".into()];
    bads.push(bad);
    let mut bad = valid.clone();
    bad.aliases = vec!["Alice".into()];
    bads.push(bad);
    let mut bad = valid.clone();
    bad.aliases = vec!["x".repeat(200_000)];
    bads.push(bad);
    for bad in bads {
        assert!(
            resolver
                .resolve_characters_checked("Alice left.", &[valid.clone(), bad], None)
                .is_err()
        );
    }
    assert!(
        resolver
            .resolve_characters_checked("Alice left.", &[valid.clone(), valid.clone()], None)
            .is_err()
    );
    assert!(
        resolver
            .resolve_characters_checked(
                "Alice left.",
                std::slice::from_ref(&valid),
                Some(&HashMap::from([("Alice".into(), "female".into())]))
            )
            .is_err()
    );
    assert!(
        resolver
            .resolve_characters_checked(
                "Alice left.",
                std::slice::from_ref(&valid),
                Some(&HashMap::from([("c".into(), "unsupported".into())]))
            )
            .is_err()
    );
    assert!(
        resolver
            .resolve_characters_checked(&" ".repeat(16 * 1024 * 1024 + 1), &[valid], None)
            .is_err()
    );
}

#[test]
fn canonical_cast_alias_id_name_and_metadata_budgets_cover_exact_boundaries() {
    let resolver = CoreferenceResolver::new();
    for count in [255, 256, 257] {
        let cast: Vec<_> = (0..count)
            .map(|i| character(&format!("c{i}"), &format!("name{i}"), &[]))
            .collect();
        assert_eq!(
            resolver.resolve_characters_checked("", &cast, None).is_ok(),
            count <= 256
        );
    }
    for count in [
        MAX_COREFERENCE_ALIAS_FORMS - 1,
        MAX_COREFERENCE_ALIAS_FORMS,
        MAX_COREFERENCE_ALIAS_FORMS + 1,
    ] {
        let mut cast = character("c", "Main", &[]);
        cast.aliases = (0..count - 1).map(|i| format!("Alias{i}")).collect();
        assert_eq!(
            resolver
                .resolve_characters_checked("", &[cast], None)
                .is_ok(),
            count <= MAX_COREFERENCE_ALIAS_FORMS
        );
    }
    for bytes in [255, 256, 257] {
        assert_eq!(
            resolver
                .resolve_characters_checked("", &[character(&"c".repeat(bytes), "Name", &[])], None)
                .is_ok(),
            bytes <= 256
        );
    }
    for bytes in [127, 128, 129] {
        assert_eq!(
            resolver
                .resolve_characters_checked("", &[character("c", &"N".repeat(bytes), &[])], None)
                .is_ok(),
            bytes <= 128
        );
    }
    for delta in [-1, 0, 1] {
        let mut cast = character("c", "Main", &[]);
        cast.aliases = (0..2048).map(|i| format!("a{i:0127}")).collect();
        cast.aliases[2047] = "z".repeat((123 + delta) as usize);
        assert_eq!(
            cast.id.len()
                + cast.canonical.len()
                + cast.aliases.iter().map(String::len).sum::<usize>(),
            (MAX_COREFERENCE_CAST_BYTES as isize + delta) as usize
        );
        let result = resolver.resolve_characters_checked("", &[cast], None);
        assert_eq!(result.is_ok(), delta <= 0, "{:?}", result.as_ref().err());
    }
}
